"""Abre o Midas: sobe o servidor, abre a tela numa janela própria (Edge/Chrome em modo aplicativo) e encerra tudo
quando a janela é fechada. Faz parte do aplicativo (atualizável); quem chama é o ponto de partida `iniciar.py`."""
from __future__ import annotations

import os
import socket
import subprocess
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent   # a pasta "sistema" (ou a raiz do projeto, ao desenvolver)
HOST = "127.0.0.1"
PINGS_SUMIDOS_S = 90          # sem sinal da tela por este tempo (modo sem janela própria) -> encerra
SAIDA_RAPIDA_S = 5            # navegador que "fecha" em menos disso passou o trabalho a outro processo


def _responde(porta: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://{HOST}:{porta}/saude", timeout=1.5) as r:
            return b"leitura_de_fotos" in r.read()
    except Exception:
        return False


def _porta_ocupada(porta: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex((HOST, porta)) == 0


def escolher_porta() -> tuple[int, bool]:
    """(porta, ja_rodando). Reaproveita uma cópia do sistema que já esteja aberta."""
    for porta in range(8000, 8020):
        if _responde(porta):
            return porta, True
        if not _porta_ocupada(porta):
            return porta, False
    raise RuntimeError("Nenhuma porta livre entre 8000 e 8019.")


def achar_navegador() -> str | None:
    forcado = os.getenv("NF_NAVEGADOR")
    if forcado:
        return forcado
    bases = [os.getenv(v) for v in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData")]
    relativos = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    for rel in relativos:
        for base in filter(None, bases):
            caminho = Path(base) / rel
            if caminho.exists():
                return str(caminho)
    return None


def abrir_janela(url: str, dados: Path) -> subprocess.Popen | None:
    exe = achar_navegador()
    if not exe:
        return None
    perfil = dados / "janela"            # perfil próprio: o processo vive enquanto a janela estiver aberta
    try:
        return subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={perfil}", "--no-first-run",
                                 "--no-default-browser-check", "--window-size=1440,920"])
    except OSError:
        return None


def vigiar(servidor, app, janela: subprocess.Popen | None) -> None:
    inicio = time.time()
    if janela is not None:
        janela.wait()
        if time.time() - inicio > SAIDA_RAPIDA_S:
            servidor.should_exit = True      # janela fechada pelo usuário
            return
    while not servidor.should_exit:          # sem janela própria: encerra quando a tela some
        time.sleep(5)
        ultimo = app.state.ultimo_ping
        if (ultimo and time.time() - ultimo > PINGS_SUMIDOS_S) or (not ultimo and time.time() - inicio > 180):
            servidor.should_exit = True


def principal(ao_confirmar=None) -> None:
    """Sobe o servidor e abre a janela. `ao_confirmar` é chamado quando o servidor respondeu: é o sinal de que
    esta versão do aplicativo abre (o ponto de partida usa isso para manter ou desfazer uma atualização)."""
    dados = Path(os.getenv("NF_DADOS_DIR") or RAIZ / "dados")
    porta, ja_rodando = escolher_porta()
    url = f"http://{HOST}:{porta}/"
    if ja_rodando:
        if abrir_janela(url, dados) is None:
            webbrowser.open(url)
        return

    import uvicorn
    from app.main import criar_app

    app = criar_app()
    servidor = uvicorn.Server(uvicorn.Config(app, host=HOST, port=porta, log_level="warning"))

    def abrir() -> None:
        for _ in range(100):                 # espera o servidor responder (até ~10 s)
            if _responde(porta):
                if ao_confirmar:
                    ao_confirmar()
                break
            time.sleep(0.1)
        janela = abrir_janela(url, dados)
        if janela is None:
            webbrowser.open(url)
        vigiar(servidor, app, janela)

    threading.Thread(target=abrir, daemon=True).start()
    servidor.run()


