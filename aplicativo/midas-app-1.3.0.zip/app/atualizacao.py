"""Atualizações do aplicativo: consulta o canal público, baixa o pacote, confere e deixa pronto para o próximo início.

Quem troca os arquivos é o ponto de partida (`iniciar.py`), ao abrir o Midas de novo: aqui só se baixa e confere.
Só existe atualização no pacote instalado (há `python/motor.json`); ao desenvolver, fica desligada.

No canal (repositório público midas-atualizacoes):
  versoes.json   {"aplicativo": {"versao", "arquivo", "sha256", "tamanho", "motor_minimo", "publicado_em",
                                 "novidades": [...]}, "instalador": {"versao", "url"}}
  aplicativo/midas-app-<versao>.zip
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import threading
import time
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

RAIZ = Path(__file__).resolve().parent.parent
CAMADA = ("app", "versao.json", "NOVIDADES.md", "README.md", ".env.example", "requirements.txt",
          "Diagnostico.bat", "Restaurar_backup.bat")   # o mesmo que iniciar.py troca
TAMANHO_MAXIMO = 30 * 1024 * 1024                       # um pacote do aplicativo tem cerca de 1 MB
CONSULTA_VALE_S = 3600


class ErroAtualizacao(Exception):
    pass


def numero_versao(texto: str | None) -> tuple[int, ...]:
    """'1.10.2' -> (1, 10, 2); texto inválido conta como 0."""
    partes = re.findall(r"\d+", texto or "")
    return tuple(int(p) for p in partes) or (0,)


def _baixar_http(url: str, limite: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Midas-atualizador", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        dados = r.read(limite + 1)
    if len(dados) > limite:
        raise ErroAtualizacao("O arquivo baixado é maior do que o esperado.")
    return dados


class Atualizador:
    def __init__(self, raiz: Path = RAIZ, baixar=None):
        self.raiz = raiz
        self._baixar = baixar or _baixar_http
        self._trava = threading.Lock()
        self._consulta: dict | None = None
        self._consultado_em = 0.0
        self._erro: str | None = None

    # ------------------------------------------------------------------ o que está instalado
    @property
    def pasta(self) -> Path:
        return self.raiz / "_atualizacao"

    def local(self) -> dict:
        def ler(caminho: Path) -> dict:
            try:
                return json.loads(caminho.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return {}
        versao = ler(self.raiz / "versao.json")
        motor = ler(self.raiz / "python" / "motor.json")
        return {"aplicativo": versao.get("aplicativo"), "canal": versao.get("canal"), "motor": motor.get("motor")}

    def ativo(self) -> bool:
        info = self.local()
        return bool(info["motor"] and info["canal"] and info["aplicativo"]) and os.getenv("NF_ATUALIZACAO", "1") != "0"

    def pronta(self) -> str | None:
        try:
            return json.loads((self.pasta / "nova" / "versao.json").read_text(encoding="utf-8")).get("aplicativo")
        except (OSError, ValueError):
            return None

    def falha(self) -> dict | None:
        try:
            return json.loads((self.pasta / "falhou.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def bloqueadas(self) -> set[str]:
        """Versões que já falharam neste computador: não são oferecidas de novo (a próxima versão corrige)."""
        try:
            lista = set(json.loads((self.pasta / "bloqueadas.json").read_text(encoding="utf-8")))
        except (OSError, ValueError):
            lista = set()
        falha = self.falha()
        if falha and falha.get("versao"):
            lista.add(falha["versao"])
        return lista

    def dispensar_falha(self) -> None:
        bloqueadas = self.bloqueadas()
        self.pasta.mkdir(parents=True, exist_ok=True)
        (self.pasta / "bloqueadas.json").write_text(json.dumps(sorted(bloqueadas)), encoding="utf-8")
        (self.pasta / "falhou.json").unlink(missing_ok=True)

    # ------------------------------------------------------------------ o que há no canal
    def verificar(self, forcar: bool = False) -> dict:
        if not self.ativo():
            return self.status()
        if forcar or self._consulta is None or time.time() - self._consultado_em > CONSULTA_VALE_S:
            try:
                bruto = self._baixar(self.local()["canal"] + "versoes.json", 1024 * 1024)
                self._consulta = json.loads(bruto.decode("utf-8"))
                self._erro = None
            except Exception as e:  # sem internet, canal fora do ar: só informa
                self._erro = f"Não consegui consultar as atualizações ({type(e).__name__})."
            self._consultado_em = time.time()
        return self.status()

    def _disponivel(self) -> dict | None:
        remoto = (self._consulta or {}).get("aplicativo")
        local = self.local()
        if not remoto or numero_versao(remoto.get("versao")) <= numero_versao(local["aplicativo"]):
            return None
        if remoto.get("versao") in self.bloqueadas():
            return None
        precisa_instalador = numero_versao(remoto.get("motor_minimo")) > numero_versao(local["motor"])
        return {"versao": remoto.get("versao"), "novidades": remoto.get("novidades") or [],
                "tamanho": remoto.get("tamanho"), "publicado_em": remoto.get("publicado_em"),
                "precisa_instalador": precisa_instalador,
                "instalador_url": ((self._consulta or {}).get("instalador") or {}).get("url")}

    def status(self) -> dict:
        local = self.local()
        return {"atual": local["aplicativo"], "motor": local["motor"], "ativo": self.ativo(),
                "disponivel": self._disponivel() if self.ativo() else None, "pronta": self.pronta(),
                "falha": self.falha(), "erro": self._erro}

    # ------------------------------------------------------------------ baixar e conferir
    def baixar(self) -> dict:
        with self._trava:
            if not self.ativo():
                raise ErroAtualizacao("Atualizações só funcionam no Midas instalado.")
            disponivel = self._disponivel()
            if not disponivel:
                raise ErroAtualizacao("Não há versão nova para baixar.")
            if disponivel["precisa_instalador"]:
                raise ErroAtualizacao("Esta versão precisa do instalador completo (o motor do Midas mudou).")
            remoto = self._consulta["aplicativo"]
            if self.pronta() == remoto["versao"]:
                return self.status()
            conteudo = self._baixar(self.local()["canal"] + remoto["arquivo"], TAMANHO_MAXIMO)
            if remoto.get("tamanho") is not None and len(conteudo) != remoto["tamanho"]:
                raise ErroAtualizacao("O arquivo baixado veio incompleto. Tente de novo.")
            if hashlib.sha256(conteudo).hexdigest() != remoto.get("sha256"):
                raise ErroAtualizacao("O arquivo baixado não confere com o publicado (integridade). Nada foi alterado.")
            self._extrair(conteudo, remoto["versao"])
            return self.status()

    def _extrair(self, conteudo: bytes, versao: str) -> None:
        try:
            pacote = zipfile.ZipFile(io.BytesIO(conteudo))
        except zipfile.BadZipFile as e:
            raise ErroAtualizacao("O pacote baixado não é um arquivo válido.") from e
        nomes = pacote.namelist()
        total = 0
        for info in pacote.infolist():
            caminho = PurePosixPath(info.filename)
            if caminho.is_absolute() or ".." in caminho.parts or ":" in info.filename or "\\" in info.filename:
                raise ErroAtualizacao("O pacote tem um caminho inválido. Nada foi alterado.")
            if caminho.parts and caminho.parts[0] not in CAMADA:
                raise ErroAtualizacao(f"O pacote tem um arquivo fora do aplicativo ({info.filename}).")
            total += info.file_size
        if total > 4 * TAMANHO_MAXIMO:
            raise ErroAtualizacao("O pacote é grande demais para uma atualização do aplicativo.")
        if "versao.json" not in nomes or "app/main.py" not in nomes:
            raise ErroAtualizacao("O pacote não tem o aplicativo completo.")
        if json.loads(pacote.read("versao.json")).get("aplicativo") != versao:
            raise ErroAtualizacao("A versão dentro do pacote não confere com a publicada.")
        temporaria = self.pasta / "baixando"
        shutil.rmtree(temporaria, ignore_errors=True)
        temporaria.mkdir(parents=True)
        pacote.extractall(temporaria)
        nova = self.pasta / "nova"
        shutil.rmtree(nova, ignore_errors=True)
        temporaria.rename(nova)   # só aparece como "pronta" depois de inteira

    # ------------------------------------------------------------------ novidades
    def novidades(self) -> list[dict]:
        """NOVIDADES.md do aplicativo instalado -> [{versao, data, itens}] (mais nova primeiro)."""
        try:
            texto = (self.raiz / "NOVIDADES.md").read_text(encoding="utf-8")
        except OSError:
            return []
        lista: list[dict] = []
        for linha in texto.splitlines():
            m = re.match(r"^##\s+(\S+)(?:\s*·\s*(\S+))?", linha)
            if m:
                lista.append({"versao": m.group(1), "data": m.group(2), "itens": []})
            elif lista and linha.startswith("- "):
                lista[-1]["itens"].append(linha[2:].strip())
        return lista
