"""Banco SQLite. Valores em centavos; datas em ISO (AAAA-MM-DD); competência no formato AAAA-MM."""
from __future__ import annotations

import sqlite3
from pathlib import Path

CATEGORIAS_PADRAO = [
    "Alimentação", "Bebidas", "Brindes", "Locação de espaço", "Locação de equipamentos",
    "Decoração", "Material gráfico", "Transporte", "Hospedagem", "Comunicação e mídia",
    "Serviços de terceiros", "Outros",
]

COLUNAS_NOTAS = (
    "id, status, origem, fornecedor, cnpj, numero, serie, data_emissao, valor_total_centavos, chave_acesso, "
    "grupo_id, categoria_id, competencia, confianca, observacoes, arquivo_nome, arquivo_mime, arquivo_sha256, "
    "arquivo_ref, arquivo_local, criado_em, validado_em"
)


def _ddl_notas(nome_sql: str) -> str:
    # Nota manual não tem arquivo: as colunas arquivo_* aceitam NULL (arquivo_ref NULL = sem arquivo).
    return f"""
CREATE TABLE {nome_sql} (
    id                   INTEGER PRIMARY KEY,
    status               TEXT NOT NULL DEFAULT 'lido' CHECK (status IN ('lido', 'validado', 'lancado')),
    origem               TEXT NOT NULL,
    fornecedor           TEXT,
    cnpj                 TEXT,
    numero               TEXT,
    serie                TEXT,
    data_emissao         TEXT,
    valor_total_centavos INTEGER,
    chave_acesso         TEXT UNIQUE,
    grupo_id            INTEGER REFERENCES grupos(id),
    categoria_id         INTEGER REFERENCES categorias(id),
    competencia          TEXT,
    confianca            TEXT NOT NULL DEFAULT '{{}}',
    observacoes          TEXT,
    arquivo_nome         TEXT,
    arquivo_mime         TEXT,
    arquivo_sha256       TEXT,
    arquivo_ref          TEXT,
    arquivo_local        TEXT CHECK (arquivo_local IS NULL OR arquivo_local IN ('entrada', 'destino')),
    criado_em            TEXT NOT NULL,
    validado_em          TEXT
)"""


INDICES = """
CREATE INDEX IF NOT EXISTS ix_notas_competencia ON notas (competencia);
CREATE INDEX IF NOT EXISTS ix_notas_grupo      ON notas (grupo_id);
CREATE INDEX IF NOT EXISTS ix_notas_sha256      ON notas (arquivo_sha256);
CREATE INDEX IF NOT EXISTS ix_itens_nota        ON itens (nota_id);
"""

ESQUEMA = f"""
CREATE TABLE IF NOT EXISTS categorias (
    id   INTEGER PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS grupos (
    id                 INTEGER PRIMARY KEY,
    nome               TEXT NOT NULL UNIQUE COLLATE NOCASE,
    data_grupo        TEXT,
    orcamento_centavos INTEGER,
    criado_em          TEXT NOT NULL
);

{_ddl_notas("IF NOT EXISTS notas")};

CREATE TABLE IF NOT EXISTS itens (
    id                      INTEGER PRIMARY KEY,
    nota_id                 INTEGER NOT NULL REFERENCES notas(id) ON DELETE CASCADE,
    descricao               TEXT NOT NULL,
    quantidade              REAL,
    valor_unitario_centavos INTEGER,
    valor_total_centavos    INTEGER
);
"""


def conectar(caminho: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(caminho, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def _migrar_evento_para_grupo(conn: sqlite3.Connection) -> None:
    """Bancos antigos chamavam de 'evento' o que agora é 'grupo': renomeia tabela e colunas sem tocar nos dados."""
    existe = lambda nome: conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (nome,)).fetchone()  # noqa: E731
    if not existe("eventos") or existe("grupos"):
        return
    conn.commit()
    try:
        conn.execute("BEGIN")
        conn.execute("ALTER TABLE eventos RENAME TO grupos")
        conn.execute("ALTER TABLE grupos RENAME COLUMN data_evento TO data_grupo")
        if existe("notas") and "evento_id" in {c["name"] for c in conn.execute("PRAGMA table_info(notas)")}:
            conn.execute("ALTER TABLE notas RENAME COLUMN evento_id TO grupo_id")
        conn.execute("DROP INDEX IF EXISTS ix_notas_evento")
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def _migrar_arquivo_opcional(conn: sqlite3.Connection) -> None:
    """Bancos criados antes do lançamento manual têm arquivo_nome NOT NULL: recria a tabela preservando tudo."""
    colunas = {c["name"]: c for c in conn.execute("PRAGMA table_info(notas)")}
    if not colunas["arquivo_nome"]["notnull"]:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys = OFF")  # exigido pelo SQLite para recriar uma tabela referenciada por outra
    try:
        conn.execute("BEGIN")
        conn.execute(_ddl_notas("notas_nova"))
        conn.execute(f"INSERT INTO notas_nova ({COLUNAS_NOTAS}) SELECT {COLUNAS_NOTAS} FROM notas")
        conn.execute("DROP TABLE notas")
        conn.execute("ALTER TABLE notas_nova RENAME TO notas")
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def _migrar_tipo_documento(conn: sqlite3.Connection) -> None:
    """Notas antigas ficam com tipo_documento NULL (= desconhecido), sem perder nada."""
    colunas = {c["name"] for c in conn.execute("PRAGMA table_info(notas)")}
    if "tipo_documento" not in colunas:
        conn.execute("ALTER TABLE notas ADD COLUMN tipo_documento TEXT")
    if "regioes" not in colunas:  # onde cada campo foi lido na foto (JSON), para destacar na tela
        conn.execute("ALTER TABLE notas ADD COLUMN regioes TEXT")


# ---------------------------------------------------------------------------- migrações numeradas
# A versão do banco fica gravada nele mesmo (PRAGMA user_version). Cada migração roda UMA vez, em ordem, e o
# Midas faz uma cópia de segurança antes de qualquer migração pendente num banco que já tem dados.
# Para mudar a estrutura: acrescente uma função no fim de MIGRACOES (nunca altere uma que já foi publicada).

def _m001_estrutura_inicial(conn: sqlite3.Connection) -> None:
    """Leva qualquer banco anterior às migrações numeradas (ou um banco novo) à estrutura de outubro de 2026."""
    _migrar_evento_para_grupo(conn)   # antes do ESQUEMA, para não criar uma tabela 'grupos' vazia ao lado de 'eventos'
    conn.executescript(ESQUEMA)
    _migrar_arquivo_opcional(conn)
    _migrar_tipo_documento(conn)
    conn.executescript(INDICES)
    if conn.execute("SELECT COUNT(*) FROM categorias").fetchone()[0] == 0:
        conn.executemany("INSERT INTO categorias (nome) VALUES (?)", [(n,) for n in CATEGORIAS_PADRAO])


MIGRACOES: list[tuple[int, str, object]] = [
    (1, "estrutura inicial (notas, itens, grupos, categorias)", _m001_estrutura_inicial),
]
VERSAO_BANCO = MIGRACOES[-1][0]


class BancoMaisNovo(RuntimeError):
    """O banco foi atualizado por uma versão mais nova do Midas do que a que está tentando abri-lo."""


def versao_do_banco(conn: sqlite3.Connection) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def _tem_dados(conn: sqlite3.Connection) -> bool:
    return conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0] > 0


def iniciar_banco(caminho: Path, pasta_backups: Path | None = None) -> list[int]:
    """Cria ou atualiza o banco. Devolve os números das migrações aplicadas agora (vazio = já estava em dia)."""
    from . import backup

    caminho.parent.mkdir(parents=True, exist_ok=True)
    pasta_backups = pasta_backups or caminho.parent / "backups"
    conn = conectar(caminho)
    try:
        atual = versao_do_banco(conn)
        if atual > VERSAO_BANCO:
            raise BancoMaisNovo(
                f"Os dados foram atualizados por uma versão mais nova do Midas (banco v{atual}; esta versão conhece "
                f"até v{VERSAO_BANCO}). Instale a versão mais recente do Midas.")
        pendentes = [m for m in MIGRACOES if m[0] > atual]
        if pendentes and _tem_dados(conn):
            conn.close()
            backup.fazer(caminho, pasta_backups, f"antes-v{VERSAO_BANCO}")
            conn = conectar(caminho)
        for numero, _descricao, migrar in pendentes:
            migrar(conn)
            conn.execute(f"PRAGMA user_version = {int(numero)}")
            conn.commit()
        return [m[0] for m in pendentes]
    finally:
        conn.close()
