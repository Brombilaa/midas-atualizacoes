"""API HTTP. Para rodar:  uvicorn app.main:criar_app --factory --reload   (docs em /docs)"""
from __future__ import annotations

import secrets
import time
from pathlib import Path
from typing import Iterator
from urllib.parse import quote

from fastapi import APIRouter, Depends, FastAPI, Form, Header, HTTPException, Query, Request, Response, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import Config, carregar_config
from . import backup
from .atualizacao import Atualizador, ErroAtualizacao
from .db import conectar, iniciar_banco
from .dinheiro import para_centavos
from .schemas import (CategoriaIn, CategoriaOut, Competencia, GrupoIn, GrupoOut, GrupoPatch, NotaOut,
                      NotaPatch, ValidarIn, grupo_out, itens_para_centavos, nota_out)
from .service import ErroNegocio, Servico

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
ESTATICOS = Path(__file__).resolve().parent / "static"
# Só estes tipos abrem no navegador; qualquer outro anexo é sempre baixado (nunca executado como página).
EXIBIVEIS = {"image/jpeg", "image/png", "image/webp", "application/pdf"}


def criar_app(cfg: Config | None = None, leitor=None, atualizador: Atualizador | None = None) -> FastAPI:
    cfg = cfg or carregar_config()
    iniciar_banco(cfg.db_path, cfg.dados_dir / "backups")
    backup.diario(cfg.db_path, cfg.dados_dir / "backups")  # uma cópia por dia, ao abrir
    servico = Servico(cfg, leitor)
    atualizador = atualizador or Atualizador()

    def get_conn() -> Iterator:
        conn = conectar(cfg.db_path)
        try:
            yield conn
        finally:
            conn.close()

    def autenticar(x_api_token: str | None = Header(default=None)) -> None:
        if cfg.api_token and not (x_api_token and secrets.compare_digest(x_api_token, cfg.api_token)):
            raise HTTPException(401, "Token inválido ou ausente (cabeçalho X-API-Token).")

    app = FastAPI(title="Midas", version=atualizador.local()["aplicativo"] or "dev")
    api = APIRouter(dependencies=[Depends(autenticar)])

    @app.exception_handler(ErroAtualizacao)
    async def tratar_erro_atualizacao(_: Request, e: ErroAtualizacao) -> JSONResponse:
        return JSONResponse(status_code=409, content={"detail": str(e)})

    @app.exception_handler(ErroNegocio)
    async def tratar_erro(_: Request, e: ErroNegocio) -> JSONResponse:
        return JSONResponse(status_code=e.status_http, content={"detail": e.mensagem, **e.extras})

    app.state.ultimo_ping = None

    @app.get("/ping", include_in_schema=False)
    def ping() -> dict:
        """A tela chama isto a cada poucos segundos; o lançador usa para saber que ainda há uma janela aberta."""
        app.state.ultimo_ping = time.time()
        return {"ok": True}

    @app.get("/saude")
    def saude() -> dict:
        return {"ok": True, "leitura_de_fotos": bool(servico.leitores_de_foto()), "leitor_de_fotos": servico.nome_do_leitor(), "armazenamento": cfg.armazenamento,
                "exige_token": cfg.api_token is not None, "limite_upload_mb": cfg.max_upload_mb}

    def ler_upload(arquivo: UploadFile) -> bytes:
        limite = cfg.max_upload_mb * 1024 * 1024
        conteudo = arquivo.file.read(limite + 1)
        if len(conteudo) > limite:
            raise HTTPException(413, f"Arquivo maior que {cfg.max_upload_mb} MB.")
        return conteudo

    # ------------------------------------------------------------ grupos e categorias
    @api.post("/grupos", response_model=GrupoOut, status_code=201)
    def criar_grupo(dados: GrupoIn, conn=Depends(get_conn)):
        return grupo_out(servico.criar_grupo(conn, dados.nome, dados.data_grupo, para_centavos(dados.orcamento)))

    @api.get("/grupos", response_model=list[GrupoOut])
    def listar_grupos(conn=Depends(get_conn)):
        return [grupo_out(e) for e in servico.listar_grupos(conn)]

    @api.patch("/grupos/{grupo_id}", response_model=GrupoOut)
    def atualizar_grupo(grupo_id: int, dados: GrupoPatch, conn=Depends(get_conn)):
        campos = dados.model_dump(exclude_unset=True)
        if "orcamento" in campos:
            campos["orcamento_centavos"] = para_centavos(campos.pop("orcamento"))
        return grupo_out(servico.atualizar_grupo(conn, grupo_id, campos))

    @api.post("/categorias", response_model=CategoriaOut, status_code=201)
    def criar_categoria(dados: CategoriaIn, conn=Depends(get_conn)):
        return servico.criar_categoria(conn, dados.nome)

    @api.patch("/categorias/{categoria_id}", response_model=CategoriaOut)
    def renomear_categoria(categoria_id: int, dados: CategoriaIn, conn=Depends(get_conn)):
        return servico.atualizar_categoria(conn, categoria_id, dados.nome)

    @api.delete("/categorias/{categoria_id}", status_code=204)
    def excluir_categoria(categoria_id: int, conn=Depends(get_conn)):
        """Só exclui categoria que nenhuma nota usa (409 com a contagem caso contrário)."""
        servico.excluir_categoria(conn, categoria_id)

    @api.get("/categorias", response_model=list[CategoriaOut])
    def listar_categorias(conn=Depends(get_conn)):
        return servico.listar_categorias(conn)

    # ------------------------------------------------------------ notas
    @api.post("/notas/upload", response_model=NotaOut, status_code=201)
    def enviar_nota(arquivo: UploadFile, ler: bool = Form(True), conn=Depends(get_conn)):
        """Recebe XML, PDF ou foto; lê os dados e devolve a nota com status 'lido' para conferência.

        Com `ler=false` o arquivo (qualquer documento) é só anexado e os dados são preenchidos à mão.
        """
        return nota_out(servico.receber_upload(conn, arquivo.filename or "", ler_upload(arquivo), ler))

    @api.post("/notas/manual", response_model=NotaOut, status_code=201)
    def lancar_manual(dados: NotaPatch | None = None, conn=Depends(get_conn)):
        """Lançamento sem arquivo: informe os dados (todos opcionais agora) e confira como qualquer nota."""
        campos, itens = campos_da_nota(dados) if dados else ({}, None)
        return nota_out(servico.criar_nota_manual(conn, campos, itens))

    @api.post("/notas/{nota_id}/arquivo", response_model=NotaOut)
    def anexar_arquivo(nota_id: int, arquivo: UploadFile, conn=Depends(get_conn)):
        """Anexa um comprovante (foto, PDF, documento...) a uma nota aberta que ainda não tem arquivo."""
        return nota_out(servico.anexar_arquivo(conn, nota_id, arquivo.filename or "", ler_upload(arquivo)))

    @api.get("/notas", response_model=list[NotaOut])
    def listar_notas(status: str | None = Query(None, pattern="^(lido|validado|lancado|concluidas)$"),
                     grupo_id: int | None = None, competencia: Competencia | None = None,
                     limite: int = Query(200, ge=1, le=1000), offset: int = Query(0, ge=0), conn=Depends(get_conn)):
        return [nota_out(n) for n in servico.listar_notas(conn, status, grupo_id, competencia, limite, offset)]

    @api.get("/notas/{nota_id}", response_model=NotaOut)
    def obter_nota(nota_id: int, conn=Depends(get_conn)):
        return nota_out(servico.detalhar_nota(conn, nota_id))

    @api.get("/notas/{nota_id}/arquivo")
    def baixar_arquivo(nota_id: int, conn=Depends(get_conn)):
        conteudo, nome, mime = servico.arquivo_da_nota(conn, nota_id)
        exibivel = mime in EXIBIVEIS
        cabecalhos = {"Content-Disposition": f"{'inline' if exibivel else 'attachment'}; filename*=UTF-8''{quote(nome)}",
                      "X-Content-Type-Options": "nosniff"}
        if mime != "application/pdf":  # o visualizador de PDF do Chrome não funciona dentro de um sandbox de CSP
            cabecalhos["Content-Security-Policy"] = "default-src 'none'; sandbox"
        return Response(conteudo, media_type=mime if exibivel else "application/octet-stream", headers=cabecalhos)

    def campos_da_nota(dados: NotaPatch) -> tuple[dict, list[dict] | None]:
        campos = dados.model_dump(exclude_unset=True, exclude={"itens"})
        if "valor_total" in campos:
            campos["valor_total_centavos"] = para_centavos(campos.pop("valor_total"))
        itens = itens_para_centavos(dados.itens) if dados.itens is not None else None
        return campos, itens

    @api.patch("/notas/{nota_id}", response_model=NotaOut)
    def corrigir_nota(nota_id: int, dados: NotaPatch, conn=Depends(get_conn)):
        campos, itens = campos_da_nota(dados)
        return nota_out(servico.atualizar_nota(conn, nota_id, campos, itens))

    @api.post("/notas/{nota_id}/validar", response_model=NotaOut)
    def validar_nota(nota_id: int, dados: ValidarIn, conn=Depends(get_conn)):
        """Confirma a conferência: guarda o arquivo na pasta do grupo e libera a nota para a planilha."""
        return nota_out(servico.validar_nota(conn, nota_id, dados.grupo_id, dados.categoria_id, dados.competencia))

    @api.post("/notas/{nota_id}/reabrir", response_model=NotaOut)
    def reabrir_nota(nota_id: int, conn=Depends(get_conn)):
        return nota_out(servico.reabrir_nota(conn, nota_id))

    @api.delete("/notas/{nota_id}", status_code=204)
    def excluir_nota(nota_id: int, conn=Depends(get_conn)):
        servico.excluir_nota(conn, nota_id)

    # ------------------------------------------------------------ atualizações do aplicativo
    @api.get("/atualizacao")
    def estado_da_atualizacao(verificar: bool = False) -> dict:
        """Versão instalada, versão nova no canal (com verificar=true consulta a internet), pacote já baixado."""
        return atualizador.verificar(forcar=True) if verificar else atualizador.status()

    @api.post("/atualizacao/baixar")
    def baixar_atualizacao() -> dict:
        """Baixa e confere o pacote; ele é aplicado no próximo início do Midas."""
        return atualizador.baixar()

    @api.post("/atualizacao/dispensar-falha", status_code=204)
    def dispensar_falha() -> None:
        atualizador.dispensar_falha()

    @api.get("/novidades")
    def novidades() -> list[dict]:
        return atualizador.novidades()

    @api.get("/resumo/{competencia}")
    def resumo_do_mes(competencia: Competencia, conn=Depends(get_conn)) -> dict:
        """Painel do mês: total, notas, por categoria, por grupo (com orçamento) e últimas arquivadas. Centavos."""
        return servico.resumo_mes(conn, competencia)

    # ------------------------------------------------------------ planilha mensal
    def _xlsx(conteudo: bytes, competencia: str) -> Response:
        return Response(conteudo, media_type=XLSX,
                        headers={"Content-Disposition": f'attachment; filename="notas_{competencia}.xlsx"'})

    @api.get("/planilhas/{competencia}")
    def baixar_planilha(competencia: Competencia, conn=Depends(get_conn)):
        """Baixa a planilha do mês sem alterar nenhum status."""
        return _xlsx(servico.exportar_mes(conn, competencia, marcar_lancado=False), competencia)

    @api.post("/planilhas/{competencia}/lancar")
    def lancar_planilha(competencia: Competencia, conn=Depends(get_conn)):
        """Gera a planilha do mês e marca as notas validadas como 'lancado'."""
        return _xlsx(servico.exportar_mes(conn, competencia, marcar_lancado=True), competencia)

    # ------------------------------------------------------------ tela (arquivos estáticos, sem build)
    @app.get("/", include_in_schema=False)
    def tela() -> FileResponse:
        return FileResponse(ESTATICOS / "index.html", headers={"Cache-Control": "no-cache"})

    app.include_router(api)
    app.mount("/static", StaticFiles(directory=ESTATICOS, check_dir=False), name="static")
    return app
