@echo off
cd /d "%~dp0"
title Midas - diagnostico
echo Use este arquivo somente se o Iniciar nao abrir o sistema. Mantenha esta janela aberta.
if not exist ".env" copy ".env.example" ".env" >nul
set NF_NAVEGADOR=
"python\python.exe" iniciar.py
echo.
echo O sistema encerrou. Se houve erro acima, tire uma foto desta tela.
pause
