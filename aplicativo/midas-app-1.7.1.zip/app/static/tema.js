/* Tema claro/escuro. Carregado no <head> (antes da tela) para não piscar. Preferência: auto | claro | escuro. */
(function () {
  const CHAVE = 'midas_tema';
  const escuroDoSistema = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function preferencia() {
    try { const v = localStorage.getItem(CHAVE); if (v === 'claro' || v === 'escuro') return v; } catch { /* sem armazenamento */ }
    return 'auto';
  }
  function aplicar() {
    const p = preferencia();
    const escuro = p === 'escuro' || (p === 'auto' && escuroDoSistema && escuroDoSistema.matches);
    document.documentElement.dataset.tema = escuro ? 'escuro' : 'claro';
    document.documentElement.dataset.preferencia = p;
  }
  aplicar();
  if (escuroDoSistema && escuroDoSistema.addEventListener) escuroDoSistema.addEventListener('change', aplicar);
  window.midasTema = {
    preferencia,
    definir(p) { try { localStorage.setItem(CHAVE, p); } catch { /* ok */ } aplicar(); },
    alternar() {  // auto -> claro -> escuro -> auto
      const proxima = { auto: 'claro', claro: 'escuro', escuro: 'auto' }[preferencia()];
      this.definir(proxima);
      return proxima;
    },
  };
})();
