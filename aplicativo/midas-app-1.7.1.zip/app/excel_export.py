"""Gera a planilha mensal (xlsx): abas Resumo (fórmulas vivas), Despesas e Receitas."""
from __future__ import annotations

import io
import re
from datetime import date
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.properties import PageSetupProperties

MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]

FONTE = "Arial"
SEM_GRUPO = "(sem grupo)"
BRL = '"R$" #,##0.00'
CABECALHO_FILL = PatternFill("solid", fgColor="1F3864")
TOTAL_FILL = PatternFill("solid", fgColor="D9E1F2")
BORDA = Border(bottom=Side(style="thin", color="BFBFBF"))

# Valor sempre na coluna G, grupo na B e categoria na C, nas duas abas: as fórmulas do Resumo usam as mesmas colunas.
COLUNAS = [  # título, largura (aba Despesas)
    ("Data", 12), ("Grupo", 26), ("Categoria", 26), ("Fornecedor / descrição", 34), ("CNPJ", 20),
    ("Nº da nota", 12), ("Valor (R$)", 16), ("Conta", 18), ("Situação", 12), ("Chave de acesso", 48),
    ("Arquivo", 60), ("ID no sistema", 14),
]
COLUNAS_RECEITAS = [
    ("Data", 12), ("Grupo", 26), ("Categoria", 26), ("Descrição", 34), ("Cliente / origem", 28),
    ("Forma", 16), ("Valor (R$)", 16), ("Conta", 18), ("Situação", 12), ("Comprovante", 60), ("ID no sistema", 14),
]
ABA = "Despesas"
ABA_RECEITAS = "Receitas"
REF = f"'{ABA}'"
REF_RECEITAS = f"'{ABA_RECEITAS}'"


def nome_competencia(competencia: str) -> str:
    ano, mes = competencia.split("-")
    return f"{MESES[int(mes) - 1]}/{ano}"


def formatar_cnpj(cnpj: str | None) -> str:
    if cnpj and re.fullmatch(r"[0-9A-Z]{12}[0-9]{2}", cnpj):
        return f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
    return cnpj or ""


def _reais(centavos: int | None) -> float | None:
    return None if centavos is None else float(Decimal(centavos) / 100)


def _texto(celula, valor: str | None) -> None:
    """Grava texto sempre como texto: um fornecedor '=1+1' não pode virar fórmula no Excel."""
    celula.value = valor or None
    if isinstance(valor, str) and valor.startswith("="):
        celula.data_type = "s"


def _estilo(celula, *, negrito=False, cor=None, formato=None, fill=None, alinhamento=None) -> None:
    celula.font = Font(name=FONTE, size=10, bold=negrito, color=cor)
    if formato:
        celula.number_format = formato
    if fill:
        celula.fill = fill
    if alinhamento:
        celula.alignment = alinhamento


def _id(item: dict):
    """Nota: o número da nota no sistema; lançamento sem nota: 'L<id>'."""
    return item["nota_id"] if item.get("nota_id") else f"L{item.get('lancamento_id', '')}"


def _escrever_aba(ws, colunas: list[tuple[str, int]], linhas: list[list], texto_cols: set[int],
                  esquerda_cols: set[int]) -> int:
    """Cabeçalho, linhas e filtro. Devolve a última linha usada (no mínimo 2, para as fórmulas)."""
    for col, (titulo, largura) in enumerate(colunas, start=1):
        c = ws.cell(row=1, column=col, value=titulo)
        _estilo(c, negrito=True, cor="FFFFFF", fill=CABECALHO_FILL,
                alinhamento=Alignment(horizontal="center", vertical="center", wrap_text=True))
        ws.column_dimensions[get_column_letter(col)].width = largura
    ws.row_dimensions[1].height = 22
    for linha, valores in enumerate(linhas, start=2):
        for col, v in enumerate(valores, start=1):
            c = ws.cell(row=linha, column=col)
            if isinstance(v, str) or v is None:
                _texto(c, v)
            else:
                c.value = v
            _estilo(c, formato={1: "dd/mm/yyyy", 7: BRL}.get(col))
            c.border = BORDA
            if col == 1:
                c.alignment = Alignment(horizontal="center")
            elif col in esquerda_cols:
                c.alignment = Alignment(horizontal="left", indent=1)
            if col in texto_cols:
                c.number_format = "@"  # chave (44 dígitos) e CNPJ são texto: Excel só guarda 15 dígitos de precisão
    ultima = max(len(linhas) + 1, 2)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(colunas))}{ultima}"
    return ultima


def gerar_planilha_mensal(competencia: str, lancamentos: list[dict],
                          grupos: dict[str, dict] | None = None, receitas: list[dict] | None = None) -> bytes:
    """
    lancamentos: as DESPESAS do mês; dicts com data (date), grupo, categoria, fornecedor, cnpj, numero,
                 valor_centavos, conta, situacao, chave, arquivo, nota_id, lancamento_id.
    receitas: as receitas do mês; dicts com data, grupo, categoria, fornecedor (descrição), contato, forma,
              valor_centavos, conta, situacao, arquivo, lancamento_id.
    grupos: nome -> {"orcamento_centavos": int|None, "acumulado_centavos": int} (acumulado = todos os meses).
    """
    grupos = grupos or {}
    receitas = receitas or []
    # lançamento sem nota (nota_id None) vem depois das notas do mesmo dia
    lancamentos = sorted(lancamentos, key=lambda x: (x["data"], x["nota_id"] is None, x["nota_id"] or 0,
                                                     x.get("fornecedor") or ""))
    receitas = sorted(receitas, key=lambda x: (x["data"], x.get("lancamento_id") or 0))

    wb = Workbook()
    ws = wb.active
    ws.title = ABA
    ultima = _escrever_aba(ws, COLUNAS, [
        [n["data"], n.get("grupo") or SEM_GRUPO, n.get("categoria"), n.get("fornecedor"),
         formatar_cnpj(n.get("cnpj")), n.get("numero"), _reais(n["valor_centavos"]), n.get("conta"),
         n.get("situacao"), n.get("chave"), n.get("arquivo"), _id(n)] for n in lancamentos],
        texto_cols={5, 6, 10}, esquerda_cols={10, 11})
    wr = wb.create_sheet(ABA_RECEITAS)
    ultima_rec = _escrever_aba(wr, COLUNAS_RECEITAS, [
        [r["data"], r.get("grupo") or SEM_GRUPO, r.get("categoria"), r.get("fornecedor"), r.get("contato"),
         r.get("forma"), _reais(r["valor_centavos"]), r.get("conta"), r.get("situacao"), r.get("arquivo"), _id(r)]
        for r in receitas], texto_cols=set(), esquerda_cols={10})

    faixa = lambda col: f"{REF}!${col}$2:${col}${ultima}"  # noqa: E731
    faixa_rec = lambda col: f"{REF_RECEITAS}!${col}$2:${col}${ultima_rec}"  # noqa: E731

    # ---------------- aba Resumo ----------------
    rs = wb.create_sheet("Resumo")
    rs.sheet_view.showGridLines = False
    for col, largura in zip("ABCDEF", (34, 10, 18, 20, 20, 16)):
        rs.column_dimensions[col].width = largura

    rs["A1"] = f"Resumo de {nome_competencia(competencia)}"
    _estilo(rs["A1"], negrito=True)
    rs["A1"].font = Font(name=FONTE, size=14, bold=True)

    def cabecalho(linha: int, titulos: list[str]) -> None:
        for col, t in enumerate(titulos, start=1):
            c = rs.cell(row=linha, column=col, value=t)
            _estilo(c, negrito=True, cor="FFFFFF", fill=CABECALHO_FILL,
                    alinhamento=Alignment(horizontal="center", vertical="center", wrap_text=True))
        rs.row_dimensions[linha].height = 30

    def total(linha: int, primeira: int, ultima_linha: int, colunas: str, rotulo: str = "Total") -> None:
        for col in range(1, 7):
            _estilo(rs.cell(row=linha, column=col), negrito=True, fill=TOTAL_FILL)
        rs.cell(row=linha, column=1, value=rotulo)
        for letra in colunas:
            c = rs[f"{letra}{linha}"]
            c.value = f"=SUM({letra}{primeira}:{letra}{ultima_linha})"
            _estilo(c, negrito=True, fill=TOTAL_FILL, formato=BRL if letra == "C" else "0")

    # --- resultado do mês
    rs["A3"] = "Resultado do mês"
    _estilo(rs["A3"], negrito=True)
    for i, (rotulo, formula) in enumerate((("Receitas", f"=SUM({faixa_rec('G')})"),
                                           ("Despesas", f"=SUM({faixa('G')})"),
                                           ("Saldo do mês", "=C4-C5")), start=4):
        rs[f"A{i}"], rs[f"C{i}"] = rotulo, formula
        negrito = rotulo == "Saldo do mês"
        _estilo(rs[f"A{i}"], negrito=negrito, fill=TOTAL_FILL if negrito else None)
        _estilo(rs[f"B{i}"], fill=TOTAL_FILL if negrito else None)
        _estilo(rs[f"C{i}"], negrito=negrito, formato=BRL, fill=TOTAL_FILL if negrito else None)

    # --- despesas por grupo
    rs["A8"] = "Despesas por grupo"
    _estilo(rs["A8"], negrito=True)
    cabecalho(9, ["Grupo", "Lançamentos", "Gasto no mês", "Orçamento do grupo", "Acumulado do grupo", "% do orçamento"])
    # mês sem despesas: uma linha vazia, para o total não somar a si mesmo
    nomes_grupos = sorted({n.get("grupo") or SEM_GRUPO for n in lancamentos}, key=str.lower) or ["(nenhuma despesa no mês)"]
    linha = 10
    for nome in nomes_grupos:
        _texto(rs.cell(row=linha, column=1), nome)
        rs[f"B{linha}"] = f"=SUMPRODUCT(--({faixa('B')}=A{linha}))"
        rs[f"C{linha}"] = f"=SUMPRODUCT(({faixa('B')}=A{linha})*{faixa('G')})"
        info = grupos.get(nome, {})
        rs[f"D{linha}"] = _reais(info.get("orcamento_centavos"))
        rs[f"E{linha}"] = _reais(info.get("acumulado_centavos"))
        rs[f"F{linha}"] = f'=IF(AND(ISNUMBER(D{linha}),D{linha}>0,ISNUMBER(E{linha})),E{linha}/D{linha},"")'
        _estilo(rs[f"A{linha}"])
        _estilo(rs[f"B{linha}"], formato="0")
        _estilo(rs[f"C{linha}"], formato=BRL)
        _estilo(rs[f"D{linha}"], cor="0000FF", formato=BRL)   # azul = valor vindo do cadastro do grupo
        _estilo(rs[f"E{linha}"], cor="0000FF", formato=BRL)   # azul = valor vindo do banco (todos os meses)
        _estilo(rs[f"F{linha}"], formato="0.0%")
        linha += 1
    ev_ini, ev_fim = 10, max(linha - 1, 10)
    total(linha, ev_ini, ev_fim, "BC")
    linha_total_grupos = linha

    # --- por categoria
    linha += 2
    rs[f"A{linha}"] = "Despesas por categoria"
    _estilo(rs[f"A{linha}"], negrito=True)
    linha += 1
    cabecalho(linha, ["Categoria", "Lançamentos", "Gasto no mês"])
    linha += 1
    cat_ini = linha
    for nome in sorted({n.get("categoria") or "(sem categoria)" for n in lancamentos}, key=str.lower) or ["(nenhuma despesa no mês)"]:
        _texto(rs.cell(row=linha, column=1), nome)
        rs[f"B{linha}"] = f"=SUMPRODUCT(--({faixa('C')}=A{linha}))"
        rs[f"C{linha}"] = f"=SUMPRODUCT(({faixa('C')}=A{linha})*{faixa('G')})"
        _estilo(rs[f"A{linha}"])
        _estilo(rs[f"B{linha}"], formato="0")
        _estilo(rs[f"C{linha}"], formato=BRL)
        linha += 1
    cat_fim = max(linha - 1, cat_ini)
    total(linha, cat_ini, cat_fim, "BC")
    linha_total_cat = linha

    # --- receitas por categoria
    linha += 2
    rs[f"A{linha}"] = "Receitas por categoria"
    _estilo(rs[f"A{linha}"], negrito=True)
    linha += 1
    cabecalho(linha, ["Categoria", "Lançamentos", "Recebido no mês"])
    linha += 1
    rec_ini = linha
    for nome in sorted({r.get("categoria") or "(sem categoria)" for r in receitas}, key=str.lower) or ["(nenhuma receita no mês)"]:
        _texto(rs.cell(row=linha, column=1), nome)
        rs[f"B{linha}"] = f"=SUMPRODUCT(--({faixa_rec('C')}=A{linha}))"
        rs[f"C{linha}"] = f"=SUMPRODUCT(({faixa_rec('C')}=A{linha})*{faixa_rec('G')})"
        _estilo(rs[f"A{linha}"])
        _estilo(rs[f"B{linha}"], formato="0")
        _estilo(rs[f"C{linha}"], formato=BRL)
        linha += 1
    total(linha, rec_ini, max(linha - 1, rec_ini), "BC", rotulo="Total das receitas")

    # --- conferência e notas
    linha += 2
    rs[f"A{linha}"] = "Conferência das despesas (grupos = categorias = aba Despesas)"
    rs[f"C{linha}"] = (f'=IF(AND(ROUND(C{linha_total_grupos}-C{linha_total_cat},2)=0,'
                       f'ROUND(C{linha_total_grupos}-SUM({faixa("G")}),2)=0),"OK","DIVERGENTE")')
    _estilo(rs[f"A{linha}"], negrito=True)
    _estilo(rs[f"C{linha}"], negrito=True, alinhamento=Alignment(horizontal="center"))
    linha += 2
    notas = [
        "Valores em azul não são fórmulas: Orçamento vem do cadastro do grupo; Acumulado soma todos os meses",
        "lançados no sistema para o grupo. Notas ainda não arquivadas e lançamentos cancelados não entram nesta planilha.",
    ]
    for texto in notas:
        rs[f"A{linha}"] = texto
        _estilo(rs[f"A{linha}"], cor="595959")
        linha += 1

    wb.move_sheet(rs, offset=-2)   # Resumo primeiro: é o que se lê antes
    wb.active = 0
    for planilha in (ws, wr, rs):  # impressão: paisagem, uma página de largura
        planilha.page_setup.orientation = "landscape"
        planilha.page_setup.fitToWidth = 1
        planilha.page_setup.fitToHeight = 0
        planilha.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)

    wb.calculation.fullCalcOnLoad = True  # o Excel recalcula as fórmulas ao abrir
    saida = io.BytesIO()
    wb.save(saida)
    return saida.getvalue()
