"""Conversões de dinheiro. Internamente tudo é inteiro em centavos (sem erro de ponto flutuante)."""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation


def para_centavos(valor) -> int | None:
    """Converte número ou texto ('1.234,56', 'R$ 12,50', 12.5) para centavos. Retorna None se inválido."""
    if valor is None or isinstance(valor, bool):
        return None
    try:
        if isinstance(valor, (int, float, Decimal)):
            d = Decimal(str(valor))
        else:
            s = str(valor).strip().replace("R$", "").replace(" ", "")
            if not s:
                return None
            if "," in s:  # formato brasileiro: ponto = milhar, vírgula = decimal
                s = s.replace(".", "").replace(",", ".")
            d = Decimal(s)
    except InvalidOperation:
        return None
    if not d.is_finite():
        return None
    return int((d * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def centavos_para_decimal(centavos: int | None) -> Decimal | None:
    if centavos is None:
        return None
    return (Decimal(centavos) / 100).quantize(Decimal("0.01"))


def formatar_brl(centavos: int | None) -> str:
    if centavos is None:
        return "—"
    sinal = "-" if centavos < 0 else ""
    reais, cent = divmod(abs(centavos), 100)
    return f"{sinal}R$ {reais:,}".replace(",", ".") + f",{cent:02d}"
