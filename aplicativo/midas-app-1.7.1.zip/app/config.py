"""Configuração por variáveis de ambiente (todas opcionais, com padrões para rodar localmente)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

CHAVES_ESTRUTURA = {"grupo", "competencia", "categoria"}


@dataclass(frozen=True)
class Config:
    dados_dir: Path
    db_path: Path
    armazenamento: str          # "local" (padrão); "drive" fica para o próximo módulo
    estrutura_pastas: str       # ex.: "{grupo}/{competencia}" ou "{competencia}/{grupo}"
    modelo_claude: str
    anthropic_api_key: str | None
    api_token: str | None       # se definido, a API exige o cabeçalho X-API-Token
    max_upload_mb: int
    leitor_foto: str = "auto"   # auto: Claude se houver chave, senão OCR local | local: só OCR local | claude: só Claude

    def __post_init__(self) -> None:
        if self.leitor_foto not in ("auto", "local", "claude"):
            raise ValueError("NF_LEITOR deve ser auto, local ou claude")
        try:
            self.estrutura_pastas.format_map({k: "x" for k in CHAVES_ESTRUTURA})
        except KeyError as e:
            raise ValueError(
                f"NF_ESTRUTURA_PASTAS usa a chave {e}; permitidas: {sorted(CHAVES_ESTRUTURA)}"
            ) from e


def carregar_dotenv(caminho: Path | None = None) -> None:
    """Lê o arquivo .env (CHAVE=valor) sem sobrescrever variáveis já definidas no ambiente."""
    caminho = caminho or Path(__file__).resolve().parent.parent / ".env"
    try:
        linhas = caminho.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for linha in linhas:
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, valor = linha.split("=", 1)
        valor = valor.strip()
        if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in "\"'":
            valor = valor[1:-1]
        elif " #" in valor:
            valor = valor.split(" #", 1)[0].rstrip()
        if valor:
            os.environ.setdefault(chave.strip(), valor)


def carregar_config() -> Config:
    carregar_dotenv()
    base = Path(os.getenv("NF_DADOS_DIR") or Path(__file__).resolve().parent.parent / "dados")
    return Config(
        dados_dir=base,
        db_path=Path(os.getenv("NF_DB_PATH") or base / "notas.db"),
        armazenamento=os.getenv("NF_ARMAZENAMENTO", "local"),
        estrutura_pastas=os.getenv("NF_ESTRUTURA_PASTAS", "{grupo}/{competencia}").replace("{evento}", "{grupo}"),  # aceita o nome antigo
        modelo_claude=os.getenv("NF_MODELO_CLAUDE", "claude-sonnet-5-5"),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY") or None,
        api_token=os.getenv("NF_API_TOKEN") or None,
        max_upload_mb=int(os.getenv("NF_MAX_UPLOAD_MB", "15")),
        leitor_foto=(os.getenv("NF_LEITOR") or "auto").strip().lower(),
    )
