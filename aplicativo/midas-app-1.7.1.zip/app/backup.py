"""Cópias de segurança do banco.

A cópia usa a API de backup do próprio SQLite: sai consistente mesmo com o Midas aberto (modo WAL), sem travar
ninguém. Ficam em dados/backups:
  notas-AAAAMMDD-HHMMSS-diario.db          uma por dia, ao abrir o Midas (guarda as 7 mais recentes)
  notas-AAAAMMDD-HHMMSS-antes-v<N>.db      antes de cada atualização da estrutura do banco (guarda as 5 mais recentes)
  notas-AAAAMMDD-HHMMSS-antes-restaurar.db antes de restaurar uma cópia (guarda as 5 mais recentes)
Para voltar a uma cópia: feche o Midas e use `restaurar` (ou copie o arquivo por cima de dados/notas.db).
"""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime
from pathlib import Path

GUARDAR = {"diario": 7, "antes": 5}
_RE_NOME = re.compile(r"^notas-(\d{8})-(\d{6})-(diario|antes-[\w-]+)\.db$")


def _tipo(motivo: str) -> str:
    return "diario" if motivo == "diario" else "antes"


def listar(pasta: Path) -> list[Path]:
    """Cópias existentes, da mais nova para a mais antiga."""
    if not pasta.is_dir():
        return []
    return sorted((p for p in pasta.iterdir() if _RE_NOME.match(p.name)), key=lambda p: p.name, reverse=True)


def fazer(banco: Path, pasta: Path, motivo: str, agora: datetime | None = None) -> Path | None:
    """Copia o banco para a pasta de backups. Banco ainda inexistente ou vazio: não há o que copiar (None)."""
    if not banco.exists() or banco.stat().st_size == 0:
        return None
    agora = agora or datetime.now()
    pasta.mkdir(parents=True, exist_ok=True)
    destino = pasta / f"notas-{agora:%Y%m%d-%H%M%S}-{motivo}.db"
    origem = sqlite3.connect(banco)
    copia = sqlite3.connect(destino)
    try:
        with copia:
            origem.backup(copia)
    finally:
        copia.close()
        origem.close()
    _podar(pasta, _tipo(motivo))
    return destino


def diario(banco: Path, pasta: Path, agora: datetime | None = None) -> Path | None:
    """Uma cópia por dia: só faz se ainda não houver a de hoje."""
    agora = agora or datetime.now()
    hoje = f"{agora:%Y%m%d}"
    if any(_RE_NOME.match(p.name).group(1) == hoje and p.name.endswith("-diario.db") for p in listar(pasta)):
        return None
    return fazer(banco, pasta, "diario", agora)


def restaurar(copia: Path, banco: Path, pasta: Path) -> Path | None:
    """Põe uma cópia no lugar do banco atual (com o Midas fechado). O banco atual vira uma cópia antes, por garantia."""
    if not _RE_NOME.match(copia.name) or not copia.is_file():
        raise ValueError(f"{copia} não é uma cópia de segurança do Midas.")
    seguranca = fazer(banco, pasta, "antes-restaurar")
    origem = sqlite3.connect(copia)
    destino = sqlite3.connect(banco)
    try:
        with destino:
            origem.backup(destino)
    finally:
        destino.close()
        origem.close()
    return seguranca


def _podar(pasta: Path, tipo: str) -> None:
    mesmas = [p for p in listar(pasta) if _tipo(_RE_NOME.match(p.name).group(3)) == tipo]
    for velha in mesmas[GUARDAR[tipo]:]:
        velha.unlink(missing_ok=True)


def _menu(banco: Path, pasta: Path) -> int:
    """Uso pelo Restaurar_backup.bat: lista as cópias e restaura a escolhida (com o Midas fechado)."""
    copias = listar(pasta)
    if not copias:
        print("Nenhuma cópia de segurança encontrada em", pasta)
        return 1
    print("Cópias de segurança (a mais nova primeiro):\n")
    for n, p in enumerate(copias, start=1):
        m = _RE_NOME.match(p.name)
        quando = datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        tipo = "diária" if m.group(3) == "diario" else m.group(3).replace("antes-", "antes de ").replace("-", " ")
        print(f"  {n:2d}. {quando:%d/%m/%Y %H:%M}  ({tipo})")
    escolha = input("\nNúmero da cópia para restaurar (Enter cancela): ").strip()
    if not escolha.isdigit() or not 1 <= int(escolha) <= len(copias):
        print("Nada foi alterado.")
        return 0
    seguranca = restaurar(copias[int(escolha) - 1], banco, pasta)
    print("\nPronto. Os dados voltaram para a cópia escolhida.")
    if seguranca:
        print("O estado anterior foi guardado em", seguranca.name)
    return 0


if __name__ == "__main__":
    import os
    import sys

    raiz = Path(__file__).resolve().parent.parent
    dados = Path(os.getenv("NF_DADOS_DIR") or raiz / "dados")
    sys.exit(_menu(Path(os.getenv("NF_DB_PATH") or dados / "notas.db"), dados / "backups"))
