"""Validações de uma nota. 'erro' bloqueia a validação final; 'aviso' só pede atenção na conferência."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, timedelta
from itertools import cycle

from .dinheiro import formatar_brl

TOLERANCIA_SOMA_CENTAVOS = 5
IDADE_MAXIMA_DIAS = 400


@dataclass(frozen=True)
class Aviso:
    campo: str
    nivel: str      # "erro" | "aviso"
    mensagem: str


def _valor(caractere: str) -> int:
    return ord(caractere) - 48  # '0'-'9' -> 0-9; 'A' -> 17... (regra do CNPJ alfanumérico)


def dv_modulo11(base: str) -> int:
    """Dígito verificador módulo 11 com pesos 2..9 da direita para a esquerda (CNPJ e chave de acesso)."""
    soma = sum(_valor(c) * peso for c, peso in zip(reversed(base), cycle(range(2, 10))))
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def cnpj_valido(cnpj: str | None) -> bool:
    if not cnpj or not re.fullmatch(r"[0-9A-Z]{12}[0-9]{2}", cnpj):
        return False
    if len(set(cnpj)) == 1:
        return False
    dv1 = dv_modulo11(cnpj[:12])
    dv2 = dv_modulo11(cnpj[:12] + str(dv1))
    return cnpj[12:] == f"{dv1}{dv2}"


def chave_dv_valido(chave: str) -> bool:
    return chave[43] == str(dv_modulo11(chave[:43]))


def validar(nota: dict, itens: list[dict], confianca: dict[str, str] | None = None,
            duplicatas: list[int] | None = None, hoje: date | None = None) -> list[Aviso]:
    """`nota` usa as colunas do banco (valor_total_centavos, data_emissao como date ou ISO, etc.)."""
    hoje = hoje or date.today()
    avisos: list[Aviso] = []
    add = lambda campo, nivel, msg: avisos.append(Aviso(campo, nivel, msg))  # noqa: E731

    # --- campos obrigatórios --------------------------------------------------------------
    if not (nota.get("fornecedor") or "").strip():
        add("fornecedor", "erro", "Fornecedor não identificado.")

    emissao = nota.get("data_emissao")
    if isinstance(emissao, str):
        try:
            emissao = date.fromisoformat(emissao)
        except ValueError:
            emissao = None
    if emissao is None:
        add("data_emissao", "erro", "Data de emissão não identificada.")
    elif emissao > hoje:
        add("data_emissao", "erro", f"Data de emissão no futuro ({emissao:%d/%m/%Y}); provável erro de leitura.")
    elif emissao < hoje - timedelta(days=IDADE_MAXIMA_DIAS):
        add("data_emissao", "aviso", f"Nota antiga ({emissao:%d/%m/%Y}); confirme a data.")

    total = nota.get("valor_total_centavos")
    if total is None or total <= 0:
        add("valor_total", "erro", "Valor total não identificado ou inválido.")

    if nota.get("tipo_documento") == "pedido_ou_comprovante":
        add("tipo_documento", "aviso",
            "Este arquivo parece um pedido/comprovante de compra, não a nota fiscal. Confira os dados e, "
            "se puder, anexe a nota fiscal (XML ou DANFE) desta compra.")

    # --- CNPJ -----------------------------------------------------------------------------
    cnpj = nota.get("cnpj")
    if not cnpj:
        add("cnpj", "aviso", "CNPJ do fornecedor não identificado.")
    elif len(cnpj) == 14 and not cnpj_valido(cnpj):
        add("cnpj", "aviso", "CNPJ com dígito verificador inválido; confira com a nota.")
    elif len(cnpj) not in (11, 14):
        add("cnpj", "aviso", f"CNPJ com {len(cnpj)} caracteres; esperado 14.")

    # --- chave de acesso ------------------------------------------------------------------
    chave = nota.get("chave_acesso")
    if not chave:
        add("chave_acesso", "aviso",
            "Sem chave de acesso: a checagem de duplicidade fica limitada (fornecedor, data e valor).")
    elif len(chave) != 44 or not re.fullmatch(r"[0-9A-Z]{44}", chave):
        add("chave_acesso", "aviso", "Chave de acesso fora do padrão de 44 caracteres.")
    else:
        if not chave_dv_valido(chave):
            add("chave_acesso", "aviso", "Dígito verificador da chave não confere; provável erro de leitura.")
        if cnpj and len(cnpj) == 14 and chave[6:20] != cnpj:
            add("chave_acesso", "aviso", "O CNPJ embutido na chave difere do CNPJ informado.")
        if emissao and chave[2:6] != f"{emissao:%y%m}":
            add("chave_acesso", "aviso", "O mês/ano embutido na chave difere da data de emissão.")
        numero = nota.get("numero")
        if numero and numero.isdigit() and int(chave[25:34]) != int(numero):
            add("numero", "aviso", "O número da nota difere do número embutido na chave.")

    # --- soma dos itens x total -----------------------------------------------------------
    valores = [i.get("valor_total_centavos") for i in itens]
    if itens and total and all(v is not None for v in valores):
        soma = sum(valores)
        if abs(soma - total) > TOLERANCIA_SOMA_CENTAVOS:
            add("itens", "aviso",
                f"A soma dos itens ({formatar_brl(soma)}) difere do total ({formatar_brl(total)}); "
                "pode haver desconto/frete ou erro de leitura.")

    # --- confiança da leitura -------------------------------------------------------------
    for campo, nivel in (confianca or {}).items():
        if nivel == "baixa":
            add(campo, "aviso", "Leitura com baixa confiança; confira na imagem.")

    # --- duplicidade por heurística -------------------------------------------------------
    if duplicatas:
        ids = ", ".join(f"#{i}" for i in duplicatas)
        add("duplicidade", "aviso", f"Possível duplicata de {ids} (mesmo fornecedor, data e valor).")

    return avisos
