"""Leitura de foto/PDF escaneado SEM internet e SEM chave: OCR local (RapidOCR sobre ONNX) + regras de texto.

O OCR roda no próprio computador. Uma única passada erra linhas em papel torto (cupom de caixa fotografado de mão),
então a leitura usa duas configurações de detecção e junta o melhor de cada uma. Quando a primeira já fecha
(CNPJ válido, data, total e itens que somam o total), a segunda é pulada: não teria o que acrescentar.
"""
from __future__ import annotations

import io
import os
import threading
import time

from .base import ErroExtracao, Extracao
from .claude_vision import preparar_imagem
from ..validation import TOLERANCIA_SOMA_CENTAVOS, cnpj_valido
from .texto_nota import Linha, interpretar

# (nome, parâmetros do RapidOCR). A 1ª separa melhor linhas inclinadas e lê cabeçalhos de cupom (CNPJ);
# a 2ª é o padrão do RapidOCR e preserva melhor os espaços das descrições.
CONFIGURACOES = (
    ("estreita", dict(det_unclip_ratio=1.0, det_thresh=0.3, det_box_thresh=0.4, text_score=0.3)),
    ("padrao", dict(text_score=0.3)),
)
MAX_PAGINAS_ESCANEADAS = 1
LADO_MAXIMO_OCR_PX = 1600   # foto de celular (4000 px) não lê melhor que isso e custa o dobro


def disponivel() -> bool:
    """True se o OCR local está instalado (no pacote Windows ele vem junto)."""
    try:
        import cv2  # noqa: F401
        import numpy  # noqa: F401
        import rapidocr_onnxruntime  # noqa: F401
    except Exception:
        return False
    return True


def _imagem_do_pdf(conteudo: bytes) -> bytes:
    """PDF escaneado: pega a maior imagem da primeira página (o PDF só embrulha a foto)."""
    try:
        from pypdf import PdfReader

        leitor = PdfReader(io.BytesIO(conteudo))
        imagens = [im for pg in leitor.pages[:MAX_PAGINAS_ESCANEADAS] for im in pg.images]
        if not imagens:
            raise ErroExtracao("Este PDF não tem imagem nem texto que eu consiga ler.")
        return max(imagens, key=lambda im: len(im.data)).data
    except ErroExtracao:
        raise
    except Exception as e:
        raise ErroExtracao("Não consegui abrir este PDF para ler a imagem.") from e


def _mesclar(a: Extracao, b: Extracao) -> Extracao:
    """Junta duas leituras da mesma foto: a de `a` vale; o que faltou nela vem de `b`."""
    campos = a.model_dump()
    for k, v in b.model_dump().items():
        if campos.get(k) in (None, [], {}) and v not in (None, [], {}):
            campos[k] = v
            if k in b.confianca:
                campos["confianca"] = {**campos["confianca"], k: b.confianca[k]}
            if k in b.regioes and k not in campos["regioes"]:
                campos["regioes"] = {**campos["regioes"], k: b.regioes[k]}
    if a.itens and b.itens and len(a.itens) == len(b.itens) \
            and [i.valor_total_centavos for i in a.itens] == [i.valor_total_centavos for i in b.itens]:
        # mesmos valores: fica a descrição com mais espaços (o OCR 'estreito' às vezes cola as palavras)
        campos["itens"] = [(ia if ia.descricao.count(" ") >= ib.descricao.count(" ") else ib).model_dump()
                           for ia, ib in zip(a.itens, b.itens)]
    return Extracao(**campos)


def fecha(ext: Extracao) -> bool:
    """A leitura está completa e as conferências batem: outra passada não tem o que acrescentar."""
    if not (ext.fornecedor and ext.cnpj and len(ext.cnpj) == 14 and cnpj_valido(ext.cnpj)):
        return False
    if not (ext.data_emissao and ext.valor_total_centavos and ext.itens):
        return False
    totais = [i.valor_total_centavos for i in ext.itens]
    return all(t is not None for t in totais) and abs(sum(totais) - ext.valor_total_centavos) <= TOLERANCIA_SOMA_CENTAVOS


class LeitorLocal:
    def __init__(self):
        self._motores: dict[str, object] = {}
        self._trava = threading.Lock()  # o OCR usa bastante CPU: uma foto por vez evita travar o computador

    def _motor(self, nome: str, parametros: dict):
        if nome not in self._motores:
            from rapidocr_onnxruntime import RapidOCR

            self._motores[nome] = RapidOCR(**parametros)
        return self._motores[nome]

    def aquecer(self) -> None:
        """Carrega os modelos e faz uma leitura em branco (o ONNX otimiza na primeira execução). Chamado em segundo
        plano ao abrir o Midas, para a primeira foto não pagar esse custo. Se uma foto chegar antes, ela espera."""
        import numpy as np

        inicio = time.perf_counter()
        branco = np.full((64, 256, 3), 255, dtype=np.uint8)
        with self._trava:
            for nome, parametros in CONFIGURACOES:
                self._motor(nome, parametros)(branco)
        try:
            import onnxruntime
            versao = onnxruntime.__version__
        except Exception:
            versao = "?"
        print(f"[leitor] pronto em {time.perf_counter() - inicio:.1f} s · {os.cpu_count()} processadores · "
              f"onnxruntime {versao}", flush=True)

    def _linhas(self, imagem, nome: str, parametros: dict) -> list[Linha]:
        resultado, _ = self._motor(nome, parametros)(imagem)
        alt, larg = imagem.shape[:2]
        linhas = []
        for caixa, t, s in (resultado or []):
            xs, ys = [p[0] for p in caixa], [p[1] for p in caixa]
            linhas.append(Linha(texto=t, y=sum(ys) / 4, x=min(xs), score=float(s),
                                caixa=(round(min(xs) / larg, 4), round(min(ys) / alt, 4),
                                       round(max(xs) / larg, 4), round(max(ys) / alt, 4))))
        return linhas

    def extrair(self, conteudo: bytes, tipo: str) -> Extracao:
        """`tipo` é 'pdf' ou 'imagem'."""
        import numpy as np
        from PIL import Image

        inicio = time.perf_counter()
        if tipo == "pdf":
            conteudo = _imagem_do_pdf(conteudo)
        jpeg, _ = preparar_imagem(conteudo)
        foto = Image.open(io.BytesIO(jpeg)).convert("RGB")
        foto.thumbnail((LADO_MAXIMO_OCR_PX, LADO_MAXIMO_OCR_PX))
        imagem = np.array(foto)
        etapas = [f"preparo {time.perf_counter() - inicio:.1f}"]

        melhor: Extracao | None = None
        ultimo_erro: ErroExtracao | None = None
        espera = time.perf_counter()
        with self._trava:
            if time.perf_counter() - espera > 0.5:   # outra foto estava sendo lida
                etapas.append(f"fila {time.perf_counter() - espera:.1f}")
            for nome, parametros in CONFIGURACOES:
                t = time.perf_counter()
                try:
                    lido = interpretar(self._linhas(imagem, nome, parametros))
                except ErroExtracao as e:
                    ultimo_erro = e
                    continue
                finally:
                    etapas.append(f"{nome} {time.perf_counter() - t:.1f}")
                melhor = lido if melhor is None else _mesclar(melhor, lido)
                if fecha(melhor):
                    break
        print(f"[leitor] {imagem.shape[1]}x{imagem.shape[0]} px · " + " · ".join(etapas) + " s", flush=True)
        if melhor is None:
            raise ultimo_erro or ErroExtracao("Não consegui ler texto nesta imagem.")
        return melhor
