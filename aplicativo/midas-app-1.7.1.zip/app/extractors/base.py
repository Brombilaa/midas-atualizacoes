"""Modelo comum de extração: tanto o XML quanto a leitura por foto/PDF devolvem uma `Extracao`."""
from __future__ import annotations

import re
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field


class ErroExtracao(Exception):
    """O arquivo não pôde ser lido como nota fiscal."""


class ItemExtraido(BaseModel):
    descricao: str
    quantidade: float | None = None
    valor_unitario_centavos: int | None = None
    valor_total_centavos: int | None = None


FORMAS_PAGAMENTO = ("pix", "dinheiro", "debito", "credito", "boleto", "transferencia", "outro")


class Extracao(BaseModel):
    origem: Literal["xml", "pdf", "claude", "ocr", "manual"]
    fornecedor: str | None = None
    cnpj: str | None = None
    numero: str | None = None
    serie: str | None = None
    data_emissao: date | None = None
    valor_total_centavos: int | None = None
    chave_acesso: str | None = None
    itens: list[ItemExtraido] = Field(default_factory=list)
    confianca: dict[str, str] = Field(default_factory=dict)  # campo -> alta | media | baixa
    observacoes: str | None = None
    # nfe_danfe | nfce_cupom | nfse_servico | pedido_ou_comprovante | outro (só na leitura por foto/PDF)
    tipo_documento: str | None = None
    regioes: dict[str, list[float]] = Field(default_factory=dict)  # campo -> [x0,y0,x1,y1] na imagem (0 a 1)
    forma_pagamento: str | None = None    # uma de FORMAS_PAGAMENTO, quando o documento informa
    destinatario_cnpj: str | None = None  # só para conferência; não é gravado


def normalizar_documento(texto: str | None) -> str | None:
    """CNPJ/CPF/chave: só letras e dígitos, maiúsculas (o CNPJ pode ser alfanumérico desde jul/2026)."""
    if not texto:
        return None
    limpo = re.sub(r"[^0-9A-Za-z]", "", texto).upper()
    return limpo or None
