"""Leitura sem IA do que um DANFE digital (PDF com texto) traz de forma padronizada, e conferência da leitura
do Claude contra a chave de acesso, que é o único dado impresso com dígitos verificadores.

A chave de acesso (44 posições) carrega: UF(2) AAMM(4) CNPJ do EMITENTE(14) modelo(2) série(3) número(9)
tipo de emissão(1) código(8) DV(1). Por isso ela corrige CNPJ, número e série lidos errado, inclusive o erro
clássico de pegar o CNPJ do destinatário (que, para quem compra, é a própria associação)."""
from __future__ import annotations

import io
import re
from datetime import date

from ..dinheiro import para_centavos
from ..validation import chave_dv_valido
from .base import Extracao, normalizar_documento

MAX_PAGINAS = 3
MAX_CARACTERES = 12000
_RE_CHAVE = re.compile(r"(?<![0-9A-Za-z])(?:[0-9A-Za-z]{4}[ \t]?){10}[0-9A-Za-z]{4}(?![0-9A-Za-z])")
_RE_VALOR = r"(\d{1,3}(?:\.\d{3})*,\d{2})"


def texto_do_pdf(conteudo: bytes) -> str:
    """Texto embutido no PDF ('' se for digitalização/foto, protegido ou ilegível). Nunca levanta erro."""
    try:
        from pypdf import PdfReader

        leitor = PdfReader(io.BytesIO(conteudo))
        partes = [(pg.extract_text() or "") for pg in leitor.pages[:MAX_PAGINAS]]
    except Exception:
        return ""
    return "\n".join(partes).strip()[:MAX_CARACTERES]


def chave_valida(chave: str | None) -> bool:
    return bool(chave) and len(chave) == 44 and chave[:6].isdigit() and chave[20:].isdigit() \
        and chave[6:20].isalnum() and chave[20:22] in ("55", "65") and chave_dv_valido(chave)


def decompor_chave(chave: str) -> dict:
    return {"uf": chave[:2], "aamm": chave[2:6], "cnpj": chave[6:20], "modelo": chave[20:22],
            "serie": str(int(chave[22:25])), "numero": str(int(chave[25:34]))}


def achar_chave_no_texto(texto: str) -> str | None:
    for m in _RE_CHAVE.finditer(texto or ""):
        candidata = normalizar_documento(m.group())
        if candidata and chave_valida(candidata):
            return candidata
    return None


def _sem_zeros(valor: str | None) -> str | None:
    """'000.000.203' -> '203', '010' -> '10' (como o XML traz)."""
    if valor is None:
        return None
    s = str(valor).strip()
    so_digitos = re.sub(r"[.\s]", "", s)
    return (so_digitos.lstrip("0") or "0") if so_digitos.isdigit() else (s or None)


def _data(dia: str, mes: str, ano: str) -> date | None:
    try:
        return date(int(ano), int(mes), int(dia))
    except ValueError:
        return None


def ler_danfe_digital(texto: str) -> Extracao | None:
    """Lê o canhoto padrão do DANFE ('Recebemos de ... Emissão ... Valor Total ...') e a chave.
    Devolve None se não houver chave válida no texto (então não é um DANFE digital que a gente entenda)."""
    chave = achar_chave_no_texto(texto)
    if not chave:
        return None
    dec = decompor_chave(chave)
    plano = re.sub(r"\s+", " ", texto)
    conf: dict[str, str] = {"chave_acesso": "alta", "cnpj": "alta"}
    obs: list[str] = []

    fornecedor = None
    m = re.search(r"Recebemos de (.+?) os produtos e/ou servi", plano)
    if m:
        fornecedor = m.group(1).strip()
        conf["fornecedor"] = "alta" if plano.count(fornecedor) >= 2 else "media"

    data_emissao = None
    m = re.search(r"Emiss[ãa]o:\s*(\d{2})/(\d{2})/(\d{4})", plano)
    if m:
        data_emissao = _data(m.group(1), m.group(2), m.group(3))
        if data_emissao and f"{data_emissao:%y%m}" == dec["aamm"]:
            conf["data_emissao"] = "alta"
        else:
            conf["data_emissao"] = "baixa"
            obs.append("A data do canhoto não bate com o mês da chave de acesso; confira.")

    valor = None
    m = re.search(r"Valor Total:\s*" + _RE_VALOR, plano)
    m2 = re.search(r"VALOR TOTAL DA NOTA\s*" + _RE_VALOR, plano)
    v1 = para_centavos(m.group(1).replace(".", "").replace(",", ".")) if m else None
    v2 = para_centavos(m2.group(1).replace(".", "").replace(",", ".")) if m2 else None
    if v1 is not None and v2 is not None:
        valor, conf["valor_total"] = (v2, "alta") if v1 == v2 else (v2, "baixa")
        if v1 != v2:
            obs.append("O valor do canhoto e o 'Valor total da nota' são diferentes; confira.")
    elif v1 is not None or v2 is not None:
        valor, conf["valor_total"] = (v2 if v2 is not None else v1), "media"

    return Extracao(
        origem="pdf", fornecedor=fornecedor, cnpj=dec["cnpj"], numero=dec["numero"], serie=dec["serie"],
        data_emissao=data_emissao, valor_total_centavos=valor, chave_acesso=chave, confianca=conf,
        observacoes=" ".join(obs) or None)


def reconciliar(ext: Extracao, texto_pdf: str = "") -> Extracao:
    """Confere e corrige a leitura do Claude usando a chave de acesso (e o texto do PDF, se houver)."""
    conf = dict(ext.confianca)
    obs = [ext.observacoes] if ext.observacoes else []
    campos = ext.model_dump()

    # 1) chave: a do texto do PDF vale mais que a lida por visão
    chave = ext.chave_acesso if chave_valida(ext.chave_acesso) else None
    do_texto = achar_chave_no_texto(texto_pdf)
    if do_texto and do_texto != chave:
        if ext.chave_acesso and not chave:
            obs.append("Chave de acesso corrigida pelo texto do PDF.")
        chave = do_texto
    if chave:
        campos["chave_acesso"] = chave
        conf["chave_acesso"] = "alta"

    # 2) número, série e CNPJ do emitente vêm da chave
    if chave:
        dec = decompor_chave(chave)
        if ext.cnpj and ext.cnpj != dec["cnpj"]:
            if ext.destinatario_cnpj and ext.cnpj == ext.destinatario_cnpj:
                obs.append("O CNPJ lido era o do destinatário; usado o do emitente, conforme a chave de acesso.")
            else:
                obs.append(f"CNPJ lido ({ext.cnpj}) corrigido pelo da chave de acesso.")
        campos["cnpj"], conf["cnpj"] = dec["cnpj"], "alta"
        lido = _sem_zeros(ext.numero)
        if lido and lido != dec["numero"]:
            obs.append(f"Número lido ({lido}) corrigido pelo da chave de acesso.")
        campos["numero"], campos["serie"] = dec["numero"], dec["serie"]

        # 3) data com dia e mês trocados (02/10 lido como 10/02): a chave informa o mês correto
        d = ext.data_emissao
        if d and f"{d:%y%m}" != dec["aamm"]:
            trocada = _data(str(d.month), str(d.day), str(d.year))
            if trocada and f"{trocada:%y%m}" == dec["aamm"]:
                campos["data_emissao"], conf["data_emissao"] = trocada, "media"
                obs.append(f"Data lida como {d:%d/%m/%Y}; ajustada para {trocada:%d/%m/%Y} pelo mês da chave.")
    else:
        campos["numero"], campos["serie"] = _sem_zeros(ext.numero), _sem_zeros(ext.serie)
        if ext.destinatario_cnpj and ext.cnpj == ext.destinatario_cnpj:
            campos["cnpj"], conf["cnpj"] = None, "baixa"
            obs.append("O CNPJ lido é o do destinatário (o comprador), não o do fornecedor; preencha o do emitente.")

    campos["confianca"], campos["observacoes"] = conf, " ".join(obs) or None
    return Extracao(**campos)
