"""Leitura do XML de NF-e (modelo 55) e NFC-e (modelo 65). Dados estruturados: confiança máxima."""
from __future__ import annotations

from datetime import date

from defusedxml import ElementTree as ET
from defusedxml.common import DefusedXmlException

from ..dinheiro import para_centavos
from .base import ErroExtracao, Extracao, ItemExtraido, normalizar_documento

CAMPOS = ("fornecedor", "cnpj", "data_emissao", "valor_total", "itens", "chave_acesso")


def _sem_namespace(raiz) -> None:
    for el in raiz.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]


def _txt(el, caminho: str) -> str | None:
    if el is None:
        return None
    achado = el.find(caminho)
    if achado is None or achado.text is None:
        return None
    texto = achado.text.strip()
    return texto or None


def _numero(texto: str | None) -> float | None:
    try:
        return float(texto) if texto is not None else None
    except ValueError:
        return None


def extrair_xml(conteudo: bytes) -> Extracao:
    try:
        raiz = ET.fromstring(conteudo)
    except (ET.ParseError, DefusedXmlException) as e:
        raise ErroExtracao("XML inválido ou malformado.") from e

    _sem_namespace(raiz)
    inf = raiz if raiz.tag == "infNFe" else raiz.find(".//infNFe")
    if inf is None:
        raise ErroExtracao("O XML não é de uma NF-e/NFC-e (elemento infNFe não encontrado).")

    ide, emit = inf.find("ide"), inf.find("emit")

    chave = (inf.get("Id") or "").removeprefix("NFe") or _txt(raiz, ".//protNFe/infProt/chNFe")

    emissao = _txt(ide, "dhEmi") or _txt(ide, "dEmi")  # dhEmi: "2026-10-12T14:33:10-03:00"
    data_emissao = None
    if emissao:
        try:
            data_emissao = date.fromisoformat(emissao[:10])
        except ValueError:
            data_emissao = None

    itens = []
    for det in inf.findall("det"):
        prod = det.find("prod")
        if prod is None:
            continue
        itens.append(ItemExtraido(
            descricao=_txt(prod, "xProd") or "(sem descrição)",
            quantidade=_numero(_txt(prod, "qCom")),
            valor_unitario_centavos=para_centavos(_txt(prod, "vUnCom")),
            valor_total_centavos=para_centavos(_txt(prod, "vProd")),
        ))

    # meio de pagamento (tPag do primeiro detPag); 90 = sem pagamento
    tpag = _txt(inf, "pag/detPag/tPag") or _txt(inf, "pag/tPag")
    forma = {"01": "dinheiro", "02": "outro", "03": "credito", "04": "debito", "15": "boleto", "16": "transferencia",
             "17": "pix", "18": "transferencia", "20": "pix", "99": "outro"}.get((tpag or "").zfill(2))

    return Extracao(
        origem="xml",
        forma_pagamento=forma,
        fornecedor=_txt(emit, "xNome") or _txt(emit, "xFant"),
        cnpj=normalizar_documento(_txt(emit, "CNPJ") or _txt(emit, "CPF")),
        numero=_txt(ide, "nNF"),
        serie=_txt(ide, "serie"),
        data_emissao=data_emissao,
        valor_total_centavos=para_centavos(_txt(inf, "total/ICMSTot/vNF")),
        chave_acesso=normalizar_documento(chave),
        itens=itens,
        confianca={campo: "alta" for campo in CAMPOS},
    )
