"""Camada de armazenamento dos arquivos originais.

O resto do sistema só conhece a interface `Armazenamento`. Para trocar o destino (Google Drive,
OneDrive...) basta implementar `salvar`, `ler` e `remover` e registrar em `criar_armazenamento`.
"""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Protocol


class Armazenamento(Protocol):
    nome: str

    def salvar(self, caminho_relativo: str, conteudo: bytes) -> str:
        """Grava o arquivo e devolve uma referência (guardada no banco) para ler/remover depois."""

    def ler(self, ref: str) -> bytes: ...

    def remover(self, ref: str) -> None: ...


def slug(texto: str | None, limite: int = 40) -> str:
    base = unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-zA-Z0-9]+", "-", base).strip("-").lower()[:limite].strip("-")
    return base or "sem-nome"


class ArmazenamentoLocal:
    nome = "local"

    def __init__(self, raiz: Path):
        self.raiz = raiz.resolve()
        self.raiz.mkdir(parents=True, exist_ok=True)

    def _resolver(self, ref: str) -> Path:
        caminho = (self.raiz / ref).resolve()
        if not caminho.is_relative_to(self.raiz):
            raise ValueError("Caminho fora da pasta de dados.")
        return caminho

    def salvar(self, caminho_relativo: str, conteudo: bytes) -> str:
        destino = self._resolver(caminho_relativo)
        destino.parent.mkdir(parents=True, exist_ok=True)
        if destino.exists() and destino.read_bytes() != conteudo:  # nunca sobrescreve outro arquivo
            n = 2
            while (alternativo := destino.with_name(f"{destino.stem}_{n}{destino.suffix}")).exists():
                n += 1
            destino = alternativo
        destino.write_bytes(conteudo)
        return destino.relative_to(self.raiz).as_posix()

    def ler(self, ref: str) -> bytes:
        return self._resolver(ref).read_bytes()

    def remover(self, ref: str) -> None:
        caminho = self._resolver(ref)
        caminho.unlink(missing_ok=True)
        pasta = caminho.parent
        while pasta != self.raiz and pasta.is_dir() and not any(pasta.iterdir()):  # limpa pastas vazias
            pasta.rmdir()
            pasta = pasta.parent


def criar_armazenamento(tipo: str, raiz: Path) -> Armazenamento:
    if tipo == "local":
        return ArmazenamentoLocal(raiz)
    raise ValueError(
        f"Armazenamento '{tipo}' ainda não implementado. Disponível: 'local'. "
        "O Google Drive entra como módulo opcional implementando a interface Armazenamento."
    )
