"""Erros de regra de negócio: a API devolve a mensagem para a pessoa com o código HTTP de cada um."""
from __future__ import annotations


class ErroNegocio(Exception):
    status_http = 400

    def __init__(self, mensagem: str, **extras):
        super().__init__(mensagem)
        self.mensagem, self.extras = mensagem, extras


class NaoEncontrado(ErroNegocio):
    status_http = 404


class Conflito(ErroNegocio):
    status_http = 409


class ArquivoInvalido(ErroNegocio):
    status_http = 422


class ServicoIndisponivel(ErroNegocio):
    status_http = 503
