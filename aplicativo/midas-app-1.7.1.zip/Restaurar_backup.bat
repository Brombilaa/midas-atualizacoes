@echo off
cd /d "%~dp0"
title Midas - restaurar copia de seguranca
echo FECHE o Midas antes de continuar.
echo.
pause
"python\python.exe" -m app.backup
echo.
pause
