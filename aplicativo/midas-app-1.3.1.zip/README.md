# Midas: controle de notas fiscais

Recebe uma nota fiscal (XML, PDF, foto do celular, qualquer documento ou só um valor digitado), lê os dados,
mostra o documento ao lado dos campos para você conferir, guarda o arquivo na pasta do grupo e alimenta a
planilha mensal em Excel.

```
upload (XML / PDF / foto)  →  leitura  →  conferência  →  validação  →  pasta do grupo + planilha do mês
                              (XML ou      (você corrige   (escolhe
                               Claude)      o que precisar)  categoria e grupo, se houver)
```

## Jeito fácil (Windows): um programa com ícone

1. Extraia o ZIP inteiro (botão direito > Extrair tudo) numa pasta fixa, como Documentos.
2. Dê dois cliques em **Midas** (o programa com o ícone da moeda dourada). Na primeira vez ele pergunta se
   quer um atalho na área de trabalho; responda Sim e use o atalho daí em diante.
3. O sistema abre numa janela própria, sem terminal. Fechou a janela, o sistema encerra sozinho.
   Se o Windows avisar "Windows protegeu seu computador", clique em **Mais informações > Executar assim mesmo**.
4. Fotos e PDFs escaneados são lidos **no próprio computador, sem internet e sem conta de IA** (leitor local).
   Opcional: com uma chave do Claude em `sistema\.env` (`ANTHROPIC_API_KEY=sk-ant-...`) a leitura fica mais precisa
   em fotos difíceis; se a internet cair, o leitor local assume.

Precisa do Microsoft Edge ou do Google Chrome (o Edge já vem no Windows). O Python já vai dentro da pasta `sistema`.
Se algo não abrir, veja `sistema\dados\log.txt` ou rode `sistema\Diagnostico.bat` para ver as mensagens na tela.
Seus dados ficam em `sistema\dados`: faça backup dessa pasta. Para atualizar o sistema, troque a pasta `sistema`
mantendo a sua `dados` e o seu `.env`.

## Como rodar pelo terminal

Precisa de Python 3.10 ou mais novo.

```powershell
# Windows (PowerShell)
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

$env:ANTHROPIC_API_KEY = "sk-ant-..."     # só para foto/PDF; XML funciona sem
uvicorn app.main:criar_app --factory --reload
```

```bash
# Mac / Linux
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY="sk-ant-..."
uvicorn app.main:criar_app --factory --reload
```

Abra <http://127.0.0.1:8000/>: é a tela de envio e conferência (documento à esquerda, campos à direita).
A documentação da API fica em <http://127.0.0.1:8000/docs>.

**Usar pelo celular** (tirar foto da notinha na hora): rode com `--host 0.0.0.0`, defina uma senha com
`NF_API_TOKEN` e abra `http://<IP do computador>:8000/` no celular, na mesma rede Wi‑Fi. A tela pede a senha
uma vez. Não exponha na internet sem HTTPS.

Bancos criados por versões anteriores são migrados automaticamente na primeira execução.
Os dados ficam na pasta `dados/` (banco `notas.db`, `entrada/` e `grupos/`). Faça backup dessa pasta.

Testes (151): `pip install -r requirements-dev.txt && python -m pytest`

## Na tela

- **Topo:** o mês por extenso (setas para trocar, clique no nome para escolher), o total arquivado no mês e dois menus:
  *Planilha do mês* (baixar, ou baixar e marcar como lançadas) e o ícone de ajustes (grupos e categorias, tema claro,
  escuro ou automático).
- **Enviar notas:** o botão, arrastar para qualquer lugar da tela ou colar (Ctrl+V). Vários arquivos de uma vez são lidos
  em paralelo (3 por vez); a primeira nota abre assim que fica pronta e as outras entram em *Para conferir*. Fotos
  mostram "Lendo…" enquanto o OCR trabalha. Também dá para *Tirar foto* ou *Lançar sem arquivo*.
- **Documento ao lado:** foto com zoom, girar e arrastar; na foto lida pelo leitor local, o fornecedor, o CNPJ, a data e o
  total aparecem destacados onde foram lidos (clique num campo para acender o destaque). XML aparece desenhado como a
  nota em papel, com itens, total e chave de acesso.
- **Ficha:** fornecedor e valor em destaque no topo; categoria em botões (as mais usadas, e *Outras…*); grupo com o
  orçamento e o peso desta nota; mês da planilha por extenso. *Dados da nota* e *Itens* abrem sozinhos quando há algo
  para conferir. *Arquivar e ir para a próxima* (Ctrl+Enter).
- **Painel do mês:** quando não há nada para conferir, a tela mostra o mês: total, notas, maior categoria, gasto por
  categoria, grupos com orçamento e as últimas arquivadas.

## Fluxo de uso pela API

1. `POST /grupos` cria um grupo (nome, data e orçamento opcionais). Grupo é **opcional**: serve para separar eventos, projetos, departamentos etc. Já existem categorias padrão (`GET /categorias`).
2. `POST /notas/upload` envia o arquivo. A resposta traz os dados lidos, a confiança de cada campo e os **avisos**.
3. `PATCH /notas/{id}` corrige o que estiver errado. Campo corrigido por você passa a contar como confiável.
4. `POST /notas/{id}/validar` com `categoria_id` e, se quiser, `grupo_id` (sem ele a nota entra como "(sem grupo)" e o arquivo vai para a pasta `sem-grupo`) e `competencia` (padrão: mês da data de emissão).
   O arquivo vai para `dados/grupos/<grupo>/<AAAA-MM>/<data>_<fornecedor>_<valor>_n<id>.<ext>`.
5. `GET /resumo/2026-10` traz os números do painel do mês (em centavos).
6. `GET /planilhas/2026-10` baixa a planilha do mês. `POST /planilhas/2026-10/lancar` faz o mesmo e marca as
   notas como `lancado`.

Status da nota: `lido` (aguardando conferência) → `validado` (arquivada e na planilha) → `lancado` (já saiu em planilha).
`POST /notas/{id}/reabrir` devolve para `lido` caso precise corrigir algo depois.

## Grupos e categorias

- **Grupo** é opcional. Antes se chamava "evento"; bancos e pastas da versão anterior são convertidos sozinhos na
  primeira abertura (a pasta `dados/eventos` vira `dados/grupos`, sem perder nada). O nome antigo `{evento}` em
  `NF_ESTRUTURA_PASTAS` continua valendo.
- **Categorias** são editáveis em *Grupos e categorias* (ou em "+ Nova categoria…" na própria ficha da nota): criar,
  renomear e excluir. Nomes repetidos são recusados mesmo com acento ou maiúscula diferente. Categoria em uso por
  alguma nota não pode ser excluída (o sistema informa quantas notas usam); renomear é sempre permitido.
- API: `GET/POST /categorias`, `PATCH/DELETE /categorias/{id}`.

## Atualizações

- O programa tem duas camadas. O **motor** (`sistema/python`, cerca de 60 MB: Python, bibliotecas e leitor de fotos, mais
  o ponto de partida `iniciar.py`) só muda com o instalador completo. O **aplicativo** (`app/`, `versao.json`,
  `NOVIDADES.md` e os .bat, cerca de 250 KB) é o que muda a cada versão.
- Ao abrir, o Midas consulta o canal público `Brombilaa/midas-atualizacoes`. Havendo versão nova, avisa; em *Ajustes >
  Atualizações e novidades* dá para baixar. O pacote é conferido (tamanho, SHA-256, caminhos permitidos, versão) e
  aplicado no próximo início. Se a versão nova não abrir, o Midas volta sozinho para a anterior e avisa; essa versão não
  é oferecida de novo naquele computador.
- Uma versão que exige motor novo (`motor_minimo` maior que o instalado) pede o instalador completo.
- `NF_ATUALIZACAO=0` no `.env` desliga a consulta.

Publicar uma versão (quem desenvolve):
1. Suba `aplicativo` em `versao.json` e escreva a seção dela em `NOVIDADES.md`.
2. `python instalador/publicar_atualizacao.py --repo ../midas-atualizacoes`, depois commit + push no canal.
3. Mudou o motor? Suba `MOTOR` em `instalador/montar_pacote.py` e `motor_minimo` em `versao.json`, gere o instalador com
   `python instalador/montar_pacote.py --dist <pasta Midas> --instalador Instalar_Midas.exe` e publique com
   `--instalador <versão>`.

## Cópias de segurança e versão do banco

- O Midas guarda uma cópia do banco **por dia**, ao abrir, em `sistema\dados\backups` (as 7 mais recentes), e outra
  **antes de qualquer atualização da estrutura do banco** (as 5 mais recentes). Os arquivos das notas não são copiados:
  eles nunca mudam depois de enviados.
- Para voltar a uma cópia: feche o Midas e rode `sistema\Restaurar_backup.bat`. Ele lista as cópias com data e hora; o
  estado atual é guardado antes de restaurar.
- A versão da estrutura do banco fica gravada nele mesmo. Cada mudança é uma migração numerada em `app/db.py`
  (`MIGRACOES`), aplicada uma única vez. Uma versão antiga do Midas recusa abrir um banco atualizado por uma mais nova,
  com uma mensagem explicando.

## Como as notas são lidas

- **XML:** leitura exata, sem IA.
- **PDF de DANFE digital** (o que o fornecedor manda por e-mail): o texto do PDF é lido direto, sem IA e sem chave
  da API. Vêm fornecedor, CNPJ, número, série, data, valor e chave; os itens só vêm com a chave da API.
- **Foto ou PDF digitalizado, sem Claude (leitor local):** um OCR que roda no computador (RapidOCR/ONNX, uns 3 a 5
  segundos por foto) transforma a imagem em texto, e regras próprias extraem CNPJ, fornecedor, data, valor total, itens
  e tipo de documento. Conferências embutidas: dígito verificador do CNPJ (e conserto de um dígito trocado), soma dos
  itens contra o total, e a chave de acesso quando legível. É menos preciso que o Claude em fotos borradas ou tortas:
  campos incertos saem marcados para conferir. `NF_LEITOR` escolhe o leitor: `auto` (padrão: Claude se houver chave,
  senão local; se o Claude falhar, cai para o local), `local` (nunca usa o Claude) ou `claude`.
- **Foto ou PDF digitalizado, com Claude:** lido pelo Claude. Depois da leitura tudo é conferido contra a **chave de acesso**
  (ela traz o CNPJ do emitente, a série, o número e o mês). Isso corrige, por exemplo, o CNPJ do destinatário
  (a própria associação) lido no lugar do fornecedor, número com zeros à esquerda e dia/mês trocados.
- **Cupom, pedido e comprovante** (ex.: o "PEDIDO DE NF-E" do caixa): o leitor classifica o documento. Se não for a
  nota fiscal em si, a nota fica marcada como *pedido/comprovante*, sem número de nota nem chave (o número do pedido e a
  forma de pagamento vão para as observações) e com um aviso pedindo a nota fiscal. Se a mesma compra já estiver
  lançada (mesmo CNPJ ou fornecedor, data e valor), aparece o aviso de possível duplicata.
- **Releitura automática:** se a leitura por foto tiver CNPJ com dígito verificador inválido ou itens que não somam o
  total, (só no Claude) o Claude recebe o problema e relê a imagem uma vez; vale a leitura com menos problemas.

## O que o sistema confere sozinho

| Situação | Resultado |
|---|---|
| Falta fornecedor, data ou valor; data no futuro | **erro**: impede validar |
| Mesmo arquivo ou mesma chave de acesso já lançada | recusa o upload (409) e indica a nota existente |
| CNPJ ou dígito verificador da chave não confere | aviso (típico de leitura errada em foto) |
| CNPJ/mês/número dentro da chave diferem dos campos lidos | aviso |
| Soma dos itens ≠ total | aviso (pode ser desconto ou frete) |
| Campo lido com baixa confiança pelo Claude | aviso |
| Sem chave de acesso e mesmo fornecedor, data e valor de outra nota | aviso de possível duplicata |

Avisos não impedem a validação; erros impedem. Aceita CNPJ numérico e alfanumérico.

## Planilha mensal

Duas abas: **Lançamentos** (uma linha por nota, com filtro) e **Resumo** (por grupo e por categoria, orçamento x
acumulado do grupo e uma célula de conferência que deve mostrar `OK`). O resumo usa fórmulas, então se você
editar um valor na aba Lançamentos ele recalcula. Células em azul no Resumo são dados vindos do cadastro, não fórmulas.

## Estrutura

```
app/
  main.py            rotas HTTP (FastAPI)          schemas.py   formato de entrada e saída
  service.py         regras de negócio             validation.py  conferências da nota
  extractors/        xml_nfe.py (XML) e claude_vision.py (foto/PDF)
  storage.py         onde os arquivos ficam (interface + versão local)
  excel_export.py    planilha mensal               db.py        SQLite
tests/               151 testes (só no código-fonte; não vão no pacote Windows)
```

## Decisões que valem saber

- **Valores em centavos** no banco (sem erro de arredondamento); a API fala em reais (`"480.00"`).
- **XML é a fonte mais confiável.** Foto e PDF passam pelo Claude e exigem conferência; o prompt manda
  deixar em branco o que não estiver legível em vez de adivinhar.
- **O texto dentro da foto é tratado como dado**, nunca como instrução, e o Claude só consegue responder
  pela ferramenta de registro de campos.
- **Segurança:** é um sistema financeiro. Rode só na rede interna ou atrás de login. Defina `NF_API_TOKEN`
  para exigir token. Não exponha direto na internet.
- **Fotos HEIC do iPhone:** o celular costuma converter para JPEG no envio. Se não, instale `pillow-heif`.
- **Renomear um grupo** não move arquivos já guardados; eles ficam na pasta antiga.

## O que ainda não existe

- Envio ao Google Drive/OneDrive: basta implementar `salvar`, `ler` e `remover` em `storage.py` e registrar em
  `criar_armazenamento`; o resto do sistema não muda.
- Boletos e pagamentos recorrentes (tabela de recorrências, painel de vencimentos e lembretes).
- A leitura de foto/PDF foi testada com um cliente simulado; falta rodar com notas reais e a chave da API.
