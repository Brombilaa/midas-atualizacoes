'use strict';
/* Tela de conferência. Sem framework e sem build: o servidor entrega estes arquivos como estão.
   Regra de segurança: texto vindo de notas (fornecedor, nome de arquivo...) só entra na página via textContent. */

/* ------------------------------------------------------------------ utilidades */
const $ = (sel, raiz = document) => raiz.querySelector(sel);
const $$ = (sel, raiz = document) => [...raiz.querySelectorAll(sel)];

function h(tag, props = {}, ...filhos) {
  const no = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') no.className = v;
    else if (k === 'value' || k === 'disabled') no[k] = v;
    else if (k.startsWith('on')) no.addEventListener(k.slice(2), v);
    else no.setAttribute(k, v === true ? '' : v);
  }
  for (const f of filhos.flat()) if (f != null && f !== false) no.append(f); // texto vira nó de texto, nunca HTML
  return no;
}

class ErroApi extends Error {
  constructor(mensagem, status = 0, dados = {}) { super(mensagem); this.status = status; this.dados = dados; }
}
class ErroForm extends Error {
  constructor(mensagem, campo) { super(mensagem); this.campo = campo; }
}

const ROTULOS = {
  fornecedor: 'Fornecedor', cnpj: 'CNPJ', numero: 'Nº da nota', data_emissao: 'Data de emissão', valor_total: 'Valor total',
  chave_acesso: 'Chave de acesso', observacoes: 'Observações', grupo_id: 'Grupo', categoria_id: 'Categoria',
  competencia: 'Mês na planilha', itens: 'Itens', duplicidade: 'Duplicidade',
};
const ORIGEM = { xml: 'Lida do XML', pdf: 'Lida do texto do PDF', claude: 'Lida pelo Claude', ocr: 'Lida da foto (leitor local)', manual: 'Preenchimento manual' };
const ORIGEM_CURTA = { xml: 'XML', pdf: 'PDF', claude: 'foto', ocr: 'foto', manual: 'manual' };
const STATUS = { lido: 'Para conferir', validado: 'Arquivada', lancado: 'Na planilha' };
const FORMAS = { pix: 'PIX', dinheiro: 'Dinheiro', debito: 'Cartão de débito', credito: 'Cartão de crédito', boleto: 'Boleto', transferencia: 'Transferência', outro: 'Outra' };
const TIPO_CONTA = { banco: 'Banco', caixa: 'Caixa', cartao: 'Cartão' };
const CAMPOS_DADOS = ['fornecedor', 'cnpj', 'numero', 'data_emissao', 'valor_total', 'chave_acesso'];

const MOEDA = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtBRL = (dec) => (dec == null || dec === '' ? '—' : MOEDA.format(Number(dec)));
const fmtData = (iso) => (iso ? iso.split('-').reverse().join('/') : 'sem data');
const decParaCampo = (dec) => (dec == null || dec === ''
  ? '' : Number(dec).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2, useGrouping: false }));

/** Texto digitado -> {vazio} | {valor:'1234.56'} | {erro}. Aceita 1.234,56 / 1234,56 / 1234.56 / R$ 12,5 */
function campoParaDec(texto) {
  let s = String(texto ?? '').replace(/R\$|\s/g, '');
  if (!s) return { vazio: true };
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return { erro: true };
  const [inteiro, dec = ''] = s.split('.');
  return { valor: `${inteiro.replace(/^0+(?=\d)/, '')}.${dec.padEnd(2, '0')}` };
}
const normDoc = (t) => (String(t ?? '').replace(/[^0-9A-Za-z]/g, '').toUpperCase() || null);
const fmtCnpj = (c) => (c && /^[0-9A-Z]{14}$/.test(c) ? `${c.slice(0, 2)}.${c.slice(2, 5)}.${c.slice(5, 8)}/${c.slice(8, 12)}-${c.slice(12)}` : (c ?? ''));
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const MESES_CURTOS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const partesMes = (comp) => { const [a, m] = (comp || '').split('-').map(Number); return a && m ? { ano: a, mes: m } : null; };
/** '2026-10' -> 'outubro/2026' */
const fmtMesCurto = (comp) => { const p = partesMes(comp); return p ? `${MESES[p.mes - 1]}/${p.ano}` : (comp || ''); };
/** '2026-10' -> 'outubro de 2026' */
const fmtMesLongo = (comp) => { const p = partesMes(comp); return p ? `${MESES[p.mes - 1]} de ${p.ano}` : (comp || ''); };
const maiuscula = (t) => (t ? t[0].toUpperCase() + t.slice(1) : t);
/** '2026-10-02' -> '2 de outubro de 2026' */
const fmtDataLonga = (iso) => { if (!iso) return ''; const [a, m, d] = iso.split('-').map(Number); return `${d} de ${MESES[m - 1]} de ${a}`; };
/** '2026-10-02' -> '2 out' */
const fmtDataCurta = (iso) => { if (!iso) return 'sem data'; const [, m, d] = iso.split('-').map(Number); return `${d} ${MESES_CURTOS[m - 1]}`; };
const somaMes = (comp, delta) => { const p = partesMes(comp) || partesMes(mesAtual()); const d = new Date(p.ano, p.mes - 1 + delta, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const mesAtual = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };

function mensagemDe(dados, status) {
  const d = dados?.detail;
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) { // erro de validação do FastAPI
    return d.map((e) => { const c = e.loc?.[e.loc.length - 1]; return `${ROTULOS[c] || c}: valor inválido`; }).join('. ');
  }
  return `Erro inesperado (código ${status}).`;
}

/* ------------------------------------------------------------------ estado */
const estado = {
  saude: { leitura_de_fotos: false, exige_token: false, limite_upload_mb: 15 },
  token: sessionStorage.getItem('nf_token') || '',
  grupos: [], categorias: [], contas: [],
  fila: [], arquivadas: [], aba: 'fila',
  nota: null, original: null, competenciaManual: false,
  vista: 'notas', lf: { alcance: 'mes', busca: '', tipo: '', categoria_id: '', grupo_id: '', situacao: '', conta_id: '' }, lancPedido: 0,
  lancAberto: null, contaEditando: null, aoCriarConta: null,
  grupoAnterior: '', categoriaAnterior: '', aoCriarGrupo: null, aoCriarCategoria: null, grupoEditando: null, categoriaEditando: null,
};

const campos = {
  fornecedor: $('#f-fornecedor'), cnpj: $('#f-cnpj'), numero: $('#f-numero'), data_emissao: $('#f-data'),
  valor_total: $('#f-valor'), chave_acesso: $('#f-chave'), grupo_id: $('#f-grupo'), categoria_id: $('#f-categoria'),
  competencia: $('#f-competencia'), observacoes: $('#f-obs'), conta_id: $('#f-conta'), forma_pagamento: $('#f-forma'),
};

/* ------------------------------------------------------------------ API */
async function api(caminho, { metodo = 'GET', json, form, blob = false, _tentou = false } = {}) {
  const cabecalhos = {};
  if (estado.token) cabecalhos['X-API-Token'] = estado.token;
  let corpo;
  if (json !== undefined) { cabecalhos['Content-Type'] = 'application/json'; corpo = JSON.stringify(json); }
  else if (form) corpo = form;
  let resp;
  try { resp = await fetch(caminho, { method: metodo, headers: cabecalhos, body: corpo }); }
  catch { throw new ErroApi('Não consegui falar com o servidor. Confira se ele está rodando.'); }
  if (resp.status === 401 && !_tentou) {
    await pedirToken(true);
    return api(caminho, { metodo, json, form, blob, _tentou: true });
  }
  if (!resp.ok) {
    const dados = await resp.json().catch(() => ({}));
    throw new ErroApi(mensagemDe(dados, resp.status), resp.status, dados);
  }
  if (blob) return resp.blob();
  return resp.status === 204 ? null : resp.json();
}

function pedirToken(errado = false) {
  const dlg = $('#dlg-token');
  return new Promise((resolver) => {
    sessionStorage.removeItem('nf_token'); estado.token = '';
    $('#token-campo').value = '';
    dlg.addEventListener('cancel', (e) => e.preventDefault(), { once: true });
    $('#token-form').onsubmit = () => {
      estado.token = $('#token-campo').value; sessionStorage.setItem('nf_token', estado.token); resolver();
    };
    if (errado) avisar('Senha incorreta. Tente de novo.', 'erro');
    dlg.showModal();
  });
}

/* ------------------------------------------------------------------ avisos na tela */
function avisar(texto, tipo = 'info', { acao, duracao } = {}) {
  const no = h('div', { class: `aviso aviso--${tipo}`, role: tipo === 'erro' ? 'alert' : 'status' }, h('span', {}, texto));
  const fechar = () => no.remove();
  if (acao) no.append(h('button', { type: 'button', onclick: () => { fechar(); acao.fn(); } }, acao.rotulo));
  else no.append(h('button', { type: 'button', 'aria-label': 'Fechar aviso', onclick: fechar }, 'Fechar'));
  $('#avisos').append(no);
  setTimeout(fechar, duracao ?? (tipo === 'erro' ? 9000 : 4500));
}
const erroParaTela = (e) => avisar(e.message || 'Algo deu errado.', 'erro');

/* ------------------------------------------------------------------ listas */
async function carregarCatalogos() {
  [estado.grupos, estado.categorias, estado.contas] = await Promise.all([api('/grupos'), api('/categorias'), api('/contas')]);
}

async function carregarListas() {
  const [fila, arquivadas] = await Promise.all([
    api('/notas?status=lido&limite=500'), api('/notas?status=concluidas&limite=100'),
  ]);
  estado.fila = fila.sort((a, b) => b.id - a.id);
  estado.arquivadas = arquivadas;
  renderLista();
  if (estado.nota) atualizarNavegacao(estado.nota);  // a fila pode ter crescido (envio em lote)
}

function renderLista() {
  $('#n-fila').textContent = estado.fila.length;
  $('#n-fila').classList.toggle('contagem--leve', estado.fila.length === 0);
  $('#n-arquivadas').textContent = estado.arquivadas.length;
  $('#aba-fila').setAttribute('aria-selected', String(estado.aba === 'fila'));
  $('#aba-arquivadas').setAttribute('aria-selected', String(estado.aba === 'arquivadas'));
  document.title = `${estado.fila.length ? `(${estado.fila.length}) ` : ''}Midas`;

  const dados = estado.aba === 'fila' ? estado.fila : estado.arquivadas;
  const ul = $('#lista');
  if (!dados.length) {
    ul.replaceChildren(h('li', { class: 'vazio-lista' },
      estado.aba === 'fila' ? 'Nenhuma nota esperando.' : 'Nenhuma nota arquivada ainda.'));
    return;
  }
  ul.replaceChildren(...dados.map(itemLista));
}

/** Avisos que pedem ação. O de "é um pedido" vira o cartão próprio; e pedido nunca tem chave de acesso. */
function avisosRelevantes(n) {
  const pedido = n.tipo_documento === 'pedido_ou_comprovante';
  return n.avisos.filter((a) => a.campo !== 'tipo_documento' && !(pedido && a.campo === 'chave_acesso'));
}

function itemLista(n) {
  const lista = avisosRelevantes(n);
  const erros = lista.filter((a) => a.nivel === 'erro').length;
  const avisos = lista.filter((a) => a.nivel === 'aviso').length;
  let pendencia;
  if (n.status !== 'lido') pendencia = h('span', { class: 'pilula pilula--ok' }, STATUS[n.status]);
  else if (erros) pendencia = h('span', { class: 'pilula pilula--erro' }, `${erros} a corrigir`);
  else if (avisos) pendencia = h('span', { class: 'pilula pilula--aviso' }, `${avisos} a conferir`);
  else pendencia = h('span', { class: 'pilula pilula--ok' }, 'Pronta');

  return h('li', {}, h('button', {
    type: 'button', class: 'lista-item', 'aria-current': String(estado.nota?.id === n.id), onclick: () => abrirNota(n.id),
  },
  h('span', { class: `titulo${n.fornecedor ? '' : ' titulo--vazio'}` }, n.fornecedor || n.arquivo_nome || 'Lançamento manual'),
  h('span', { class: 'valor num' }, fmtBRL(n.valor_total)),
  h('span', { class: 'meta' }, h('span', {}, `${fmtDataCurta(n.data_emissao)} · ${ORIGEM_CURTA[n.origem] || ''}`), pendencia)));
}

/** Uma nota acabou de chegar (envio): entra na fila sem buscar a lista inteira de novo. */
function receberNaFila(nota) {
  estado.fila = [nota, ...estado.fila.filter((n) => n.id !== nota.id)].sort((a, b) => b.id - a.id);
  renderLista();
  if (estado.nota) atualizarNavegacao(estado.nota);
}

function trocarAba(aba) { estado.aba = aba; renderLista(); }

/* ------------------------------------------------------------------ abrir e mostrar uma nota */
async function abrirNota(id, { rolar = true } = {}) {
  if (estado.nota && estado.nota.id !== id && !(await salvarSePreciso())) return;
  mostrarVista('notas');
  let nota;
  try { nota = await api(`/notas/${id}`); } catch (e) { erroParaTela(e); return; }
  estado.nota = nota;
  estado.competenciaManual = false;
  estado.aba = nota.status === 'lido' ? 'fila' : 'arquivadas';
  mostrarNota(nota);
  renderLista();
  carregarArquivo(nota);
  if (rolar) $('#area').scrollIntoView?.({ block: 'nearest' });
}

async function salvarSePreciso() {
  if (!estaSujo()) return true;
  try { await salvar({ silencioso: true }); return true; }
  catch (e) { erroParaTela(e); if (e.campo) focarCampo(e.campo); return false; }
}

/** Categorias de um tipo (despesa | receita), na ordem do servidor (subcategoria logo abaixo da principal). */
const catsDo = (tipo) => estado.categorias.filter((c) => (c.tipo || 'despesa') === tipo);
const rotuloCat = (c) => c.nome_completo || c.nome;
function opcoesDeCategoria(sel, tipo, escolhida, { vazio = 'Sem categoria' } = {}) {
  const lista = catsDo(tipo);
  sel.replaceChildren(h('option', { value: '' }, vazio), ...lista.map((c) => h('option', { value: String(c.id) }, rotuloCat(c))));
  sel.value = escolhida && lista.some((c) => c.id === escolhida) ? String(escolhida) : '';
}

function ultimoGrupo() { return localStorage.getItem('nf_ultimo_grupo') || ''; }
function ultimaConta() { try { return Number(localStorage.getItem('nf_ultima_conta')) || null; } catch { return null; } }

/** Opções de conta: as ativas (e a já escolhida, mesmo desativada), sem conta e criar nova. */
function opcoesDeConta(sel, escolhida, { nova = true, vazio = 'Sem conta' } = {}) {
  const lista = estado.contas.filter((k) => k.ativa || k.id === escolhida);
  sel.replaceChildren(h('option', { value: '' }, vazio),
    ...lista.map((k) => h('option', { value: String(k.id) }, k.nome + (k.ativa ? '' : ' (desativada)'))),
    nova ? h('option', { value: '__nova__' }, '+ Nova conta…') : null);
  sel.value = escolhida && lista.some((k) => k.id === escolhida) ? String(escolhida) : '';
}

function opcoesDeForma(sel, valor) {
  sel.replaceChildren(h('option', { value: '' }, 'Não informada'),
    ...Object.entries(FORMAS).map(([v, r]) => h('option', { value: v }, r)));
  sel.value = valor && FORMAS[valor] ? valor : '';
}

/** Grupo e categoria da última nota arquivada do mesmo fornecedor (CNPJ, ou nome quando não há CNPJ). */
function sugerirLancamento(nota) {
  if (nota.status !== 'lido' || nota.categoria_id) return null;
  const nome = (nota.fornecedor || '').trim().toLowerCase();
  const mesmo = (n) => n.id !== nota.id && n.categoria_id
    && ((nota.cnpj && n.cnpj === nota.cnpj) || (!nota.cnpj && nome && (n.fornecedor || '').trim().toLowerCase() === nome));
  const anterior = estado.arquivadas.filter(mesmo).sort((a, b) => b.id - a.id)[0];
  if (!anterior || !estado.categorias.some((c) => c.id === anterior.categoria_id)) return null;
  const grupoVale = anterior.grupo_id && estado.grupos.some((g) => g.id === anterior.grupo_id);
  // 0 = "sem grupo" de propósito (não cai no último grupo usado)
  return { grupo_id: nota.grupo_id || (grupoVale ? anterior.grupo_id : 0), categoria_id: anterior.categoria_id, de: anterior.id };
}

function popularSelects(nota) {
  // sugere o último grupo usado só em nota ainda intocada; depois disso respeita a escolha (inclusive "Sem grupo")
  const grupo = nota.grupo_id ?? (nota.status === 'lido' && !nota.categoria_id ? Number(ultimoGrupo()) || null : null);
  campos.grupo_id.replaceChildren(
    h('option', { value: '' }, 'Sem grupo'),
    ...estado.grupos.map((e) => h('option', { value: String(e.id) }, e.nome)),
    h('option', { value: '__novo__' }, '+ Novo grupo…'));
  campos.grupo_id.value = grupo && estado.grupos.some((e) => e.id === grupo) ? String(grupo) : '';
  estado.grupoAnterior = campos.grupo_id.value;
  campos.categoria_id.replaceChildren(
    h('option', { value: '' }, 'Escolha a categoria…'),
    ...catsDo('despesa').map((c) => h('option', { value: String(c.id) }, rotuloCat(c))),
    h('option', { value: '__nova__' }, '+ Nova categoria…'));
  campos.categoria_id.value = nota.categoria_id && catsDo('despesa').some((c) => c.id === nota.categoria_id) ? String(nota.categoria_id) : '';
  estado.categoriaAnterior = campos.categoria_id.value;
  renderCategoriaChips();
  opcoesDeConta(campos.conta_id, nota.conta_id ?? (nota.status === 'lido' ? ultimaConta() : null));
  estado.contaAnterior = campos.conta_id.value;
  opcoesDeForma(campos.forma_pagamento, nota.forma_pagamento);
  atualizarOrcamento();
}

/* categorias como botões: as mais usadas + a escolhida; o resto fica em "Outras…" */
const CHIPS_VISIVEIS = 5;
function renderCategoriaChips() {
  const sel = campos.categoria_id;
  const escolhida = sel.value ? Number(sel.value) : null;
  const editavel = !sel.disabled;
  const despesas = catsDo('despesa');
  const porUso = [...despesas].sort((a, b) => (b.qtd_notas || 0) - (a.qtd_notas || 0) || a.nome.localeCompare(b.nome, 'pt-BR'));
  const visiveis = porUso.slice(0, CHIPS_VISIVEIS);
  if (escolhida && !visiveis.some((c) => c.id === escolhida)) {
    const c = despesas.find((x) => x.id === escolhida); if (c) visiveis.push(c);
  }
  const chips = visiveis.map((c) => h('button', {
    type: 'button', class: 'chip', 'aria-pressed': String(c.id === escolhida), disabled: !editavel,
    onclick: () => escolherCategoria(String(c.id)),
  }, rotuloCat(c)));
  const resto = despesas.length - visiveis.length;
  if (editavel) {
    chips.push(h('button', {
      type: 'button', class: 'chip chip--mais', 'aria-expanded': String(!sel.hidden),
      onclick: () => { sel.hidden = !sel.hidden; renderCategoriaChips(); if (!sel.hidden) sel.focus(); },
    }, resto > 0 ? `Outras (${resto})…` : 'Nova…'));
  }
  $('#cat-chips').replaceChildren(...chips);
}

function escolherCategoria(valor) {
  campos.categoria_id.value = valor;
  estado.categoriaAnterior = valor;
  renderCategoriaChips();
  $('.campo[data-campo="categoria_id"]').classList.remove('campo--erro');
  atualizarSujo();
}

/* mês da planilha: lista de meses por extenso (12 para trás, 2 para frente, e o da nota se estiver fora) */
function popularMeses(valor) {
  const base = mesAtual();
  const meses = new Set();
  for (let d = -12; d <= 2; d++) meses.add(somaMes(base, d));
  if (valor) meses.add(valor);
  const lista = [...meses].sort().reverse();
  campos.competencia.replaceChildren(h('option', { value: '' }, 'Escolha o mês…'),
    ...lista.map((m) => h('option', { value: m }, fmtMesCurto(m))));
  campos.competencia.value = valor || '';
}
function definirMes(valor) {
  if (valor && ![...campos.competencia.options].some((o) => o.value === valor)) popularMeses(valor);
  else campos.competencia.value = valor || '';
}

/* cabeçalho da ficha: acompanha o que está nos campos */
function atualizarCabeca() {
  const nota = estado.nota; if (!nota) return;
  const f = lerForm();
  $('#cab-fornecedor').textContent = f.fornecedor || nota.arquivo_nome || 'Lançamento sem fornecedor';
  $('#cab-fornecedor').classList.toggle('vazio', !f.fornecedor);
  const partes = [];
  if (f.cnpj) partes.push(`CNPJ ${fmtCnpj(f.cnpj)}`);
  if (f.numero) partes.push(`Nº ${f.numero}`);
  if (f.data_emissao) partes.push(fmtDataLonga(f.data_emissao));
  $('#cab-sub').textContent = partes.join(' · ') || 'Preencha os dados da nota abaixo';
  $('#cab-valor').textContent = f.valor_total && f.valor_total !== '__invalido__' ? fmtBRL(f.valor_total) : 'R$ —';
  const centavos = f.itens.map((i) => (i.valor_total && i.valor_total !== '__invalido__' ? Math.round(Number(i.valor_total) * 100) : null));
  const total = f.valor_total && f.valor_total !== '__invalido__' ? Math.round(Number(f.valor_total) * 100) : null;
  const confere = total != null && centavos.length > 0 && centavos.every((c) => c != null)
    && Math.abs(centavos.reduce((a, b) => a + b, 0) - total) <= 5;
  $('#cab-confere').hidden = !confere;
  atualizarOrcamento();
}

/* orçamento do grupo escolhido, com o peso desta nota */
function atualizarOrcamento() {
  const caixa = $('#grupo-orc');
  const id = campos.grupo_id.value && !campos.grupo_id.value.startsWith('__') ? Number(campos.grupo_id.value) : null;
  const g = estado.grupos.find((x) => x.id === id);
  if (!g || g.orcamento == null || Number(g.orcamento) <= 0 || !estado.nota) { caixa.hidden = true; return; }
  caixa.hidden = false;
  const orc = Number(g.orcamento);
  const ja = Number(g.gasto);
  const contada = estado.nota.status !== 'lido' && estado.nota.grupo_id === g.id;   // já está dentro do gasto
  const v = campoParaDec(campos.valor_total.value);
  const esta = !contada && v.valor ? Number(v.valor) : 0;
  const pctJa = Math.min(100, (ja / orc) * 100);
  const pctEsta = Math.max(0, Math.min(100 - pctJa, (esta / orc) * 100));
  $('#orc-nome').textContent = g.nome;
  $('#orc-valores').textContent = `${fmtBRL(ja)} de ${fmtBRL(orc)}`;
  $('#orc-fill').style.width = `${pctJa}%`;
  $('#orc-esta').style.width = `${pctEsta}%`;
  const depois = ((ja + esta) / orc) * 100;
  const nota = $('#orc-nota');
  nota.classList.toggle('estourou', depois > 100);
  nota.textContent = contada ? `Esta nota já está somada: ${Math.round((ja / orc) * 100)}% do orçamento.`
    : `Com esta nota: ${Math.round(depois)}% do orçamento${depois > 100 ? ' (passa do previsto)' : ''}.`;
}

function mostrarNota(nota) {
  $('#vazio').hidden = true; $('#painel').hidden = true; $('#area').hidden = false;
  const editavel = nota.status === 'lido';

  const chip = $('#chip-status');
  chip.textContent = STATUS[nota.status];
  chip.className = `selo-estado${editavel ? '' : ' selo-estado--ok'}`;
  $('#chip-origem').textContent = ORIGEM[nota.origem];
  $('#nota-arquivo').textContent = nota.arquivo_nome || 'Sem arquivo anexado';

  campos.fornecedor.value = nota.fornecedor ?? '';
  campos.cnpj.value = fmtCnpj(nota.cnpj);
  campos.numero.value = nota.numero ?? '';
  campos.data_emissao.value = nota.data_emissao ?? '';
  campos.valor_total.value = decParaCampo(nota.valor_total);
  campos.chave_acesso.value = nota.chave_acesso ?? '';
  campos.observacoes.value = nota.observacoes ?? '';
  for (const el of Object.values(campos)) el.disabled = !editavel;
  campos.categoria_id.hidden = true;
  const sugestao = sugerirLancamento(nota);
  popularSelects(sugestao ? { ...nota, grupo_id: sugestao.grupo_id, categoria_id: sugestao.categoria_id } : nota);
  const dica = $('#dica-sugestao');
  dica.hidden = !sugestao;
  if (sugestao) dica.textContent = 'sugerida pela última nota deste fornecedor';
  popularMeses(nota.competencia || (nota.data_emissao || '').slice(0, 7));
  renderItens(nota.itens, editavel);
  atualizarContadorChave();

  $('#alerta-pedido').hidden = nota.tipo_documento !== 'pedido_ou_comprovante';
  const faixa = $('#faixa');
  faixa.hidden = false;
  if (!editavel) faixa.textContent = 'Esta nota já foi arquivada. Reabra para editar.';
  else if (nota.origem === 'pdf') faixa.textContent = 'Lido do texto do PDF. Os itens não vêm nesta leitura.';
  else if (nota.origem === 'claude') faixa.textContent = 'Lido pelo Claude a partir da imagem. Compare com o documento ao lado.';
  else if (nota.origem === 'ocr') faixa.textContent = 'Lido da foto no seu computador. Compare cada campo com o documento ao lado.';
  else if (nota.origem === 'xml') faixa.textContent = 'Lido direto do XML da nota: dados exatos.';
  else faixa.hidden = true;

  atualizarNavegacao(nota);
  marcarCampos(nota);
  $('#btn-validar').hidden = $('#btn-excluir').hidden = !editavel;
  $('#btn-reabrir').hidden = editavel;
  estado.original = lerForm();
  atualizarCabeca();
  atualizarSujo();
}

function atualizarNavegacao(nota) {
  const i = estado.fila.findIndex((n) => n.id === nota.id);
  const nav = $('#fila-nav');
  nav.hidden = nota.status !== 'lido' || i < 0 || estado.fila.length < 2;
  $('#validar-txt').textContent = nota.status === 'lido' && estado.fila.some((n) => n.id !== nota.id) ? 'Arquivar e ir para a próxima' : 'Arquivar';
  if (nav.hidden) return;
  $('#nav-pos').textContent = `${i + 1} de ${estado.fila.length}`;
  $('#nav-ant').disabled = i === 0;
  $('#nav-prox').disabled = i === estado.fila.length - 1;
}

async function vizinha(delta) {
  const i = estado.fila.findIndex((n) => n.id === estado.nota?.id);
  const alvo = estado.fila[i + delta];
  if (i >= 0 && alvo) await abrirNota(alvo.id);
}

/* marcas por campo: erro (vermelho), leitura incerta ou aviso (âmbar) */
function marcarCampos(nota) {
  const relevantes = avisosRelevantes(nota);
  const nivelDo = {};
  for (const a of relevantes) if (nivelDo[a.campo] !== 'erro') nivelDo[a.campo] = a.nivel;
  const editavel = nota.status === 'lido';
  const wraps = [...$$('.campo[data-campo]'), $('#itens')];
  const pendentes = new Set();
  for (const w of wraps) {
    const c = w.dataset.campo;
    w.classList.remove('campo--erro', 'campo--aviso', 'campo--incerto');
    const conf = nota.confianca[c];
    const incerto = editavel && (conf === 'baixa' || conf === 'media');
    if (nivelDo[c] === 'erro') w.classList.add('campo--erro');
    else if (incerto && conf === 'baixa') w.classList.add('campo--incerto');
    else if (nivelDo[c] === 'aviso') w.classList.add('campo--aviso');
    if (editavel && CAMPOS_DADOS.includes(c) && (incerto || nivelDo[c] === 'erro' || (nivelDo[c] === 'aviso' && c !== 'chave_acesso'))) pendentes.add(c);
    const selo = $('.selo-campo', w);
    if (selo) {
      selo.hidden = !incerto;
      selo.textContent = conf === 'baixa' ? 'Leitura incerta: confirmar' : 'Confirmar';
      selo.onclick = (e) => { e.preventDefault(); confirmarCampo(c); };
    }
  }

  // seção "Dados da nota": abre sozinha quando há o que conferir
  const vazios = editavel && (!nota.fornecedor || !nota.data_emissao || nota.valor_total == null);
  const dados = $('#dados');
  dados.open = editavel && (pendentes.size > 0 || vazios || nota.origem === 'manual');
  const resumoDados = $('#dados-resumo');
  resumoDados.className = 'secao-resumo';
  if (!editavel) resumoDados.textContent = '';
  else if (pendentes.size) { resumoDados.textContent = `${pendentes.size} para conferir`; resumoDados.classList.add('secao-resumo--aviso'); }
  else if (vazios) { resumoDados.textContent = 'preencha os dados'; resumoDados.classList.add('secao-resumo--aviso'); }
  else if (nota.chave_acesso && !nivelDo.chave_acesso) { resumoDados.textContent = 'conferidos pela chave de acesso'; resumoDados.classList.add('secao-resumo--ok'); }
  else if (nota.origem === 'xml') { resumoDados.textContent = 'dados exatos do XML'; resumoDados.classList.add('secao-resumo--ok'); }
  else resumoDados.textContent = '';

  // o aviso de "pedido" tem o seu próprio cartão; os demais vão para o resumo
  const avisos = relevantes;
  const erros = avisos.filter((a) => a.nivel === 'erro');
  const resumo = $('#resumo');
  resumo.hidden = avisos.length === 0 || !editavel;
  resumo.classList.toggle('resumo--erro', erros.length > 0);
  $('#resumo-titulo').textContent = erros.length
    ? `${erros.length === 1 ? '1 ponto a corrigir' : `${erros.length} pontos a corrigir`} antes de arquivar`
    : `${avisos.length === 1 ? '1 ponto' : `${avisos.length} pontos`} para conferir`;
  const ordenados = [...erros, ...avisos.filter((a) => a.nivel === 'aviso')];
  $('#resumo-lista').replaceChildren(...ordenados.map((a) => {
    const rotulo = h('span', { class: 'marca-nivel' }, a.nivel === 'erro' ? 'Corrigir' : 'Conferir');
    const alvo = campos[a.campo] || a.campo === 'itens';
    return h('li', { class: 'nv-' + a.nivel },
      alvo ? h('button', { type: 'button', onclick: () => focarCampo(a.campo) }, rotulo, h('span', {}, a.mensagem))
        : h('span', { class: 'sem-alvo' }, rotulo, h('span', {}, a.mensagem)));
  }));
}

function focarCampo(nome) {
  if (nome === 'itens') { $('#itens').open = true; ($('#itens-corpo input') || $('#item-novo')).focus(); return; }
  if (CAMPOS_DADOS.includes(nome)) $('#dados').open = true;
  if (nome === 'categoria_id') { const b = $('#cat-chips .chip'); if (b) { b.focus(); return; } }
  const el = campos[nome]; if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.focus(); }
}

/* ------------------------------------------------------------------ itens */
function linhaItem(i = {}, editavel = true) {
  const entrada = (classe, rotulo, valor, extra = {}) => h('input', { class: classe, 'aria-label': rotulo, value: valor, disabled: !editavel, ...extra });
  const tr = h('tr', {},
    h('td', {}, entrada('i-desc', 'Descrição do item', i.descricao ?? '')),
    h('td', {}, entrada('i-qtd n', 'Quantidade', i.quantidade ?? '', { inputmode: 'decimal' })),
    h('td', {}, entrada('i-unit n', 'Valor unitário', decParaCampo(i.valor_unitario), { inputmode: 'decimal' })),
    h('td', {}, entrada('i-total n', 'Valor total do item', decParaCampo(i.valor_total), { inputmode: 'decimal' })),
    h('td', {}, editavel ? h('button', { type: 'button', class: 'item-remover', 'aria-label': 'Remover item',
      onclick: () => { tr.remove(); aoMudarItens(); } }, '×') : null));
  tr.addEventListener('input', aoMudarItens);
  return tr;
}

function renderItens(itens, editavel) {
  $('#itens-corpo').replaceChildren(...itens.map((i) => linhaItem(i, editavel)));
  $('#item-novo').hidden = !editavel;
  $('#itens').open = itens.length > 0 && itens.length <= 6;
  atualizarResumoItens();
}

function lerItens() {
  const num = (t) => { const d = campoParaDec(t); return d.vazio ? null : d.erro ? '__invalido__' : d.valor; };
  return $$('#itens-corpo tr').map((tr) => {
    const q = $('.i-qtd', tr).value.trim().replace(',', '.');
    return {
      descricao: $('.i-desc', tr).value.trim(),
      quantidade: q === '' ? null : (Number.isFinite(Number(q)) ? Number(q) : '__invalido__'),
      valor_unitario: num($('.i-unit', tr).value),
      valor_total: num($('.i-total', tr).value),
    };
  }).filter((i) => i.descricao || i.quantidade != null || i.valor_unitario != null || i.valor_total != null);
}

function atualizarResumoItens() {
  const itens = lerItens();
  const el = $('#itens-resumo');
  el.classList.remove('diverge');
  if (!itens.length) { el.textContent = 'nenhum item'; return; }
  const centavos = itens.map((i) => (i.valor_total && i.valor_total !== '__invalido__' ? Math.round(Number(i.valor_total) * 100) : null));
  let texto = `${itens.length} ${itens.length === 1 ? 'item' : 'itens'}`;
  if (centavos.every((c) => c != null)) {
    const soma = centavos.reduce((a, b) => a + b, 0);
    texto += `, soma ${fmtBRL(soma / 100)}`;
    const total = campoParaDec(campos.valor_total.value);
    if (total.valor && Math.abs(soma - Math.round(Number(total.valor) * 100)) > 5) {
      texto += `, difere do total em ${fmtBRL(Math.abs(soma - Math.round(Number(total.valor) * 100)) / 100)}`;
      el.classList.add('diverge');
    }
  }
  el.textContent = texto;
}

function aoMudarItens() { atualizarResumoItens(); atualizarCabeca(); atualizarSujo(); }

/* ------------------------------------------------------------------ ler o formulário e detectar alterações */
function lerForm() {
  const v = campoParaDec(campos.valor_total.value);
  const idDe = (el) => (el.value && !el.value.startsWith('__') ? Number(el.value) : null);
  return {
    fornecedor: campos.fornecedor.value.trim() || null,
    cnpj: normDoc(campos.cnpj.value),
    numero: campos.numero.value.trim() || null,
    data_emissao: campos.data_emissao.value || null,
    valor_total: v.vazio ? null : (v.erro ? '__invalido__' : v.valor),
    chave_acesso: normDoc(campos.chave_acesso.value),
    grupo_id: idDe(campos.grupo_id),
    categoria_id: idDe(campos.categoria_id),
    competencia: campos.competencia.value || null,
    observacoes: campos.observacoes.value.trim() || null,
    forma_pagamento: campos.forma_pagamento.value || null,
    conta_id: idDe(campos.conta_id),
    itens: lerItens(),
  };
}

function diferencas() {
  const atual = lerForm(); const original = estado.original || {}; const dif = {};
  for (const k of Object.keys(atual)) {
    if (k === 'competencia' && !estado.competenciaManual) continue; // o servidor deriva da data de emissão
    if (k === 'conta_id') continue;                                   // é do lançamento: vai junto ao arquivar
    if (JSON.stringify(atual[k]) !== JSON.stringify(original[k])) dif[k] = atual[k];
  }
  return dif;
}

const estaSujo = () => estado.nota?.status === 'lido' && Object.keys(diferencas()).length > 0;

// escolher categoria, grupo ou mês não conta como "alteração não salva": isso é gravado ao arquivar
const CAMPOS_DO_LANCAMENTO = ['grupo_id', 'categoria_id', 'competencia', 'forma_pagamento', 'conta_id'];
function atualizarSujo() {
  const sujo = estado.nota?.status === 'lido' && Object.keys(diferencas()).some((k) => !CAMPOS_DO_LANCAMENTO.includes(k));
  $('#sujo').hidden = !sujo;
  $('#btn-salvar').hidden = !sujo;
}

function atualizarContadorChave() {
  const n = (normDoc(campos.chave_acesso.value) || '').length;
  const el = $('#chave-contador');
  el.textContent = n ? `${n}/44` : '';
  el.classList.toggle('erro', n > 0 && n !== 44);
}

/* ------------------------------------------------------------------ salvar, confirmar, validar */
function conferirPayload(dif) {
  if (dif.valor_total === '__invalido__') throw new ErroForm('Valor total inválido. Digite números, como 1.234,56.', 'valor_total');
  if (dif.chave_acesso && dif.chave_acesso.length !== 44) throw new ErroForm('A chave de acesso deve ter 44 caracteres.', 'chave_acesso');
  if (dif.itens) {
    if (dif.itens.some((i) => !i.descricao)) throw new ErroForm('Informe a descrição de cada item (ou remova a linha).', 'itens');
    if (dif.itens.some((i) => Object.values(i).includes('__invalido__'))) throw new ErroForm('Há números inválidos nos itens.', 'itens');
  }
}

async function salvar({ silencioso = false, forcar = [] } = {}) {
  const nota = estado.nota;
  if (!nota || nota.status !== 'lido') return nota;
  const dif = diferencas();
  const atual = forcar.length ? lerForm() : null;
  for (const k of forcar) dif[k] = atual[k];
  if (!Object.keys(dif).length) return nota;
  conferirPayload(dif);
  const atualizada = await api(`/notas/${nota.id}`, { metodo: 'PATCH', json: dif });
  aplicarNota(atualizada);
  if (!silencioso) avisar('Correções salvas.', 'ok');
  return atualizada;
}

function aplicarNota(nota) {
  estado.nota = nota;
  const i = estado.fila.findIndex((n) => n.id === nota.id);
  if (i >= 0) estado.fila[i] = nota;
  const manual = estado.competenciaManual;
  mostrarNota(nota);
  estado.competenciaManual = manual && Boolean(nota.competencia);
  renderLista();
}

async function confirmarCampo(campo) {
  const atual = lerForm();
  if (atual[campo] == null || atual[campo] === '__invalido__' || (campo === 'itens' && !atual.itens.length)) {
    avisar('Preencha o campo corretamente antes de confirmar.', 'erro'); focarCampo(campo); return;
  }
  try { await salvar({ silencioso: true, forcar: [campo] }); avisar(`${ROTULOS[campo]} confirmado.`, 'ok'); }
  catch (e) { erroParaTela(e); if (e.campo) focarCampo(e.campo); }
}

async function validar() {
  const nota = estado.nota;
  if (!nota || nota.status !== 'lido') return;
  const botao = $('#btn-validar'); botao.disabled = true;
  try {
    const f = lerForm();
    if (!f.categoria_id) {
      $('.campo[data-campo="categoria_id"]').classList.add('campo--erro');
      throw new ErroForm('Escolha a categoria desta nota.', 'categoria_id');
    }
    if (!f.competencia) throw new ErroForm('Escolha em qual mês da planilha a nota entra.', 'competencia');
    await salvar({ silencioso: true });
    const validada = await api(`/notas/${nota.id}/validar`, {
      metodo: 'POST', json: { grupo_id: f.grupo_id, categoria_id: f.categoria_id, competencia: f.competencia, conta_id: f.conta_id },
    });
    localStorage.setItem('nf_ultimo_grupo', String(f.grupo_id ?? ''));
    try { localStorage.setItem('nf_ultima_conta', String(f.conta_id ?? '')); } catch { /* ok */ }
    const grupo = estado.grupos.find((e) => e.id === f.grupo_id);
    avisar(`${validada.fornecedor || `Nota #${validada.id}`} arquivada${grupo ? ` em ${grupo.nome}` : ''}, planilha de ${fmtMesCurto(validada.competencia)}.`, 'ok',
      { acao: { rotulo: 'Desfazer', fn: () => desfazerArquivamento(validada.id) }, duracao: 10000 });
    const posicao = estado.fila.findIndex((n) => n.id === nota.id);
    await Promise.all([carregarListas(), carregarCatalogos()]);
    const proxima = estado.fila[Math.min(Math.max(posicao, 0), estado.fila.length - 1)];
    estado.nota = null;
    atualizarTotalMes();
    if (proxima) await abrirNota(proxima.id); else mostrarVazio();
  } catch (e) {
    erroParaTela(e);
    if (e.campo) focarCampo(e.campo);
    if (e.dados?.avisos) { try { aplicarNota(await api(`/notas/${nota.id}`)); } catch { /* mantém a tela */ } }
  } finally { botao.disabled = false; }
}

async function desfazerArquivamento(id) {
  try {
    if (estado.nota && !(await salvarSePreciso())) return;
    await api(`/notas/${id}/reabrir`, { metodo: 'POST' });
    await Promise.all([carregarListas(), carregarCatalogos()]);
    estado.nota = null;
    await abrirNota(id);
    atualizarTotalMes();
  } catch (e) { erroParaTela(e); }
}

async function reabrir() {
  const nota = estado.nota; if (!nota) return;
  if (nota.status === 'lancado' && !confirm('Esta nota já saiu em uma planilha. Reabrir mesmo assim?')) return;
  try {
    const aberta = await api(`/notas/${nota.id}/reabrir`, { metodo: 'POST' });
    await carregarListas();
    estado.nota = null;
    await abrirNota(aberta.id);
    atualizarTotalMes();
  } catch (e) { erroParaTela(e); }
}

async function excluir() {
  const nota = estado.nota; if (!nota) return;
  if (!confirm(`Excluir a nota #${nota.id} e o arquivo enviado? Isso não pode ser desfeito.`)) return;
  try {
    await api(`/notas/${nota.id}`, { metodo: 'DELETE' });
    estado.nota = null;
    await carregarListas();
    avisar(`Nota #${nota.id} excluída.`, 'ok');
    atualizarTotalMes();
    if (estado.fila[0]) await abrirNota(estado.fila[0].id); else mostrarVazio();
  } catch (e) { erroParaTela(e); }
}

function mostrarVazio() {
  limparMesa();
  estado.nota = null;
  $('#area').hidden = true;
  const temHistorico = estado.arquivadas.length > 0;
  $('#vazio').hidden = temHistorico;
  $('#painel').hidden = !temHistorico;
  renderLista();
  if (temHistorico) carregarResumo();
}

/* ------------------------------------------------------------------ painel do mês */
function renderPainel(r) {
  const vazio = r.qtd === 0 && !r.qtd_receitas;
  const fila = estado.fila.length;
  const estadoEl = $('#painel-estado');
  estadoEl.className = `painel-estado${fila ? ' painel-estado--aviso' : ''}`;
  estadoEl.textContent = fila ? `${fila} ${fila === 1 ? 'nota esperando' : 'notas esperando'} conferência` : 'Tudo conferido';
  $('#painel-titulo').textContent = maiuscula(fmtMesLongo(r.competencia));
  const lancar = $('#painel-lancar');
  lancar.hidden = !r.qtd_a_lancar;
  lancar.textContent = `Baixar e marcar ${r.qtd_a_lancar} ${r.qtd_a_lancar === 1 ? 'nota' : 'notas'} como lançadas`;

  $('#kpi-total').textContent = fmtBRL(r.total_centavos / 100);
  $('#kpi-total-nota').textContent = r.total_mes_anterior_centavos
    ? `${MESES[partesMes(r.mes_anterior).mes - 1]}: ${fmtBRL(r.total_mes_anterior_centavos / 100)}` : '';
  const anterior = $('#kpi-total-nota').textContent;
  $('#kpi-total-nota').textContent = [`${r.qtd} ${r.qtd === 1 ? 'lançamento' : 'lançamentos'}`, anterior].filter(Boolean).join(' · ');
  $('#kpi-rec').textContent = fmtBRL((r.receitas_centavos || 0) / 100);
  $('#kpi-rec-nota').textContent = r.qtd_receitas ? `${r.qtd_receitas} ${r.qtd_receitas === 1 ? 'lançamento' : 'lançamentos'}` : 'nenhuma receita lançada';
  const saldo = r.saldo_centavos ?? -r.total_centavos;
  $('#kpi-saldo').textContent = fmtSaldo(saldo);
  $('#kpi-saldo').classList.toggle('saldo-negativo', saldo < 0);
  $('#kpi-saldo').classList.toggle('kpi-valor--receita', saldo > 0);
  const maior = r.por_categoria[0];
  $('#kpi-cat').textContent = maior ? maior.nome : '—';
  $('#kpi-cat-nota').textContent = maior && r.total_centavos ? `${Math.round((maior.total_centavos / r.total_centavos) * 100)}% do mês` : '';

  const topo = Math.max(1, ...r.por_categoria.map((c) => c.total_centavos));
  $('#barras-cat').replaceChildren(...(r.por_categoria.length ? r.por_categoria.map((c) => {
    const pct = r.total_centavos ? Math.round((c.total_centavos / r.total_centavos) * 100) : 0;
    const dica = `${c.nome}: ${fmtBRL(c.total_centavos / 100)} em ${c.qtd} ${c.qtd === 1 ? 'nota' : 'notas'} (${pct}% do mês)`;
    return h('div', { class: 'barra-linha', title: dica },
      h('span', { class: 'barra-nome' }, c.nome),
      h('span', { class: 'barra-trilho', role: 'img', 'aria-label': dica }, h('span', { class: 'barra', style: `width:${(c.total_centavos / topo) * 100}%` })),
      h('span', { class: 'barra-valor num' }, fmtBRL(c.total_centavos / 100)));
  }) : [h('p', { class: 'cartao-vazio' }, 'Nada arquivado neste mês.')]));

  $('#grupos-mes').replaceChildren(...(r.por_grupo.length ? r.por_grupo.map((g) => {
    const filhos = [h('div', { class: 'grupo-linha' }, h('strong', {}, g.nome), h('span', { class: 'num' }, fmtBRL(g.total_centavos / 100)))];
    if (g.orcamento_centavos) {
      const pct = (g.acumulado_centavos / g.orcamento_centavos) * 100;
      filhos.push(h('span', { class: `orc-barra${pct > 100 ? ' estourou' : ''}`, role: 'img', 'aria-label': `${Math.round(pct)}% do orçamento` },
        h('span', { style: `width:${Math.min(100, pct)}%` })));
      filhos.push(h('span', { class: 'grupo-nota' }, `${Math.round(pct)}% do orçamento de ${fmtBRL(g.orcamento_centavos / 100)} (todos os meses)`));
    } else filhos.push(h('span', { class: 'grupo-nota' }, `${g.qtd} ${g.qtd === 1 ? 'despesa' : 'despesas'} neste mês`));
    return h('div', { class: 'grupo-item' }, ...filhos);
  }) : [h('p', { class: 'cartao-vazio' }, 'Nenhum grupo neste mês.')]));

  $('#ultimas').replaceChildren(...r.ultimas.map((u) => h('tr', {},
    h('td', { class: 'u-data' }, fmtDataCurta(u.data_emissao)),
    h('td', {}, h('button', { type: 'button', class: 'link',
      onclick: () => (u.id ? abrirNota(u.id) : abrirLancamento(u.lancamento_id)) }, u.fornecedor || `Nota #${u.id}`),
      u.tipo_documento === 'pedido_ou_comprovante' ? h('span', { class: 'pilula pilula--aviso' }, 'pedido') : null),
    h('td', { class: 'u-cat' }, [u.categoria, u.grupo].filter(Boolean).join(' · ')),
    h('td', { class: `u-valor num${u.tipo === 'receita' ? ' l-valor--receita' : ''}` },
      `${u.tipo === 'receita' ? '+ ' : ''}${fmtBRL(u.valor_total_centavos / 100)}`))));
  $('#painel-vazio').hidden = !vazio;
}

/* ------------------------------------------------------------------ mesa: visualizador do documento *//* ------------------------------------------------------------------ mesa: visualizador do documento */
const mesa = { url: null, urlGirada: null, img: null, blob: null, nome: '', zoom: 1 };

function limparMesa() {
  for (const k of ['url', 'urlGirada']) if (mesa[k]) { URL.revokeObjectURL(mesa[k]); mesa[k] = null; }
  Object.assign(mesa, { img: null, blob: null, nome: '', zoom: 1 });
  $('#palco').classList.remove('ampliado', 'arrastando', 'palco--papel');
}

function avisoPalco(titulo, texto, botao) {
  return h('div', { class: 'palco-aviso' }, h('strong', {}, titulo), h('p', {}, texto), botao);
}
const botaoBaixar = () => h('button', { type: 'button', class: 'btn-mesa', onclick: baixarOriginal }, 'Baixar arquivo');

function controlesDaMesa({ imagem, arquivo }) {
  $('#mesa-zoom').hidden = !imagem;
  $('#m-baixar').hidden = !arquivo;
}

function seloDaMesa(texto, tipo = 'ok') {
  const selo = $('#mesa-selo');
  selo.hidden = !texto;
  selo.className = `mesa-selo mesa-selo--${tipo}`;
  selo.textContent = texto || '';
}

/* XML: a nota desenhada como papel, com os dados que vieram do arquivo */
function renderPapel(nota) {
  const linhaItem = (i) => h('tr', {}, h('td', {}, i.descricao),
    h('td', { class: 'n' }, i.quantidade != null ? Number(i.quantidade).toLocaleString('pt-BR') : ''),
    h('td', { class: 'n' }, i.valor_unitario != null ? decParaCampo(i.valor_unitario) : ''),
    h('td', { class: 'n' }, i.valor_total != null ? decParaCampo(i.valor_total) : ''));
  const chave = nota.chave_acesso || '';
  const chaveOk = chave.length === 44 && !nota.avisos.some((a) => a.campo === 'chave_acesso');
  return h('article', { class: 'papel', 'aria-label': 'Nota fiscal lida do XML' },
    h('div', { class: 'papel-faixa' }),
    h('header', { class: 'papel-cabeca' },
      h('div', {}, h('span', { class: 'papel-rotulo' }, 'Emitente'),
        h('p', { class: 'papel-nome' }, nota.fornecedor || '—'),
        h('p', { class: 'papel-sub num' }, nota.cnpj ? `CNPJ ${fmtCnpj(nota.cnpj)}` : '')),
      h('div', { class: 'papel-dir' }, h('span', { class: 'papel-rotulo' }, chave.slice(20, 22) === '65' ? 'NFC-e' : 'NF-e'),
        h('p', { class: 'papel-nome' }, nota.numero ? `Nº ${Number(nota.numero).toLocaleString('pt-BR')}` : '—'),
        h('p', { class: 'papel-sub' }, [nota.serie ? `Série ${nota.serie}` : '', nota.data_emissao ? `emitida em ${fmtDataLonga(nota.data_emissao)}` : ''].filter(Boolean).join(' · ')))),
    nota.itens.length ? h('table', { class: 'papel-itens' },
      h('thead', {}, h('tr', {}, h('th', { scope: 'col' }, 'Produto'), h('th', { scope: 'col', class: 'n' }, 'Qtd.'),
        h('th', { scope: 'col', class: 'n' }, 'Unitário'), h('th', { scope: 'col', class: 'n' }, 'Total'))),
      h('tbody', {}, ...nota.itens.map(linhaItem))) : h('p', { class: 'papel-sem-itens' }, 'O XML não trouxe itens.'),
    h('div', { class: 'papel-total' }, h('div', {}, h('span', {}, 'Valor total da nota'), h('strong', { class: 'num' }, fmtBRL(nota.valor_total)))),
    chave ? h('footer', { class: 'papel-chave' },
      h('span', { class: 'papel-rotulo' }, 'Chave de acesso ', h('span', { class: `pilula ${chaveOk ? 'pilula--ok' : 'pilula--aviso'}` }, chaveOk ? 'válida' : 'conferir')),
      h('p', { class: 'num' }, chave.replace(/(.{4})/g, '$1 ').trim())) : null);
}

async function carregarArquivo(nota) {
  limparMesa();
  const palco = $('#palco');
  controlesDaMesa({ imagem: false, arquivo: false });
  if (!nota.tem_arquivo) {
    seloDaMesa('');
    palco.replaceChildren(avisoPalco('Sem arquivo anexado',
      nota.status === 'lido' ? 'Este lançamento foi feito à mão. Você pode anexar a foto ou o comprovante.' : 'Este lançamento foi feito à mão e não tem arquivo.',
      nota.status === 'lido' ? h('button', { type: 'button', class: 'btn-mesa', onclick: () => $('#in-anexo').click() }, 'Anexar foto ou documento') : null));
    return;
  }
  seloDaMesa(nota.origem === 'xml' ? 'Lida do XML: dados exatos' : nota.origem === 'ocr' ? 'Lida da foto no seu computador'
    : nota.origem === 'claude' ? 'Lida pelo Claude' : nota.origem === 'pdf' ? 'Lida do texto do PDF' : '', nota.origem === 'xml' || nota.origem === 'pdf' ? 'ok' : 'neutro');
  palco.replaceChildren(avisoPalco('Carregando documento…', ''));
  let blob;
  try { blob = await api(`/notas/${nota.id}/arquivo`, { blob: true }); }
  catch (e) { if (estado.nota?.id === nota.id) palco.replaceChildren(avisoPalco('Não foi possível abrir o arquivo', e.message)); return; }
  if (estado.nota?.id !== nota.id) return; // a pessoa já abriu outra nota
  mesa.blob = blob; mesa.nome = nota.arquivo_nome || 'arquivo';
  const mime = nota.arquivo_mime || '';

  if (mime.startsWith('image/')) mostrarImagem(blob, nota);
  else if (mime === 'application/pdf') {
    mesa.url = URL.createObjectURL(blob);
    palco.replaceChildren(h('iframe', { title: 'Documento PDF', src: mesa.url }));
    controlesDaMesa({ imagem: false, arquivo: true });
  } else if (mime === 'application/xml') {
    palco.replaceChildren(renderPapel(nota));
    palco.classList.add('palco--papel');
    controlesDaMesa({ imagem: false, arquivo: true });
  } else {
    palco.replaceChildren(avisoPalco('Pré-visualização indisponível', 'Este tipo de documento não abre aqui. Baixe para conferir os valores.', botaoBaixar()));
    controlesDaMesa({ imagem: false, arquivo: true });
  }
}

const ROTULO_REGIAO = { fornecedor: 'Fornecedor', cnpj: 'CNPJ', data_emissao: 'Data', valor_total: 'Total' };

function mostrarImagem(blob, nota) {
  mesa.url = URL.createObjectURL(blob);
  mesa.zoom = 1;
  const img = h('img', { alt: 'Documento enviado' });
  // destaques: onde cada campo foi lido na foto (só a leitura local guarda essas posições)
  const marcas = Object.entries(nota?.regioes || {}).filter(([c]) => ROTULO_REGIAO[c]).map(([c, [x0, y0, x1, y1]]) => {
    const folga = 0.006;
    return h('span', {
      class: 'marca-leitura', 'data-campo': c, 'aria-hidden': 'true',
      style: `left:${(x0 - folga) * 100}%;top:${(y0 - folga) * 100}%;width:${(x1 - x0 + 2 * folga) * 100}%;height:${(y1 - y0 + 2 * folga) * 100}%`,
    }, h('span', { class: 'marca-rotulo' }, ROTULO_REGIAO[c]));
  });
  const foto = h('div', { class: 'foto' }, img, ...marcas);
  img.addEventListener('load', ajustarImagem);
  img.addEventListener('error', () => {
    $('#palco').replaceChildren(avisoPalco('Não consegui exibir esta imagem', 'Formatos como HEIC não abrem em todos os navegadores. Baixe para ver.', botaoBaixar()));
    controlesDaMesa({ imagem: false, arquivo: true });
  });
  img.addEventListener('dblclick', (e) => zoomPara(mesa.zoom > 1 ? 1 : 2.5, e));
  img.src = mesa.url;
  mesa.img = img;
  $('#palco').replaceChildren(foto);
  controlesDaMesa({ imagem: true, arquivo: true });
}

function ajustarImagem() {
  if (!mesa.img) return;
  const largura = Math.max(160, ($('#palco').clientWidth - 32) * mesa.zoom);
  mesa.img.style.width = `${largura}px`;
  $('#palco').classList.toggle('ampliado', mesa.zoom > 1);
}

function zoomPara(novo, ev) {
  if (!mesa.img) return;
  const palco = $('#palco');
  const antes = mesa.img.clientWidth;
  const relX = ev ? ev.offsetX / antes : 0.5;
  const relY = ev ? ev.offsetY / mesa.img.clientHeight : 0;
  mesa.zoom = Math.min(6, Math.max(0.5, novo));
  ajustarImagem();
  if (ev) {
    palco.scrollLeft = relX * mesa.img.clientWidth - palco.clientWidth / 2;
    palco.scrollTop = mesa.img.offsetTop + relY * mesa.img.clientHeight - palco.clientHeight / 2;
  }
}

async function girarImagem() {
  const img = mesa.img; if (!img || !img.complete) return;
  const c = document.createElement('canvas');
  c.width = img.naturalHeight; c.height = img.naturalWidth;
  const ctx = c.getContext('2d');
  ctx.translate(c.width / 2, c.height / 2); ctx.rotate(Math.PI / 2);
  ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
  const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.92));
  if (mesa.urlGirada) URL.revokeObjectURL(mesa.urlGirada);
  mesa.urlGirada = URL.createObjectURL(blob);
  img.src = mesa.urlGirada; // só a visualização gira; o arquivo guardado não muda
  $$('.marca-leitura').forEach((m) => m.remove()); // as posições valem para a foto como foi enviada
}

function baixarBlob(blob, nome) {
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: nome });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
const baixarOriginal = () => mesa.blob && baixarBlob(mesa.blob, mesa.nome);

function ligarMesa() {
  const palco = $('#palco');
  $('#z-menos').onclick = () => zoomPara(mesa.zoom / 1.25);
  $('#z-mais').onclick = () => zoomPara(mesa.zoom * 1.25);
  $('#z-ajustar').onclick = () => { mesa.zoom = 1; ajustarImagem(); palco.scrollTo(0, 0); };
  $('#z-girar').onclick = girarImagem;
  $('#m-baixar').onclick = baixarOriginal;
  palco.addEventListener('wheel', (e) => { if (e.ctrlKey && mesa.img) { e.preventDefault(); zoomPara(mesa.zoom * (e.deltaY < 0 ? 1.15 : 1 / 1.15), e); } }, { passive: false });
  new ResizeObserver(ajustarImagem).observe(palco);

  let arrasto = null; // arrastar para mover a imagem ampliada
  palco.addEventListener('pointerdown', (e) => {
    if (!palco.classList.contains('ampliado') || e.target !== mesa.img) return;
    arrasto = { x: e.clientX, y: e.clientY, sl: palco.scrollLeft, st: palco.scrollTop };
    palco.setPointerCapture(e.pointerId); palco.classList.add('arrastando');
  });
  palco.addEventListener('pointermove', (e) => {
    if (!arrasto) return;
    palco.scrollLeft = arrasto.sl - (e.clientX - arrasto.x); palco.scrollTop = arrasto.st - (e.clientY - arrasto.y);
  });
  const soltar = () => { arrasto = null; palco.classList.remove('arrastando'); };
  palco.addEventListener('pointerup', soltar); palco.addEventListener('pointercancel', soltar);
}

/* ------------------------------------------------------------------ envio de arquivos */
const LEGIVEIS = /\.(xml|pdf|jpe?g|png|webp|heic|heif)$/i;
const ehXml = (f) => /\.xml$/i.test(f.name) || /xml/.test(f.type);
const ehPdf = (f) => /\.pdf$/i.test(f.name) || f.type === 'application/pdf';
const podeLer = (f) => LEGIVEIS.test(f.name) || f.type.startsWith('image/') || f.type === 'application/pdf' || ehXml(f);

function itemEnvio(nome, { lendo = false } = {}) {
  const estadoEl = h('span', { class: 'estado' }, lendo ? 'Lendo…' : 'Enviando…');
  const msg = h('span', { class: 'envio-msg', style: 'grid-column:1/-1;font-size:13px', hidden: true });
  const acoes = h('div', { class: 'acoes' });
  const barra = h('span', { class: 'envio-barra', 'aria-hidden': 'true' }, h('span', {}));
  const li = h('li', { class: `envio-item${lendo ? ' envio-item--lendo' : ''}` }, h('span', { class: 'nome', title: nome }, nome), estadoEl, barra, msg, acoes);
  $('#envios').prepend(li);
  // contador enquanto lê: uma foto pode levar alguns segundos e a tela não pode parecer travada
  const inicio = Date.now();
  const segundos = () => Math.round((Date.now() - inicio) / 1000);
  const relogio = lendo ? setInterval(() => { if (segundos() >= 2) estadoEl.textContent = `Lendo… ${segundos()} s`; }, 1000) : null;
  const parar = () => clearInterval(relogio);
  const fechar = () => { parar(); li.remove(); };
  return {
    info(t) { msg.hidden = false; msg.textContent = t; },
    ok(t) {
      parar(); li.classList.remove('envio-item--lendo'); li.classList.add('envio-item--ok');
      estadoEl.textContent = lendo && segundos() >= 2 ? `${t} · ${segundos()} s` : t; setTimeout(fechar, 2500);
    },
    erro(t, botoes = []) {
      parar(); li.classList.remove('envio-item--lendo'); li.classList.add('envio-item--erro'); estadoEl.textContent = 'Não enviada'; msg.hidden = false; msg.textContent = t;
      for (const b of botoes) acoes.append(h('button', { type: 'button', class: 'btn', onclick: () => { fechar(); b.fn(); } }, b.rotulo));
      acoes.append(h('button', { type: 'button', class: 'btn btn--texto', onclick: fechar }, 'Dispensar'));
    },
    remover: fechar,
  };
}

async function enviarUm(arquivo, { ler } = {}) {
  let lerAgora = ler ?? podeLer(arquivo);
  const item = itemEnvio(arquivo.name, { lendo: lerAgora && !ehXml(arquivo) });
  const limite = estado.saude.limite_upload_mb;
  if (arquivo.size > limite * 1024 * 1024) { item.erro(`O arquivo passa de ${limite} MB.`); return null; }
  if (lerAgora && !estado.saude.leitura_de_fotos && !ehXml(arquivo) && !ehPdf(arquivo)) {  // PDF digital é lido sem chave
    lerAgora = false;
    item.info('Leitura de fotos indisponível neste computador. O arquivo foi anexado; preencha os campos.');
  }
  try {
    const form = new FormData();
    form.append('arquivo', arquivo); form.append('ler', lerAgora ? 'true' : 'false');
    const nota = await api('/notas/upload', { metodo: 'POST', form });
    item.ok('Pronta');
    return nota;
  } catch (e) {
    if (e.status === 409 && e.dados.nota_id) {
      item.erro(e.message, [{ rotulo: `Abrir nota #${e.dados.nota_id}`, fn: () => abrirNota(e.dados.nota_id) }]);
    } else if (lerAgora && (e.status === 422 || e.status === 503)) {
      item.erro(e.message, [{ rotulo: 'Anexar sem ler', fn: async () => {
        const nota = await enviarUm(arquivo, { ler: false });
        if (nota) { receberNaFila(nota); await abrirNota(nota.id); }
      } }]);
    } else item.erro(e.message);
    return null;
  }
}

const LEITURAS_SIMULTANEAS = 3;

function progressoLote(feitos, total) {
  const lote = $('#lote');
  lote.hidden = total < 2 || feitos >= total;
  if (lote.hidden) return;
  $('#lote-txt').textContent = `Lendo ${feitos + 1 > total ? total : feitos + 1} de ${total}…`;
  $('#lote-fill').style.width = `${Math.round((feitos / total) * 100)}%`;
}

/* Várias notas de uma vez: lê até 3 em paralelo, abre a primeira assim que fica pronta (sem esperar o resto)
   e as demais vão entrando na fila "Para conferir". */
async function enviarArquivos(lista) {
  const arquivos = [...lista];
  if (!arquivos.length) return;
  const total = arquivos.length;
  let proximo = 0, feitos = 0, abriu = false, recebidas = 0;
  progressoLote(0, total);
  async function trabalhador() {
    while (proximo < total) {
      const nota = await enviarUm(arquivos[proximo++]);
      feitos++;
      progressoLote(feitos, total);
      if (!nota) continue;
      recebidas++;
      receberNaFila(nota);
      if (!abriu) { abriu = true; await abrirNota(nota.id); }
    }
  }
  await Promise.all(Array.from({ length: Math.min(LEITURAS_SIMULTANEAS, total) }, trabalhador));
  progressoLote(total, total);
  if (total > 1) {
    const falhas = total - recebidas;
    avisar(`${recebidas} de ${total} notas enviadas${falhas ? `; ${falhas} não entraram (veja a lista de envios)` : ''}.`,
      falhas ? 'aviso' : 'ok');
  }
}

async function lancarManual() {
  try {
    if (estado.nota && !(await salvarSePreciso())) return;
    const nota = await api('/notas/manual', { metodo: 'POST' });
    await carregarListas();
    await abrirNota(nota.id);
    campos.fornecedor.focus();
  } catch (e) { erroParaTela(e); }
}

async function anexarComprovante(arquivo) {
  const nota = estado.nota; if (!nota || !arquivo) return;
  try {
    const form = new FormData(); form.append('arquivo', arquivo);
    const atualizada = await api(`/notas/${nota.id}/arquivo`, { metodo: 'POST', form });
    aplicarNota(atualizada); carregarArquivo(atualizada);
    avisar('Arquivo anexado.', 'ok');
  } catch (e) {
    if (e.status === 409 && e.dados.nota_id) avisar(e.message, 'erro', { acao: { rotulo: `Abrir nota #${e.dados.nota_id}`, fn: () => abrirNota(e.dados.nota_id) } });
    else erroParaTela(e);
  }
}

/* ------------------------------------------------------------------ mês, total e resumo */
function atualizarRotuloMes() {
  const comp = $('#mes').value || mesAtual();
  const p = partesMes(comp);
  $('#mes-nome').textContent = maiuscula(MESES[p.mes - 1]);
  $('#mes-ano').textContent = `de ${p.ano}`;
  $('#baixar-titulo').textContent = `Baixar planilha de ${MESES[p.mes - 1]}`;
}

async function carregarResumo() {
  const mes = $('#mes').value;
  if (!/^\d{4}-\d{2}$/.test(mes)) return;
  let r;
  try { r = await api(`/resumo/${mes}`); } catch { return; } // o resumo é só informativo
  if (mes !== $('#mes').value) return; // a pessoa já mudou de mês
  estado.resumo = r;
  $('#total-valor').textContent = fmtBRL(r.total_centavos / 100);
  $('#total-meta').textContent = r.qtd ? `em despesas · saldo ${fmtSaldo(r.saldo_centavos ?? -r.total_centavos)}` : 'nenhuma despesa no mês';
  $('#lancar-detalhe').textContent = r.qtd_a_lancar
    ? `${r.qtd_a_lancar} ${r.qtd_a_lancar === 1 ? 'nota ainda não foi' : 'notas ainda não foram'} para a planilha`
    : 'Nenhuma nota nova para lançar';
  if (!$('#painel').hidden) renderPainel(r);
}
const atualizarTotalMes = carregarResumo;

function mudarMes(delta) {
  $('#mes').value = somaMes($('#mes').value || mesAtual(), delta);
  aoMudarMes();
}

function aoMudarMes() {
  atualizarRotuloMes();
  carregarResumo();
  if (estado.vista === 'lancamentos') carregarLancamentos();
}

/* ------------------------------------------------------------------ seções: Notas | Lançamentos */
const SITUACAO = {
  pago: ['Pago', 'ok'], a_pagar: ['A pagar', 'aviso'], recebido: ['Recebido', 'ok'], a_receber: ['A receber', 'aviso'],
  previsto: ['Previsto', 'neutra'], cancelado: ['Cancelado', 'neutra'],
};
const FILTROS_LANC = ['tipo', 'categoria_id', 'grupo_id', 'situacao'];
const SELETOR_FILTRO = (k) => `#lf-${k.replace('_id', '')}`;

function mostrarVista(vista) {
  if (estado.vista === vista) return;
  estado.vista = vista;
  $('#vista-notas').setAttribute('aria-selected', String(vista === 'notas'));
  $('#vista-lanc').setAttribute('aria-selected', String(vista === 'lancamentos'));
  $('#vista-forn').setAttribute('aria-selected', String(vista === 'fornecedores'));
  $('#app').hidden = vista !== 'notas';
  $('#lancs').hidden = vista !== 'lancamentos';
  $('#forn').hidden = vista !== 'fornecedores';
  if (vista === 'lancamentos') { popularFiltros(); carregarLancamentos(); }
  if (vista === 'fornecedores') carregarFornecedores();
}

/** Categorias e grupos nos filtros, mantendo o que estava escolhido (podem ter mudado em Ajustes). */
function popularFiltros() {
  const preencher = (sel, primeiro, lista) => {
    const atual = sel.value;
    sel.replaceChildren(h('option', { value: '' }, primeiro), ...lista.map((x) => h('option', { value: String(x.id) }, x.nome)));
    sel.value = lista.some((x) => String(x.id) === atual) ? atual : '';
  };
  const selCat = $('#lf-categoria'); const atualCat = selCat.value;
  selCat.replaceChildren(h('option', { value: '' }, 'Todas as categorias'),
    ...[['despesa', 'Despesas'], ['receita', 'Receitas']].map(([t, r]) => h('optgroup', { label: r },
      ...catsDo(t).map((c) => h('option', { value: String(c.id) }, c.pai_id ? `   ${c.nome}` : c.nome)))));
  selCat.value = estado.categorias.some((c) => String(c.id) === atualCat) ? atualCat : '';
  preencher($('#lf-grupo'), 'Todos os grupos', estado.grupos);
  estado.lf.categoria_id = $('#lf-categoria').value;
  estado.lf.grupo_id = $('#lf-grupo').value;
}

function periodoLanc() {
  const mes = $('#mes').value || mesAtual();
  if (estado.lf.alcance === 'tudo') return { de: null, ate: null, rotulo: 'Todos os lançamentos', frase: 'até agora' };
  if (estado.lf.alcance === 'ano') { const ano = mes.slice(0, 4); return { de: `${ano}-01`, ate: `${ano}-12`, rotulo: `Ano de ${ano}`, frase: `em ${ano}` }; }
  return { de: mes, ate: mes, rotulo: maiuscula(fmtMesLongo(mes)), frase: `em ${fmtMesLongo(mes)}` };
}

const filtrandoLanc = () => FILTROS_LANC.some((k) => estado.lf[k]) || !!estado.lf.busca.trim() || !!estado.lf.conta_id || !!estado.lf.contato_id;

async function carregarLancamentos() {
  const pedido = ++estado.lancPedido;
  const per = periodoLanc();
  $('#lancs-titulo').textContent = per.rotulo;
  const p = new URLSearchParams({ limite: '1000' });
  if (per.de) { p.set('de', per.de); p.set('ate', per.ate); }
  for (const k of [...FILTROS_LANC, 'conta_id', 'contato_id']) if (estado.lf[k]) p.set(k, estado.lf[k]);
  if (estado.lf.busca.trim()) p.set('busca', estado.lf.busca.trim());
  let r;
  try { r = await api(`/lancamentos?${p}`); } catch (e) { erroParaTela(e); return; }
  if (pedido !== estado.lancPedido) return; // chegou uma resposta mais nova (digitação, troca de mês)
  renderLancamentos(r, per);
  renderContasFaixa();
}

/** Saldo de cada conta ativa; clicar filtra os lançamentos daquela conta. */
function renderContasFaixa() {
  const faixa = $('#contas-faixa');
  const ativas = estado.contas.filter((k) => k.ativa);
  faixa.hidden = false;
  faixa.replaceChildren(...ativas.map((k) => {
    const escolhida = String(k.id) === String(estado.lf.conta_id);
    return h('button', {
      type: 'button', class: 'conta-chip', 'aria-pressed': String(escolhida),
      title: escolhida ? 'Mostrar todas as contas' : `Só lançamentos de ${k.nome}`,
      onclick: () => { estado.lf.conta_id = escolhida ? '' : String(k.id); carregarLancamentos(); },
    },
    h('span', { class: 'conta-chip-nome' }, `${k.nome} · ${TIPO_CONTA[k.tipo] || ''}`),
    h('span', { class: `conta-chip-saldo${k.saldo_centavos < 0 ? ' negativo' : ''}` }, fmtSaldo(k.saldo_centavos)));
  }), h('button', { type: 'button', class: 'conta-chip conta-chip--nova', onclick: () => abrirContas({ criar: !ativas.length }) },
    ativas.length ? 'Contas…' : '+ Cadastrar contas'));
}

const fmtSaldo = (c) => `${c < 0 ? '− ' : ''}${fmtBRL(Math.abs(c) / 100)}`;

function linhaLancamento(l) {
  const [rotulo, cor] = SITUACAO[l.situacao] || [l.situacao, 'neutra'];
  const meta = [];
  if (l.nota_numero) meta.push(`Nota nº ${l.nota_numero}`);
  else if (l.nota_id) meta.push('Nota sem número');
  if (l.nota_origem && ORIGEM_CURTA[l.nota_origem]) meta.push(ORIGEM_CURTA[l.nota_origem]);
  if (!l.nota_id) meta.push(l.tem_arquivo ? 'com comprovante' : 'sem nota');
  if (l.nota_id && !l.tem_arquivo) meta.push('sem arquivo');
  if (l.contato && chaveTexto(l.contato) !== chaveTexto(l.descricao)) meta.push(l.contato);
  if (l.conta) meta.push(l.conta);
  if (l.forma_pagamento && FORMAS[l.forma_pagamento]) meta.push(FORMAS[l.forma_pagamento]);
  if ((l.situacao === 'a_pagar' || l.situacao === 'a_receber') && l.vencimento) meta.push(`vence ${fmtDataCurta(l.vencimento)}`);
  if (l.exportado_em) meta.push('na planilha');
  const receita = l.tipo === 'receita';
  const abrir = () => abrirLancamento(l.id);
  return h('tr', {
    class: l.situacao === 'cancelado' ? 'l-cancelado' : null, tabindex: '0',
    title: 'Ver e editar o lançamento', onclick: abrir,
    onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); abrir(); } },
  },
  h('td', { class: 'l-data' }, fmtDataCurta(l.data)),
  h('td', { class: 'l-desc' }, h('strong', {}, l.descricao), meta.length ? h('span', { class: 'l-meta' }, meta.join(' · ')) : null),
  h('td', { class: `l-cat${l.categoria ? '' : ' l-vazio'}` }, l.categoria || 'sem categoria'),
  h('td', { class: `l-grupo${l.grupo ? '' : ' l-vazio'}` }, l.grupo || '—'),
  h('td', {}, h('span', { class: `pilula pilula--${cor}` }, rotulo)),
  h('td', { class: `n l-valor${receita ? ' l-valor--receita' : ''}` }, `${receita ? '+' : '−'} ${fmtBRL(l.valor_centavos / 100)}`));
}

function renderLancamentos(r, per) {
  $('#lancs-corpo').replaceChildren(...r.itens.map(linhaLancamento));
  const vazio = !r.itens.length;
  $('#lancs-vazio').hidden = !vazio;
  $('.tabela-lancs thead').hidden = vazio;
  if (vazio) {
    const filtrando = filtrandoLanc();
    $('#lancs-vazio-titulo').textContent = filtrando ? 'Nada com esses filtros' : `Nenhum lançamento ${per.frase}`;
    $('#lancs-vazio-texto').textContent = filtrando
      ? 'Tente outra busca, troque os filtros ou veja o ano inteiro.'
      : 'As notas entram aqui assim que você as arquiva. Receitas e despesas sem nota, use "Novo lançamento".';
    $('#lancs-ir-notas').textContent = filtrando ? 'Limpar filtros' : 'Novo lançamento';
    $('#lancs-ir-notas').onclick = filtrando ? limparFiltrosLanc : () => abrirLancamento(null);
  }
  const t = r.totais;
  const qtd = `${t.qtd} ${t.qtd === 1 ? 'lançamento' : 'lançamentos'}`;
  $('#ls-qtd').textContent = r.itens.length < t.qtd ? `${qtd} · mostrando os ${r.itens.length} mais recentes` : qtd;
  $('#ls-despesas').textContent = fmtBRL(t.despesas_centavos / 100);
  $('#ls-receitas').textContent = fmtBRL(t.receitas_centavos / 100);
  $('#ls-saldo').textContent = fmtSaldo(t.saldo_centavos);
  $('#ls-saldo').parentElement.classList.toggle('soma--positivo', t.saldo_centavos > 0);
  $('#lf-limpar').hidden = !filtrandoLanc();
  $('#lf-contato').hidden = !estado.lf.contato_id;
  $('#lf-contato').textContent = estado.lf.contato_id ? estado.lf.contato_nome || 'Fornecedor' : '';
  for (const k of FILTROS_LANC) $(`#lf-${k.replace('_id', '')}`).classList.toggle('ativo', !!estado.lf[k]);
}

function limparFiltrosLanc() {
  Object.assign(estado.lf, { busca: '', tipo: '', categoria_id: '', grupo_id: '', situacao: '', conta_id: '', contato_id: '', contato_nome: '' });
  $('#lf-busca').value = '';
  for (const k of FILTROS_LANC) $(`#lf-${k.replace('_id', '')}`).value = '';
  carregarLancamentos();
}

function ligarLancamentos() {
  $('#vista-notas').onclick = () => mostrarVista('notas');
  $('#vista-lanc').onclick = () => mostrarVista('lancamentos');
  for (const k of FILTROS_LANC) {
    $(`#lf-${k.replace('_id', '')}`).addEventListener('change', (e) => { estado.lf[k] = e.target.value; carregarLancamentos(); });
  }
  let espera;
  $('#lf-busca').addEventListener('input', (e) => {
    estado.lf.busca = e.target.value;
    clearTimeout(espera);
    espera = setTimeout(carregarLancamentos, 250);
  });
  $('#lf-limpar').onclick = limparFiltrosLanc;
  $('#btn-novo-lanc').onclick = () => abrirLancamento(null);
  $('#lf-contato').onclick = () => { estado.lf.contato_id = ''; estado.lf.contato_nome = ''; carregarLancamentos(); };
  $('#vista-forn').onclick = () => mostrarVista('fornecedores');
  ligarFornecedores();
  ligarDialogoLancamento();
  ligarContas();
  for (const b of $$('[data-alcance]')) {
    b.onclick = () => {
      estado.lf.alcance = b.dataset.alcance;
      for (const o of $$('[data-alcance]')) o.setAttribute('aria-pressed', String(o === b));
      carregarLancamentos();
    };
  }
}

/* menus do topo (planilha e ajustes) */
function fecharMenus(exceto) {
  for (const b of $$('[aria-haspopup="menu"]')) {
    if (b === exceto) continue;
    b.setAttribute('aria-expanded', 'false');
    $(`#${b.getAttribute('aria-controls')}`).hidden = true;
  }
}
function ligarMenus() {
  for (const botao of $$('[aria-haspopup="menu"]')) {
    const menu = $(`#${botao.getAttribute('aria-controls')}`);
    botao.addEventListener('click', (e) => {
      e.stopPropagation();
      const abrir = menu.hidden;
      fecharMenus(botao);
      menu.hidden = !abrir;
      botao.setAttribute('aria-expanded', String(abrir));
      if (abrir) $('[role^="menuitem"]', menu)?.focus();
    });
    menu.addEventListener('click', (e) => { if (e.target.closest('[role="menuitem"]')) fecharMenus(); });
  }
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu')) fecharMenus(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fecharMenus(); });
}

function mostrarTema() {
  const pref = window.midasTema?.preferencia() ?? 'auto';
  for (const b of $$('[data-tema]')) b.setAttribute('aria-checked', String(b.dataset.tema === pref));
}


/* ------------------------------------------------------------------ diálogo de lançamento */
const SIT_DO_TIPO = {
  despesa: [['pago', 'Pago'], ['a_pagar', 'A pagar'], ['previsto', 'Previsto']],
  receita: [['recebido', 'Recebido'], ['a_receber', 'A receber'], ['previsto', 'Previsto']],
};
const dl = {
  desc: $('#dl-desc'), valor: $('#dl-valor'), data: $('#dl-data'), mes: $('#dl-mes'), forma: $('#dl-forma'),
  cat: $('#dl-cat'), grupo: $('#dl-grupo'), conta: $('#dl-conta'), sit: $('#dl-sit'), venc: $('#dl-venc'),
  pago: $('#dl-pago'), obs: $('#dl-obs'), contato: $('#dl-contato'),
};

function tipoDl() { return $('.dl-tipo [aria-pressed="true"]').dataset.tipo; }

function definirTipoDl(tipo) {
  const mudou = tipoDl() !== tipo;
  for (const b of $$('.dl-tipo [data-tipo]')) b.setAttribute('aria-pressed', String(b.dataset.tipo === tipo));
  if (mudou) opcoesDeCategoria(dl.cat, tipo, null);   // categoria de despesa não vale para receita (e vice-versa)
  $('#dl-contato-rotulo').textContent = tipo === 'receita' ? 'Cliente / origem' : 'Fornecedor';
  const atual = dl.sit.value;
  const opcoes = SIT_DO_TIPO[tipo];
  dl.sit.replaceChildren(...opcoes.map(([v, r]) => h('option', { value: v }, r)),
    estado.lancAberto?.situacao === 'cancelado' ? h('option', { value: 'cancelado' }, 'Cancelado') : null);
  const par = { pago: 'recebido', recebido: 'pago', a_pagar: 'a_receber', a_receber: 'a_pagar' };
  dl.sit.value = [...dl.sit.options].some((o) => o.value === atual) ? atual : (par[atual] && opcoes.some(([v]) => v === par[atual]) ? par[atual] : opcoes[0][0]);
  $('#dl-pago-rotulo').textContent = tipo === 'receita' ? 'Recebido em' : 'Pago em';
  $('#dl-valor').closest('.campo').querySelector('label').textContent = tipo === 'receita' ? 'Valor recebido (R$)' : 'Valor (R$)';
  ajustarSituacaoDl();
}

function ajustarSituacaoDl() {
  const quitado = dl.sit.value === 'pago' || dl.sit.value === 'recebido';
  $('#dl-pago-campo').hidden = !quitado;
  $('#dl-venc-campo').hidden = quitado || dl.sit.value === 'cancelado';
}

/** id = null abre um lançamento novo (sem nota). */
async function abrirLancamento(id) {
  let l = null;
  if (id != null) { try { l = await api(`/lancamentos/${id}`); } catch (e) { erroParaTela(e); return; } }
  estado.lancAberto = l;
  const daNota = !!l?.nota_id;
  $('#dl-titulo').textContent = l ? (l.tipo === 'receita' ? 'Receita' : 'Despesa') : 'Novo lançamento';
  const origem = $('#dl-origem');
  origem.hidden = !daNota && !(l?.situacao === 'cancelado');
  origem.textContent = daNota
    ? `Vem da nota${l.nota_numero ? ` nº ${l.nota_numero}` : ''}: valor, data, categoria e grupo se corrigem nela.`
    : 'Este lançamento está cancelado: não entra nas contas.';

  const hoje = new Date(); const iso = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}-${String(hoje.getDate()).padStart(2, '0')}`;
  const mesTela = $('#mes').value || mesAtual();
  const dataPadrao = mesTela === iso.slice(0, 7) ? iso : `${mesTela}-01`;
  dl.desc.value = l?.descricao ?? '';
  dl.valor.value = l ? decParaCampo(l.valor_centavos / 100) : '';
  dl.data.value = l?.data ?? dataPadrao;
  dl.mes.value = l?.competencia ?? dataPadrao.slice(0, 7);
  dl.mes.dataset.manual = l && l.competencia !== (l.data || '').slice(0, 7) ? '1' : '';
  opcoesDeForma(dl.forma, l?.forma_pagamento);
  dl.contato.value = l?.contato ?? '';
  carregarSugestoesDeContato();
  opcoesDeCategoria(dl.cat, l?.tipo ?? 'despesa', l?.categoria_id);
  dl.grupo.replaceChildren(h('option', { value: '' }, 'Sem grupo'), ...estado.grupos.map((g) => h('option', { value: String(g.id) }, g.nome)));
  dl.grupo.value = l?.grupo_id ? String(l.grupo_id) : '';
  opcoesDeConta(dl.conta, l ? l.conta_id : ultimaConta(), { nova: true });
  dl.sit.replaceChildren(); dl.sit.value = '';
  if (l) dl.sit.append(h('option', { value: l.situacao }, l.situacao));
  dl.sit.value = l?.situacao ?? '';
  definirTipoDl(l?.tipo ?? 'despesa');
  if (l) dl.sit.value = l.situacao;
  ajustarSituacaoDl();
  dl.venc.value = l?.vencimento ?? '';
  dl.pago.value = l?.pago_em ?? '';
  dl.obs.value = l?.observacoes ?? '';

  for (const el of [dl.desc, dl.valor, dl.data, dl.mes, dl.forma, dl.cat, dl.grupo, dl.contato]) el.disabled = daNota;
  for (const b of $$('.dl-tipo [data-tipo]')) b.disabled = daNota;
  // comprovante: o da nota, ou o anexo do lançamento (dá para escolher já na criação)
  estado.anexoPendente = null;
  $('#dl-anexo-escolher').hidden = daNota;
  $('#dl-anexo-escolher').textContent = l?.tem_arquivo ? 'Trocar comprovante' : 'Anexar comprovante';
  $('#dl-anexo-nome').textContent = daNota ? (l.tem_arquivo ? 'Arquivo da nota' : 'A nota não tem arquivo')
    : (l?.tem_arquivo ? (l.arquivo_nome || 'Comprovante anexado') : 'Sem comprovante');
  const ver = $('#dl-anexo-ver');
  ver.hidden = !l?.tem_arquivo;
  if (l?.tem_arquivo) ver.href = `/lancamentos/${l.id}/arquivo`;

  $('#dl-cancelar').hidden = !l || daNota;
  $('#dl-cancelar').textContent = l?.situacao === 'cancelado' ? 'Reativar lançamento' : 'Cancelar lançamento';
  $('#dl-cancelar').className = `btn ${l?.situacao === 'cancelado' ? '' : 'btn--perigo'}`;
  $('#dl-abrir-nota').hidden = !daNota;
  $('#dl-salvar').textContent = l ? 'Salvar' : 'Lançar';
  for (const w of $$('#dl-form [data-dl]')) w.classList.remove('campo--erro');
  $('#dlg-lanc').showModal();
  (daNota ? dl.conta : dl.desc).focus();
}

function erroDl(campo, mensagem) {
  const w = $(`#dl-form [data-dl="${campo}"]`);
  if (w) { w.classList.add('campo--erro'); $('input, select', w)?.focus(); }
  throw new ErroForm(mensagem, campo);
}

function lerDialogoLancamento() {
  const l = estado.lancAberto;
  const idDe = (el) => (el.value && !el.value.startsWith('__') ? Number(el.value) : null);
  const corpo = {
    conta_id: idDe(dl.conta), situacao: dl.sit.value, observacoes: dl.obs.value.trim() || null,
    vencimento: $('#dl-venc-campo').hidden ? null : (dl.venc.value || null),
    pago_em: $('#dl-pago-campo').hidden ? null : (dl.pago.value || null),
  };
  if (l?.nota_id) return corpo;
  for (const w of $$('#dl-form [data-dl]')) w.classList.remove('campo--erro');
  const v = campoParaDec(dl.valor.value);
  if (!dl.desc.value.trim()) erroDl('descricao', 'Informe uma descrição.');
  if (v.vazio || v.erro || Number(v.valor) <= 0) erroDl('valor', 'Informe um valor maior que zero, como 1.234,56.');
  if (!dl.data.value) erroDl('data', 'Informe a data.');
  return { ...corpo, tipo: tipoDl(), descricao: dl.desc.value.trim(), valor: v.valor, data: dl.data.value,
    contato_nome: dl.contato.value.trim() || null,
    competencia: dl.mes.value || dl.data.value.slice(0, 7), forma_pagamento: dl.forma.value || null,
    categoria_id: idDe(dl.cat), grupo_id: idDe(dl.grupo) };
}

async function salvarLancamento(e) {
  e?.preventDefault();
  const botao = $('#dl-salvar'); botao.disabled = true;
  try {
    const l = estado.lancAberto;
    const corpo = lerDialogoLancamento();
    let salvo = l ? await api(`/lancamentos/${l.id}`, { metodo: 'PATCH', json: corpo })
      : await api('/lancamentos', { metodo: 'POST', json: corpo });
    if (estado.anexoPendente) {
      const form = new FormData(); form.append('arquivo', estado.anexoPendente);
      try { salvo = await api(`/lancamentos/${salvo.id}/arquivo`, { metodo: 'POST', form }); }
      catch (err) { avisar(`Lançamento salvo, mas o comprovante não foi anexado: ${err.message}`, 'erro'); }
    }
    if (corpo.conta_id) { try { localStorage.setItem('nf_ultima_conta', String(corpo.conta_id)); } catch { /* ok */ } }
    $('#dlg-lanc').close();
    avisar(l ? 'Lançamento atualizado.' : `${salvo.tipo === 'receita' ? 'Receita' : 'Despesa'} lançada: ${salvo.descricao}.`, 'ok');
    await atualizarDepoisDeLancar();
  } catch (err) { erroParaTela(err); } finally { botao.disabled = false; }
}

async function atualizarDepoisDeLancar() {
  try { estado.contas = await api('/contas'); } catch { /* segue */ }
  carregarResumo();
  if (estado.vista === 'lancamentos') carregarLancamentos();
}

async function alternarCancelamento() {
  const l = estado.lancAberto; if (!l) return;
  const reativar = l.situacao === 'cancelado';
  if (!reativar && !confirm(`Cancelar "${l.descricao}"? Ele sai das contas, mas continua guardado e pode ser reativado.`)) return;
  try {
    await api(`/lancamentos/${l.id}`, { metodo: 'PATCH', json: { situacao: reativar ? (l.tipo === 'receita' ? 'recebido' : 'pago') : 'cancelado' } });
    $('#dlg-lanc').close();
    avisar(reativar ? 'Lançamento reativado.' : 'Lançamento cancelado. Veja em Situação: Cancelados.', 'ok');
    await atualizarDepoisDeLancar();
  } catch (e) { erroParaTela(e); }
}

function ligarDialogoLancamento() {
  $('#dl-form').addEventListener('submit', salvarLancamento);
  $('#dl-fechar').onclick = () => $('#dlg-lanc').close();
  for (const b of $$('.dl-tipo [data-tipo]')) b.onclick = () => definirTipoDl(b.dataset.tipo);
  dl.sit.onchange = ajustarSituacaoDl;
  dl.data.addEventListener('change', () => { if (!dl.mes.dataset.manual && dl.data.value) dl.mes.value = dl.data.value.slice(0, 7); });
  dl.mes.addEventListener('change', () => { dl.mes.dataset.manual = '1'; });
  dl.valor.addEventListener('blur', () => { const v = campoParaDec(dl.valor.value); if (v.valor) dl.valor.value = decParaCampo(v.valor); });
  $('#dl-anexo-escolher').onclick = () => $('#dl-anexo-in').click();
  $('#dl-anexo-in').onchange = (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    estado.anexoPendente = f;
    $('#dl-anexo-nome').textContent = `${f.name} (anexado ao salvar)`;
  };
  $('#dl-cancelar').onclick = alternarCancelamento;
  $('#dl-abrir-nota').onclick = () => { const id = estado.lancAberto?.nota_id; $('#dlg-lanc').close(); if (id) abrirNota(id); };
  dl.conta.addEventListener('change', () => {
    if (dl.conta.value !== '__nova__') return;
    dl.conta.value = '';
    abrirContas({ criar: true, aoCriar: (k) => opcoesDeConta(dl.conta, k.id) });
  });
  $('#dl-form').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.ctrlKey) salvarLancamento(e); });
}

/* ------------------------------------------------------------------ fornecedores e clientes */
const chaveTexto = (t) => (t || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const TIPO_CONTATO = { fornecedor: 'Fornecedor', cliente: 'Cliente', ambos: 'Fornecedor e cliente' };

async function carregarSugestoesDeContato() {
  try { estado.contatos = await api('/contatos'); } catch { estado.contatos = estado.contatos || []; }
  $('#dl-contatos').replaceChildren(...(estado.contatos || []).map((k) => h('option', { value: k.nome })));
}

async function carregarFornecedores() {
  const p = new URLSearchParams();
  const busca = $('#ff-busca').value.trim(); const tipo = $('#ff-tipo').value;
  if (busca) p.set('busca', busca);
  if (tipo) p.set('tipo', tipo);
  const pedido = (estado.fornPedido = (estado.fornPedido || 0) + 1);
  let lista;
  try { lista = await api(`/contatos?${p}`); } catch (e) { erroParaTela(e); return; }
  if (pedido !== estado.fornPedido) return;
  $('#forn-vazio').hidden = lista.length > 0;
  $('#forn .tabela-lancs thead').hidden = !lista.length;
  $('#forn-qtd').textContent = `${lista.length} ${lista.length === 1 ? 'cadastro' : 'cadastros'}`;
  $('#forn-corpo').replaceChildren(...lista.map((k) => {
    const ver = () => verLancamentosDoContato(k);
    return h('tr', { tabindex: '0', title: `Ver os lançamentos de ${k.nome}`, onclick: ver,
      onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); ver(); } } },
    h('td', { class: 'l-desc' }, h('strong', {}, k.nome), h('span', { class: 'l-meta' }, k.cnpj ? `CNPJ ${fmtCnpj(k.cnpj)}` : 'sem CNPJ')),
    h('td', {}, h('span', { class: `pilula ${k.tipo === 'cliente' ? 'pilula--ok' : 'pilula--neutra'}` }, TIPO_CONTATO[k.tipo] || k.tipo)),
    h('td', { class: 'n num' }, String(k.qtd_lancamentos)),
    h('td', { class: 'n l-valor' }, k.despesas_centavos ? `− ${fmtBRL(k.despesas_centavos / 100)}` : '—'),
    h('td', { class: 'n l-valor l-valor--receita' }, k.receitas_centavos ? `+ ${fmtBRL(k.receitas_centavos / 100)}` : '—'),
    h('td', { class: 'l-data' }, k.ultimo_em ? fmtDataCurta(k.ultimo_em) + ` ${k.ultimo_em.slice(2, 4)}` : '—'),
    h('td', {}, h('button', { type: 'button', class: 'btn btn--texto',
      onclick: (e) => { e.stopPropagation(); editarContato(k); } }, 'Editar')));
  }));
}

/** O histórico de um fornecedor é a aba Lançamentos filtrada por ele, em todos os períodos. */
function verLancamentosDoContato(k) {
  Object.assign(estado.lf, { busca: '', tipo: '', categoria_id: '', grupo_id: '', situacao: '', conta_id: '',
    contato_id: String(k.id), contato_nome: k.nome, alcance: 'tudo' });
  $('#lf-busca').value = '';
  for (const kk of FILTROS_LANC) $(SELETOR_FILTRO(kk)).value = '';
  for (const o of $$('[data-alcance]')) o.setAttribute('aria-pressed', String(o.dataset.alcance === 'tudo'));
  mostrarVista('lancamentos');
}

function editarContato(k) {
  estado.contatoEditando = k;
  $('#dc-titulo').textContent = TIPO_CONTATO[k.tipo] || 'Fornecedor';
  $('#dc-cnpj').textContent = k.cnpj ? `CNPJ ${fmtCnpj(k.cnpj)}` : 'Sem CNPJ (cadastrado pelo nome).';
  $('#dc-nome').value = k.nome;
  $('#dc-obs').value = k.observacoes || '';
  $('#dlg-contato').showModal();
  $('#dc-nome').focus();
}

function ligarFornecedores() {
  let espera;
  $('#ff-busca').addEventListener('input', () => { clearTimeout(espera); espera = setTimeout(carregarFornecedores, 250); });
  $('#ff-tipo').onchange = carregarFornecedores;
  $('#dc-fechar').onclick = () => $('#dlg-contato').close();
  $('#dc-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const k = estado.contatoEditando; if (!k) return;
    try {
      await api(`/contatos/${k.id}`, { metodo: 'PATCH', json: { nome: $('#dc-nome').value.trim(), observacoes: $('#dc-obs').value.trim() || null } });
      $('#dlg-contato').close(); avisar('Cadastro atualizado.', 'ok'); carregarFornecedores();
    } catch (err) { erroParaTela(err); }
  });
}

/* ------------------------------------------------------------------ contas */
function abrirContas({ criar = false, aoCriar = null } = {}) {
  estado.aoCriarConta = aoCriar;
  editarConta(null);
  renderContas();
  $('#dlg-contas').showModal();
  if (criar) $('#ct-nome').focus();
}

function renderContas() {
  const lista = estado.contas;
  $('#ct-vazio').hidden = lista.length > 0;
  $('#ct-tabela').hidden = lista.length === 0;
  $('#ct-corpo').replaceChildren(...lista.map((k) => h('tr', { class: k.ativa ? null : 'conta-inativa' },
    h('td', {}, h('strong', {}, k.nome), k.ativa ? null : h('span', { class: 'l-meta' }, 'desativada')),
    h('td', {}, TIPO_CONTA[k.tipo] || k.tipo),
    h('td', { class: `n num${k.saldo_centavos < 0 ? ' saldo-negativo' : ''}` }, fmtSaldo(k.saldo_centavos)),
    h('td', {}, k.qtd_lancamentos ? `${k.qtd_lancamentos} ${k.qtd_lancamentos === 1 ? 'lançamento' : 'lançamentos'}` : 'sem uso'),
    h('td', { class: 'acoes-linha' },
      h('button', { type: 'button', class: 'btn btn--texto', onclick: () => editarConta(k) }, 'Editar'),
      k.qtd_lancamentos
        ? h('button', { type: 'button', class: 'btn btn--texto', onclick: () => salvarCampoConta(k, { ativa: !k.ativa }) }, k.ativa ? 'Desativar' : 'Reativar')
        : h('button', { type: 'button', class: 'btn btn--perigo', onclick: () => excluirConta(k) }, 'Excluir')))));
}

function editarConta(k) {
  estado.contaEditando = k;
  $('#ct-form-titulo').textContent = k ? `Editar ${k.nome}` : 'Nova conta';
  $('#ct-salvar').textContent = k ? 'Salvar conta' : 'Cadastrar conta';
  $('#ct-cancelar').hidden = !k;
  $('#ct-nome').value = k?.nome ?? '';
  $('#ct-tipo').value = k?.tipo ?? 'banco';
  $('#ct-saldo').value = k ? decParaCampo(Math.abs(k.saldo_inicial_centavos) / 100).replace(/^/, k.saldo_inicial_centavos < 0 ? '-' : '') : '';
  $('#ct-saldo-em').value = k?.saldo_inicial_em ?? '';
  if (k) $('#ct-nome').focus();
}

async function salvarConta(e) {
  e.preventDefault();
  const texto = $('#ct-saldo').value.trim();
  const negativo = texto.startsWith('-');
  const v = campoParaDec(texto.replace(/^-/, ''));
  if (v.erro) { avisar('Saldo inicial inválido. Digite como 1.234,56 (ou -350,00 para saldo negativo).', 'erro'); $('#ct-saldo').focus(); return; }
  const corpo = { nome: $('#ct-nome').value.trim(), tipo: $('#ct-tipo').value,
    saldo_inicial: v.vazio ? '0.00' : `${negativo ? '-' : ''}${v.valor}`, saldo_inicial_em: $('#ct-saldo-em').value || null };
  try {
    const k = estado.contaEditando;
    const salva = k ? await api(`/contas/${k.id}`, { metodo: 'PATCH', json: corpo }) : await api('/contas', { metodo: 'POST', json: corpo });
    estado.contas = await api('/contas');
    editarConta(null); renderContas();
    avisar(k ? 'Conta atualizada.' : `Conta ${salva.nome} cadastrada.`, 'ok');
    if (!k && estado.aoCriarConta) { const fn = estado.aoCriarConta; estado.aoCriarConta = null; $('#dlg-contas').close(); fn(salva); }
    if (estado.vista === 'lancamentos') carregarLancamentos();
  } catch (err) { erroParaTela(err); }
}

async function salvarCampoConta(k, campos) {
  try { await api(`/contas/${k.id}`, { metodo: 'PATCH', json: campos }); estado.contas = await api('/contas'); renderContas(); if (estado.vista === 'lancamentos') carregarLancamentos(); }
  catch (e) { erroParaTela(e); }
}

async function excluirConta(k) {
  if (!confirm(`Excluir a conta "${k.nome}"?`)) return;
  try { await api(`/contas/${k.id}`, { metodo: 'DELETE' }); estado.contas = await api('/contas'); renderContas(); if (estado.vista === 'lancamentos') carregarLancamentos(); }
  catch (e) { erroParaTela(e); }
}

function ligarContas() {
  $('#btn-contas').onclick = () => abrirContas();
  $('#dlg-contas-fechar').onclick = () => $('#dlg-contas').close();
  $('#ct-form').addEventListener('submit', salvarConta);
  $('#ct-cancelar').onclick = () => editarConta(null);
}

/* ------------------------------------------------------------------ planilha */
async function baixarPlanilha(marcar) {
  const mes = $('#mes').value;
  if (!mes) { avisar('Escolha o mês da planilha.', 'erro'); return; }
  if (marcar && !confirm(`Baixar a planilha de ${fmtMesCurto(mes)} e marcar as notas arquivadas como lançadas?`)) return;
  try {
    const blob = await api(marcar ? `/planilhas/${mes}/lancar` : `/planilhas/${mes}`, { metodo: marcar ? 'POST' : 'GET', blob: true });
    baixarBlob(blob, `notas_${mes}.xlsx`);
    avisar(marcar ? `Planilha de ${fmtMesCurto(mes)} baixada; notas marcadas como lançadas.` : `Planilha de ${fmtMesCurto(mes)} baixada.`, 'ok');
    if (marcar) { await carregarListas(); carregarResumo(); }
  } catch (e) { erroParaTela(e); }
}

/* ------------------------------------------------------------------ grupos e categorias */
function abrirGrupos({ criar = false, aoCriar = null, categoria = false, aoCriarCategoria = null } = {}) {
  estado.aoCriarGrupo = aoCriar; estado.aoCriarCategoria = aoCriarCategoria; estado.categoriaEditando = null;
  editarGrupo(null);
  renderGrupos();
  renderCategorias();
  $('#dlg-grupos').showModal();
  if (criar) $('#ev-nome').focus();
  if (categoria) { $('#cat-tipo').value = 'despesa'; popularPaiCategoria(null); $('#cat-nome').scrollIntoView({ block: 'center' }); $('#cat-nome').focus(); }
}

function renderGrupos() {
  $('#ev-vazio').hidden = estado.grupos.length > 0;
  $('.tabela-grupos').hidden = estado.grupos.length === 0;
  $('#ev-corpo').replaceChildren(...estado.grupos.map((e) => {
    const orc = e.orcamento != null ? Number(e.orcamento) : null;
    const gasto = Number(e.gasto);
    const pct = orc > 0 ? (gasto / orc) * 100 : null;
    const uso = pct == null ? h('span', { class: 'uso-texto' }, 'sem orçamento')
      : h('div', {}, h('span', { class: `uso${pct > 100 ? ' estourou' : ''}`, role: 'img', 'aria-label': `${Math.round(pct)}% do orçamento` },
        h('span', { style: `width:${Math.min(pct, 100)}%` })), h('span', { class: 'uso-texto' }, `${Math.round(pct)}%`));
    return h('tr', {}, h('td', {}, e.nome), h('td', {}, e.data_grupo ? fmtData(e.data_grupo) : ''),
      h('td', { class: 'n' }, orc != null ? fmtBRL(e.orcamento) : ''), h('td', { class: 'n' }, fmtBRL(e.gasto)), h('td', {}, uso),
      h('td', {}, h('button', { type: 'button', class: 'btn btn--texto', onclick: () => editarGrupo(e) }, 'Editar')));
  }));
}

function editarGrupo(grupo) {
  estado.grupoEditando = grupo;
  $('#ev-nome').value = grupo?.nome ?? '';
  $('#ev-data').value = grupo?.data_grupo ?? '';
  $('#ev-orc').value = decParaCampo(grupo?.orcamento);
  $('#ev-form-titulo').textContent = grupo ? `Editar ${grupo.nome}` : 'Novo grupo';
  $('#ev-salvar').textContent = grupo ? 'Salvar alterações' : 'Cadastrar grupo';
  $('#ev-cancelar').hidden = !grupo;
  if (grupo) $('#ev-nome').focus();
}

async function salvarGrupo(e) {
  e.preventDefault();
  const nome = $('#ev-nome').value.trim();
  if (!nome) { avisar('Informe o nome do grupo.', 'erro'); $('#ev-nome').focus(); return; }
  const orc = campoParaDec($('#ev-orc').value);
  if (orc.erro) { avisar('Orçamento inválido. Digite números, como 5.000,00.', 'erro'); $('#ev-orc').focus(); return; }
  const corpo = { nome, data_grupo: $('#ev-data').value || null, orcamento: orc.vazio ? null : orc.valor };
  try {
    const editando = estado.grupoEditando;
    const salvo = editando
      ? await api(`/grupos/${editando.id}`, { metodo: 'PATCH', json: corpo })
      : await api('/grupos', { metodo: 'POST', json: corpo });
    await carregarCatalogos();
    editarGrupo(null); renderGrupos(); repovoarSelects();
    avisar(editando ? 'Grupo atualizado.' : `Grupo "${salvo.nome}" cadastrado.`, 'ok');
    if (!editando && estado.aoCriarGrupo) { estado.aoCriarGrupo(salvo); estado.aoCriarGrupo = null; $('#dlg-grupos').close(); }
  } catch (err) { erroParaTela(err); }
}

function renderCategorias() {
  const item = (c) => {
    const n = c.qtd_lancamentos ?? c.qtd_notas;
    const uso = h('span', { class: 'cat-uso' }, n ? `${n} ${n === 1 ? 'lançamento' : 'lançamentos'}` : 'sem uso');
    const classe = `cat-item${c.pai_id ? ' cat-item--sub' : ''}`;
    if (estado.categoriaEditando === c.id) {
      const campo = h('input', { class: 'cat-campo', value: c.nome, maxlength: '80', 'aria-label': `Novo nome da categoria ${c.nome}` });
      const salvarEdicao = () => renomearCategoria(c, campo.value);
      campo.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); salvarEdicao(); }
        if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); estado.categoriaEditando = null; renderCategorias(); }
      });
      setTimeout(() => { campo.focus(); campo.select(); });
      return h('li', { class: classe }, campo, uso,
        h('button', { type: 'button', class: 'btn btn--texto', onclick: salvarEdicao }, 'Salvar'),
        h('button', { type: 'button', class: 'btn btn--texto', onclick: () => { estado.categoriaEditando = null; renderCategorias(); } }, 'Cancelar'));
    }
    return h('li', { class: classe }, h('span', { class: 'cat-nome' }, c.nome), uso,
      c.pai_id ? null : h('button', { type: 'button', class: 'btn btn--texto', title: `Criar uma subcategoria dentro de ${c.nome}`,
        onclick: () => { $('#cat-tipo').value = c.tipo; popularPaiCategoria(c.id); $('#cat-nome').focus(); } }, '+ Sub'),
      h('button', { type: 'button', class: 'btn btn--texto', onclick: () => { estado.categoriaEditando = c.id; renderCategorias(); } }, 'Renomear'),
      h('button', { type: 'button', class: 'btn btn--perigo', onclick: () => excluirCategoria(c),
        title: c.qtd_subcategorias ? 'Tem subcategorias: exclua-as antes' : (n ? 'Em uso: troque a categoria dos lançamentos antes de excluir' : null) }, 'Excluir'));
  };
  $('#cat-lista').replaceChildren(...[['despesa', 'Despesas'], ['receita', 'Receitas']].flatMap(([t, r]) =>
    [h('li', { class: 'cat-secao' }, r), ...catsDo(t).map(item)]));
  popularPaiCategoria($('#cat-pai').value ? Number($('#cat-pai').value) : null);
}

/** "Dentro de": só categorias principais do tipo escolhido. */
function popularPaiCategoria(escolhida) {
  const tipo = $('#cat-tipo').value;
  const principais = catsDo(tipo).filter((c) => !c.pai_id);
  $('#cat-pai').replaceChildren(h('option', { value: '' }, '(categoria principal)'),
    ...principais.map((c) => h('option', { value: String(c.id) }, c.nome)));
  $('#cat-pai').value = escolhida && principais.some((c) => c.id === escolhida) ? String(escolhida) : '';
}

async function adicionarCategoria(e) {
  e.preventDefault();
  const nome = $('#cat-nome').value.trim();
  if (!nome) { avisar('Informe o nome da categoria.', 'erro'); $('#cat-nome').focus(); return; }
  try {
    const pai = $('#cat-pai').value ? Number($('#cat-pai').value) : null;
    const nova = await api('/categorias', { metodo: 'POST', json: { nome, tipo: $('#cat-tipo').value, pai_id: pai } });
    $('#cat-nome').value = '';
    await carregarCatalogos(); renderCategorias(); repovoarSelects();
    avisar(`${nova.pai_id ? 'Subcategoria' : 'Categoria'} "${nova.nome_completo || nova.nome}" adicionada.`, 'ok');
    if (estado.aoCriarCategoria) { estado.aoCriarCategoria(nova); estado.aoCriarCategoria = null; $('#dlg-grupos').close(); }
  } catch (err) { erroParaTela(err); $('#cat-nome').focus(); }
}

async function renomearCategoria(c, nome) {
  nome = nome.trim();
  if (nome === c.nome) { estado.categoriaEditando = null; renderCategorias(); return; }
  try {
    await api(`/categorias/${c.id}`, { metodo: 'PATCH', json: { nome } });
    estado.categoriaEditando = null;
    await carregarCatalogos(); renderCategorias(); repovoarSelects();
    avisar('Categoria renomeada.', 'ok');
  } catch (err) { erroParaTela(err); }
}

async function excluirCategoria(c) {
  if (c.qtd_notas) {
    avisar(`"${c.nome}" está em uso por ${c.qtd_notas} ${c.qtd_notas === 1 ? 'nota' : 'notas'} e não pode ser excluída. Troque a categoria dessas notas antes, ou renomeie esta categoria.`, 'erro');
    return;
  }
  if (!confirm(`Excluir a categoria "${c.nome}"?`)) return;
  try {
    await api(`/categorias/${c.id}`, { metodo: 'DELETE' });
    await carregarCatalogos(); renderCategorias(); repovoarSelects();
    avisar(`Categoria "${c.nome}" excluída.`, 'ok');
  } catch (err) { erroParaTela(err); await carregarCatalogos(); renderCategorias(); }
}

/** Atualiza as listas de grupo/categoria sem perder o que a pessoa já escolheu na nota aberta. */
function repovoarSelects() {
  if (!estado.nota) return;
  const atual = lerForm();
  popularSelects({ grupo_id: atual.grupo_id, categoria_id: atual.categoria_id, status: 'repovoar',
    conta_id: atual.conta_id, forma_pagamento: atual.forma_pagamento });
  if (estado.original) { estado.original.grupo_id = estado.original.grupo_id ?? null; }
  atualizarSujo();
}

/* ------------------------------------------------------------------ ligações da tela */
function ligarGruposDaTela() {
  $('#aba-fila').onclick = () => trocarAba('fila');
  $('#aba-arquivadas').onclick = () => trocarAba('arquivadas');

  $('#btn-escolher').onclick = () => $('#in-arquivos').click();
  $('#btn-camera').onclick = () => $('#in-camera').click();
  $('#btn-manual').onclick = lancarManual;
  for (const id of ['in-arquivos', 'in-camera']) {
    $(`#${id}`).onchange = (e) => { const f = [...e.target.files]; e.target.value = ''; enviarArquivos(f); };
  }
  const anexo = h('input', { type: 'file', id: 'in-anexo', hidden: true });
  anexo.addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; anexarComprovante(f); });
  document.body.append(anexo);

  let sobre = 0;
  const temArquivos = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  window.addEventListener('dragenter', (e) => { if (temArquivos(e)) { sobre++; $('#solte').hidden = false; } });
  window.addEventListener('dragleave', (e) => { if (temArquivos(e)) { sobre = Math.max(0, sobre - 1); if (!sobre) $('#solte').hidden = true; } });
  window.addEventListener('dragover', (e) => { if (temArquivos(e)) e.preventDefault(); });
  window.addEventListener('drop', (e) => {
    if (!temArquivos(e)) return;
    e.preventDefault(); sobre = 0; $('#solte').hidden = true; enviarArquivos(e.dataTransfer.files);
  });
  document.addEventListener('paste', (e) => {
    const arquivos = [...(e.clipboardData?.files || [])];
    if (arquivos.length) { e.preventDefault(); enviarArquivos(arquivos); }
  });

  $('#mes').onchange = aoMudarMes;
  $('#mes-rotulo').onclick = () => { const m = $('#mes'); try { m.showPicker(); } catch { mudarMes(0); } };
  $('#mes-ant').onclick = () => mudarMes(-1);
  $('#mes-prox').onclick = () => mudarMes(1);
  $('#nav-ant').onclick = () => vizinha(-1);
  $('#nav-prox').onclick = () => vizinha(1);
  $('#btn-baixar').onclick = () => baixarPlanilha(false);
  $('#btn-lancar').onclick = () => baixarPlanilha(true);
  $('#btn-grupos').onclick = () => abrirGrupos();
  $('#btn-atualizacao').onclick = abrirAtualizacoes;
  $('#dlg-atu-fechar').onclick = () => $('#dlg-atualizacao').close();
  $('#atu-verificar').onclick = () => verificarAtualizacao({ forcar: true, silencioso: false });
  $('#atu-baixar').onclick = acaoDeAtualizar;
  for (const b of $$('[data-tema]')) b.onclick = () => { window.midasTema?.definir(b.dataset.tema); mostrarTema(); };
  mostrarTema();
  ligarMenus();
  $('#painel-lancar').onclick = () => baixarPlanilha(true);
  $('#ver-arquivadas').onclick = () => { trocarAba('arquivadas'); $('#lista').focus?.(); };
  $('#dlg-grupos-fechar').onclick = () => $('#dlg-grupos').close();
  $('#dlg-grupos').addEventListener('close', () => { estado.aoCriarGrupo = null; estado.aoCriarCategoria = null; estado.categoriaEditando = null; });
  $('#ev-form').onsubmit = salvarGrupo;
  $('#ev-cancelar').onclick = () => editarGrupo(null);
  $('#cat-form').onsubmit = adicionarCategoria;
  $('#cat-tipo').onchange = () => popularPaiCategoria(null);

  const form = $('#form');
  form.addEventListener('submit', (e) => e.preventDefault()); // Enter dentro de um campo nunca valida por acidente
  form.addEventListener('input', (e) => {
    if (e.target.closest('#itens-corpo')) return; // as linhas de itens tratam o próprio evento
    if (e.target === campos.competencia) estado.competenciaManual = true;
    if (e.target === campos.data_emissao && !estado.competenciaManual) definirMes(campos.data_emissao.value.slice(0, 7));
    if (e.target === campos.chave_acesso) atualizarContadorChave();
    if (e.target === campos.valor_total) atualizarResumoItens();
    if (e.target === campos.grupo_id) atualizarOrcamento();
    atualizarCabeca();
    atualizarSujo();
  });
  form.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); validar(); } });
  for (const [nome, el] of Object.entries(campos)) {
    el.addEventListener('focus', () => $$('.marca-leitura').forEach((m) => m.classList.toggle('ativa', m.dataset.campo === nome)));
    el.addEventListener('blur', () => $$('.marca-leitura').forEach((m) => m.classList.remove('ativa')));
  }
  campos.cnpj.addEventListener('blur', () => { campos.cnpj.value = fmtCnpj(normDoc(campos.cnpj.value)); });
  campos.valor_total.addEventListener('blur', () => {
    const v = campoParaDec(campos.valor_total.value); if (v.valor) campos.valor_total.value = decParaCampo(v.valor);
  });
  campos.conta_id.addEventListener('change', () => {
    if (campos.conta_id.value !== '__nova__') { estado.contaAnterior = campos.conta_id.value; return; }
    campos.conta_id.value = estado.contaAnterior || '';
    abrirContas({ criar: true, aoCriar: (k) => { opcoesDeConta(campos.conta_id, k.id); estado.contaAnterior = String(k.id); } });
  });
  campos.grupo_id.addEventListener('change', () => {
    if (campos.grupo_id.value !== '__novo__') { estado.grupoAnterior = campos.grupo_id.value; return; }
    campos.grupo_id.value = estado.grupoAnterior;
    abrirGrupos({ criar: true, aoCriar: (ev) => { campos.grupo_id.value = String(ev.id); estado.grupoAnterior = String(ev.id); atualizarOrcamento(); atualizarSujo(); } });
  });

  campos.categoria_id.addEventListener('change', () => {
    if (campos.categoria_id.value !== '__nova__') { escolherCategoria(campos.categoria_id.value); return; }
    campos.categoria_id.value = estado.categoriaAnterior;
    abrirGrupos({ categoria: true, aoCriarCategoria: (c) => { escolherCategoria(String(c.id)); } });
  });

  $('#item-novo').onclick = () => {
    const tr = linhaItem({}, true); $('#itens-corpo').append(tr); $('#itens').open = true; $('.i-desc', tr).focus(); aoMudarItens();
  };
  $('#btn-salvar').onclick = async () => { try { await salvar(); } catch (e) { erroParaTela(e); if (e.campo) focarCampo(e.campo); } };
  $('#btn-validar').onclick = validar;
  $('#btn-reabrir').onclick = reabrir;
  $('#btn-excluir').onclick = excluir;

  window.addEventListener('beforeunload', (e) => { if (estaSujo()) { e.preventDefault(); e.returnValue = ''; } });
  ligarMesa();
}

/* ------------------------------------------------------------------ atualizações e novidades */
function renderAtualizacao(s) {
  estado.atualizacao = s;
  $('#versao-txt').textContent = s.atual ? `Versão instalada: ${s.atual}` : 'Versão de desenvolvimento';
  const nova = s.disponivel && s.pronta !== s.disponivel.versao ? s.disponivel : null;
  $('#btn-ajustes').dataset.novo = String(Boolean(nova));
  $('#menu-novo').hidden = !nova;
  const titulo = $('#atu-titulo'), texto = $('#atu-texto'), baixar = $('#atu-baixar');
  baixar.hidden = true;
  $('#atu-novas').hidden = true;
  if (!s.ativo) {
    titulo.textContent = 'Atualizações automáticas desligadas';
    texto.textContent = 'Elas funcionam no Midas instalado pelo instalador.';
  } else if (s.pronta) {
    titulo.textContent = `Versão ${s.pronta} baixada`;
    texto.textContent = 'Feche o Midas e abra de novo para usar. Se a versão nova não abrir, o Midas volta sozinho para esta.';
  } else if (nova) {
    titulo.textContent = `Versão ${nova.versao} disponível`;
    baixar.hidden = false;
    if (nova.precisa_instalador) {
      texto.textContent = 'Esta versão muda o motor do Midas e precisa do instalador completo. Seus dados são mantidos.';
      baixar.textContent = 'Baixar o instalador';
    } else {
      const kb = nova.tamanho ? ` (${Math.max(1, Math.round(nova.tamanho / 1024)).toLocaleString('pt-BR')} KB)` : '';
      texto.textContent = `Baixa só o que mudou${kb}. Seus dados não são tocados.`;
      baixar.textContent = 'Baixar atualização';
    }
    if (nova.novidades.length) {
      $('#atu-novas').hidden = false;
      $('#atu-novas').replaceChildren(...nova.novidades.map((i) => h('li', {}, i)));
    }
  } else {
    titulo.textContent = `Você está na versão mais recente (${s.atual})`;
    texto.textContent = s.erro || 'O Midas verifica sozinho sempre que abre.';
  }
}

async function verificarAtualizacao({ forcar = false, silencioso = true } = {}) {
  try {
    const s = await api(`/atualizacao${forcar ? '?verificar=true' : ''}`);
    renderAtualizacao(s);
    return s;
  } catch (e) { if (!silencioso) erroParaTela(e); return null; }
}

async function acaoDeAtualizar() {
  const nova = estado.atualizacao?.disponivel;
  if (!nova) return;
  if (nova.precisa_instalador) { if (nova.instalador_url) window.open(nova.instalador_url, '_blank', 'noopener'); return; }
  const botao = $('#atu-baixar');
  botao.disabled = true; botao.textContent = 'Baixando…';
  try {
    const s = await api('/atualizacao/baixar', { metodo: 'POST' });
    renderAtualizacao(s);
    avisar(`Versão ${s.pronta} baixada. Feche e abra o Midas para usar.`, 'ok', { duracao: 12000 });
  } catch (e) { erroParaTela(e); renderAtualizacao(estado.atualizacao); }
  finally { botao.disabled = false; }
}

async function renderNovidades() {
  let lista = [];
  try { lista = await api('/novidades'); } catch { /* sem novidades para mostrar */ }
  // histórico completo: o planejado ("Em breve") primeiro, depois cada versão, com a instalada marcada
  $('#atu-novidades').replaceChildren(...(lista.length ? lista.map((n) => h('article', { class: `novidade${n.planejado ? ' novidade--planejada' : ''}` },
    h('h4', {}, n.planejado ? 'Em breve' : `Versão ${n.versao}`,
      n.data ? h('span', {}, ` · ${fmtDataLonga(n.data)}`) : null,
      n.planejado ? h('span', {}, ' · planejado, ainda não instalado') : null,
      n.instalada ? h('span', { class: 'pilula pilula--ok novidade-selo' }, 'instalada') : null),
    h('ul', {}, ...n.itens.map((i) => h('li', {}, i))))) : [h('p', { class: 'cartao-vazio' }, 'Sem registro de novidades.')]));
}

function abrirAtualizacoes() {
  $('#dlg-atualizacao').showModal();
  renderNovidades();
  verificarAtualizacao({ forcar: true, silencioso: false });
}

async function checarAtualizacaoAoAbrir() {
  const s = await verificarAtualizacao({ forcar: true });
  if (!s) return;
  if (s.falha) {
    avisar(`A versão ${s.falha.versao} não abriu e o Midas voltou sozinho para a ${s.falha.voltou_para}. Seus dados estão intactos.`, 'erro',
      { acao: { rotulo: 'Entendi', fn: () => api('/atualizacao/dispensar-falha', { metodo: 'POST' }).catch(() => {}) }, duracao: 30000 });
  }
  let vista = null;
  try { vista = localStorage.getItem('midas_versao_vista'); } catch { /* sem armazenamento */ }
  if (s.atual && vista && vista !== s.atual && !s.falha) {
    avisar(`O Midas foi atualizado para a versão ${s.atual}.`, 'ok', { acao: { rotulo: 'Ver novidades', fn: abrirAtualizacoes }, duracao: 12000 });
  }
  try { if (s.atual) localStorage.setItem('midas_versao_vista', s.atual); } catch { /* ok */ }
  if (s.pronta) avisar(`A versão ${s.pronta} já foi baixada. Feche e abra o Midas para usar.`, 'info', { duracao: 10000 });
  else if (s.disponivel) avisar(`Versão ${s.disponivel.versao} do Midas disponível.`, 'info', { acao: { rotulo: 'Ver', fn: abrirAtualizacoes }, duracao: 12000 });
}

/* ------------------------------------------------------------------ início */
async function iniciar() {
  try { estado.saude = await (await fetch('/saude')).json(); }
  catch { avisar('Não consegui falar com o servidor. Confira se ele está rodando.', 'erro', { duracao: 60000 }); return; }
  if (estado.saude.exige_token && !estado.token) await pedirToken();
  $('#mes').value = mesAtual();
  atualizarRotuloMes();
  ligarGruposDaTela();
  ligarLancamentos();
  try {
    await Promise.all([carregarCatalogos(), carregarListas()]);
  } catch (e) { erroParaTela(e); return; }
  if (!estado.saude.leitura_de_fotos) {
    avisar('Leitura de fotos indisponível neste computador (leitor local não encontrado). XML e PDF de DANFE funcionam; em fotos, os campos são preenchidos à mão.', 'info', { duracao: 12000 });
  }
  carregarResumo();
  checarAtualizacaoAoAbrir();
  if (estado.fila.length) await abrirNota(estado.fila[0].id, { rolar: false }); else mostrarVazio();
}

// Sinal de vida: permite ao lançador encerrar o programa quando a janela é fechada.
setInterval(() => { fetch('/ping', { cache: 'no-store' }).catch(() => {}); }, 10000);

iniciar();
