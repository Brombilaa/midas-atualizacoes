"""Banco SQLite. Valores em centavos; datas em ISO (AAAA-MM-DD); competência no formato AAAA-MM."""
from __future__ import annotations

import sqlite3
from pathlib import Path

CATEGORIAS_PADRAO = [
    "Alimentação", "Bebidas", "Brindes", "Locação de espaço", "Locação de equipamentos",
    "Decoração", "Material gráfico", "Transporte", "Hospedagem", "Comunicação e mídia",
    "Serviços de terceiros", "Outros",
]

COLUNAS_NOTAS = (
    "id, status, origem, fornecedor, cnpj, numero, serie, data_emissao, valor_total_centavos, chave_acesso, "
    "grupo_id, categoria_id, competencia, confianca, observacoes, arquivo_nome, arquivo_mime, arquivo_sha256, "
    "arquivo_ref, arquivo_local, criado_em, validado_em"
)


def _ddl_notas(nome_sql: str) -> str:
    # Nota manual não tem arquivo: as colunas arquivo_* aceitam NULL (arquivo_ref NULL = sem arquivo).
    return f"""
CREATE TABLE {nome_sql} (
    id                   INTEGER PRIMARY KEY,
    status               TEXT NOT NULL DEFAULT 'lido' CHECK (status IN ('lido', 'validado', 'lancado')),
    origem               TEXT NOT NULL,
    fornecedor           TEXT,
    cnpj                 TEXT,
    numero               TEXT,
    serie                TEXT,
    data_emissao         TEXT,
    valor_total_centavos INTEGER,
    chave_acesso         TEXT UNIQUE,
    grupo_id            INTEGER REFERENCES grupos(id),
    categoria_id         INTEGER REFERENCES categorias(id),
    competencia          TEXT,
    confianca            TEXT NOT NULL DEFAULT '{{}}',
    observacoes          TEXT,
    arquivo_nome         TEXT,
    arquivo_mime         TEXT,
    arquivo_sha256       TEXT,
    arquivo_ref          TEXT,
    arquivo_local        TEXT CHECK (arquivo_local IS NULL OR arquivo_local IN ('entrada', 'destino')),
    criado_em            TEXT NOT NULL,
    validado_em          TEXT
)"""


INDICES = """
CREATE INDEX IF NOT EXISTS ix_notas_competencia ON notas (competencia);
CREATE INDEX IF NOT EXISTS ix_notas_grupo      ON notas (grupo_id);
CREATE INDEX IF NOT EXISTS ix_notas_sha256      ON notas (arquivo_sha256);
CREATE INDEX IF NOT EXISTS ix_itens_nota        ON itens (nota_id);
"""

ESQUEMA = f"""
CREATE TABLE IF NOT EXISTS categorias (
    id   INTEGER PRIMARY KEY,
    nome TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS grupos (
    id                 INTEGER PRIMARY KEY,
    nome               TEXT NOT NULL UNIQUE COLLATE NOCASE,
    data_grupo        TEXT,
    orcamento_centavos INTEGER,
    criado_em          TEXT NOT NULL
);

{_ddl_notas("IF NOT EXISTS notas")};

CREATE TABLE IF NOT EXISTS itens (
    id                      INTEGER PRIMARY KEY,
    nota_id                 INTEGER NOT NULL REFERENCES notas(id) ON DELETE CASCADE,
    descricao               TEXT NOT NULL,
    quantidade              REAL,
    valor_unitario_centavos INTEGER,
    valor_total_centavos    INTEGER
);
"""


def conectar(caminho: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(caminho, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    from .lancamentos import chave_busca
    conn.create_function("chave_busca", 1, chave_busca, deterministic=True)  # busca sem acento nem maiúsculas
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def _migrar_evento_para_grupo(conn: sqlite3.Connection) -> None:
    """Bancos antigos chamavam de 'evento' o que agora é 'grupo': renomeia tabela e colunas sem tocar nos dados."""
    existe = lambda nome: conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (nome,)).fetchone()  # noqa: E731
    if not existe("eventos") or existe("grupos"):
        return
    conn.commit()
    try:
        conn.execute("BEGIN")
        conn.execute("ALTER TABLE eventos RENAME TO grupos")
        conn.execute("ALTER TABLE grupos RENAME COLUMN data_evento TO data_grupo")
        if existe("notas") and "evento_id" in {c["name"] for c in conn.execute("PRAGMA table_info(notas)")}:
            conn.execute("ALTER TABLE notas RENAME COLUMN evento_id TO grupo_id")
        conn.execute("DROP INDEX IF EXISTS ix_notas_evento")
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def _migrar_arquivo_opcional(conn: sqlite3.Connection) -> None:
    """Bancos criados antes do lançamento manual têm arquivo_nome NOT NULL: recria a tabela preservando tudo."""
    colunas = {c["name"]: c for c in conn.execute("PRAGMA table_info(notas)")}
    if not colunas["arquivo_nome"]["notnull"]:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys = OFF")  # exigido pelo SQLite para recriar uma tabela referenciada por outra
    try:
        conn.execute("BEGIN")
        conn.execute(_ddl_notas("notas_nova"))
        conn.execute(f"INSERT INTO notas_nova ({COLUNAS_NOTAS}) SELECT {COLUNAS_NOTAS} FROM notas")
        conn.execute("DROP TABLE notas")
        conn.execute("ALTER TABLE notas_nova RENAME TO notas")
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def _migrar_tipo_documento(conn: sqlite3.Connection) -> None:
    """Notas antigas ficam com tipo_documento NULL (= desconhecido), sem perder nada."""
    colunas = {c["name"] for c in conn.execute("PRAGMA table_info(notas)")}
    if "tipo_documento" not in colunas:
        conn.execute("ALTER TABLE notas ADD COLUMN tipo_documento TEXT")
    if "regioes" not in colunas:  # onde cada campo foi lido na foto (JSON), para destacar na tela
        conn.execute("ALTER TABLE notas ADD COLUMN regioes TEXT")


# ---------------------------------------------------------------------------- migrações numeradas
# A versão do banco fica gravada nele mesmo (PRAGMA user_version). Cada migração roda UMA vez, em ordem, e o
# Midas faz uma cópia de segurança antes de qualquer migração pendente num banco que já tem dados.
# Para mudar a estrutura: acrescente uma função no fim de MIGRACOES (nunca altere uma que já foi publicada).

def _m001_estrutura_inicial(conn: sqlite3.Connection) -> None:
    """Leva qualquer banco anterior às migrações numeradas (ou um banco novo) à estrutura de outubro de 2026."""
    _migrar_evento_para_grupo(conn)   # antes do ESQUEMA, para não criar uma tabela 'grupos' vazia ao lado de 'eventos'
    conn.executescript(ESQUEMA)
    _migrar_arquivo_opcional(conn)
    _migrar_tipo_documento(conn)
    conn.executescript(INDICES)
    if conn.execute("SELECT COUNT(*) FROM categorias").fetchone()[0] == 0:
        conn.executemany("INSERT INTO categorias (nome) VALUES (?)", [(n,) for n in CATEGORIAS_PADRAO])


def _m002_lancamentos(conn: sqlite3.Connection) -> None:
    """O lançamento vira a peça central: todo dinheiro que entra ou sai. A nota fiscal passa a ser o documento de
    um lançamento de despesa; as notas já arquivadas ganham o seu lançamento aqui."""
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS contas (
        id                     INTEGER PRIMARY KEY,
        nome                   TEXT NOT NULL UNIQUE COLLATE NOCASE,
        tipo                   TEXT NOT NULL DEFAULT 'banco' CHECK (tipo IN ('caixa', 'banco', 'cartao')),
        saldo_inicial_centavos INTEGER NOT NULL DEFAULT 0,
        saldo_inicial_em       TEXT,
        ativa                  INTEGER NOT NULL DEFAULT 1,
        criado_em              TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lancamentos (
        id              INTEGER PRIMARY KEY,
        tipo            TEXT NOT NULL CHECK (tipo IN ('despesa', 'receita')),
        descricao       TEXT NOT NULL,
        valor_centavos  INTEGER NOT NULL CHECK (valor_centavos >= 0),
        data            TEXT NOT NULL,              -- quando aconteceu (para nota: a emissão)
        competencia     TEXT NOT NULL,              -- mês a que pertence (AAAA-MM)
        categoria_id    INTEGER REFERENCES categorias(id),
        grupo_id        INTEGER REFERENCES grupos(id),
        conta_id        INTEGER REFERENCES contas(id),
        forma_pagamento TEXT,
        situacao        TEXT NOT NULL DEFAULT 'pago'
                        CHECK (situacao IN ('previsto', 'a_pagar', 'pago', 'a_receber', 'recebido', 'cancelado')),
        vencimento      TEXT,
        pago_em         TEXT,
        nota_id         INTEGER UNIQUE REFERENCES notas(id) ON DELETE CASCADE,
        observacoes     TEXT,
        exportado_em    TEXT,                       -- quando entrou numa planilha "lançada"
        criado_em       TEXT NOT NULL,
        atualizado_em   TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_lanc_competencia ON lancamentos (competencia);
    CREATE INDEX IF NOT EXISTS ix_lanc_categoria   ON lancamentos (categoria_id);
    CREATE INDEX IF NOT EXISTS ix_lanc_grupo       ON lancamentos (grupo_id);
    """)
    conn.execute("""
        INSERT INTO lancamentos (tipo, descricao, valor_centavos, data, competencia, categoria_id, grupo_id,
                                 situacao, pago_em, nota_id, exportado_em, criado_em, atualizado_em)
        SELECT 'despesa', COALESCE(NULLIF(TRIM(fornecedor), ''), 'Nota #' || id), COALESCE(valor_total_centavos, 0),
               COALESCE(data_emissao, SUBSTR(criado_em, 1, 10)), COALESCE(competencia, SUBSTR(data_emissao, 1, 7)),
               categoria_id, grupo_id, 'pago', data_emissao, id,
               CASE WHEN status = 'lancado' THEN COALESCE(validado_em, criado_em) END,
               COALESCE(validado_em, criado_em), COALESCE(validado_em, criado_em)
        FROM notas
        WHERE status IN ('validado', 'lancado') AND id NOT IN (SELECT nota_id FROM lancamentos WHERE nota_id IS NOT NULL)
    """)


def _m003_forma_e_anexos(conn: sqlite3.Connection) -> None:
    """Forma de pagamento lida do documento (na nota) e anexo opcional em lançamento sem nota."""
    colunas = {c["name"] for c in conn.execute("PRAGMA table_info(notas)")}
    if "forma_pagamento" not in colunas:
        conn.execute("ALTER TABLE notas ADD COLUMN forma_pagamento TEXT")
    colunas = {c["name"] for c in conn.execute("PRAGMA table_info(lancamentos)")}
    for coluna in ("arquivo_nome", "arquivo_mime", "arquivo_sha256", "arquivo_ref"):
        if coluna not in colunas:
            conn.execute(f"ALTER TABLE lancamentos ADD COLUMN {coluna} TEXT")


RECEITAS_PADRAO = ["Patrocínios", "Inscrições", "Mensalidades", "Doações", "Outras receitas"]


def _m004_tipos_e_contatos(conn: sqlite3.Connection) -> None:
    """Categorias de despesa e de receita, com subcategorias; fornecedores e clientes (contatos) ligados aos
    lançamentos. Os fornecedores das notas já arquivadas viram contatos pelo CNPJ."""
    colunas = {c["name"] for c in conn.execute("PRAGMA table_info(categorias)")}
    if "tipo" not in colunas:
        conn.execute("ALTER TABLE categorias ADD COLUMN tipo TEXT NOT NULL DEFAULT 'despesa'")
    if "pai_id" not in colunas:
        conn.execute("ALTER TABLE categorias ADD COLUMN pai_id INTEGER REFERENCES categorias(id)")
    existentes = {r[0].casefold() for r in conn.execute("SELECT nome FROM categorias")}
    if not conn.execute("SELECT 1 FROM categorias WHERE tipo = 'receita'").fetchone():
        conn.executemany("INSERT INTO categorias (nome, tipo) VALUES (?, 'receita')",
                         [(n,) for n in RECEITAS_PADRAO if n.casefold() not in existentes])

    conn.executescript("""
    CREATE TABLE IF NOT EXISTS contatos (
        id          INTEGER PRIMARY KEY,
        nome        TEXT NOT NULL,
        cnpj        TEXT UNIQUE,
        tipo        TEXT NOT NULL DEFAULT 'fornecedor' CHECK (tipo IN ('fornecedor', 'cliente', 'ambos')),
        observacoes TEXT,
        criado_em   TEXT NOT NULL
    );
    """)
    if "contato_id" not in {c["name"] for c in conn.execute("PRAGMA table_info(lancamentos)")}:
        conn.execute("ALTER TABLE lancamentos ADD COLUMN contato_id INTEGER REFERENCES contatos(id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_lanc_contato ON lancamentos (contato_id)")
    # um contato por CNPJ das notas, com o nome da nota mais recente
    conn.execute("""
        INSERT INTO contatos (nome, cnpj, tipo, criado_em)
        SELECT (SELECT COALESCE(NULLIF(TRIM(n2.fornecedor), ''), n2.cnpj) FROM notas n2
                WHERE n2.cnpj = n.cnpj AND n2.status IN ('validado', 'lancado') ORDER BY n2.data_emissao DESC, n2.id DESC LIMIT 1),
               n.cnpj, 'fornecedor', MIN(n.criado_em)
        FROM notas n
        WHERE n.status IN ('validado', 'lancado') AND n.cnpj IS NOT NULL AND n.cnpj <> ''
          AND n.cnpj NOT IN (SELECT cnpj FROM contatos WHERE cnpj IS NOT NULL)
        GROUP BY n.cnpj""")
    conn.execute("""
        UPDATE lancamentos SET contato_id = (
            SELECT k.id FROM notas n JOIN contatos k ON k.cnpj = n.cnpj WHERE n.id = lancamentos.nota_id)
        WHERE nota_id IS NOT NULL AND contato_id IS NULL""")


MIGRACOES: list[tuple[int, str, object]] = [
    (1, "estrutura inicial (notas, itens, grupos, categorias)", _m001_estrutura_inicial),
    (2, "lançamentos e contas; notas arquivadas viram lançamentos", _m002_lancamentos),
    (3, "forma de pagamento nas notas; anexo em lançamento sem nota", _m003_forma_e_anexos),
    (4, "categorias de despesa e de receita, subcategorias; fornecedores e clientes", _m004_tipos_e_contatos),
]
VERSAO_BANCO = MIGRACOES[-1][0]


class BancoMaisNovo(RuntimeError):
    """O banco foi atualizado por uma versão mais nova do Midas do que a que está tentando abri-lo."""


def versao_do_banco(conn: sqlite3.Connection) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def _tem_dados(conn: sqlite3.Connection) -> bool:
    return conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0] > 0


def iniciar_banco(caminho: Path, pasta_backups: Path | None = None) -> list[int]:
    """Cria ou atualiza o banco. Devolve os números das migrações aplicadas agora (vazio = já estava em dia)."""
    from . import backup

    caminho.parent.mkdir(parents=True, exist_ok=True)
    pasta_backups = pasta_backups or caminho.parent / "backups"
    conn = conectar(caminho)
    try:
        atual = versao_do_banco(conn)
        if atual > VERSAO_BANCO:
            raise BancoMaisNovo(
                f"Os dados foram atualizados por uma versão mais nova do Midas (banco v{atual}; esta versão conhece "
                f"até v{VERSAO_BANCO}). Instale a versão mais recente do Midas.")
        pendentes = [m for m in MIGRACOES if m[0] > atual]
        if pendentes and _tem_dados(conn):
            conn.close()
            backup.fazer(caminho, pasta_backups, f"antes-v{VERSAO_BANCO}")
            conn = conectar(caminho)
        for numero, _descricao, migrar in pendentes:
            migrar(conn)
            conn.execute(f"PRAGMA user_version = {int(numero)}")
            conn.commit()
        return [m[0] for m in pendentes]
    finally:
        conn.close()
