"""Leitura de boleto: pela linha digitável (colada) ou pelo PDF.

Dois formatos da FEBRABAN:
- Boleto de banco (47 números, começa pelo código do banco): 3 campos com dígito pelo módulo 10, o dígito geral pelo
  módulo 11, o fator de vencimento e o valor. O fator conta dias desde 07/10/1997 e, ao chegar a 9999 (21/02/2025),
  recomeçou em 1000 (22/02/2025); das duas leituras possíveis vale a mais próxima de hoje.
- Arrecadação (48 números, começa com 8): contas de luz, água, telefone, tributos. Quatro blocos de 11 números + dígito
  (módulo 10 ou 11, conforme o 3º número). Tem valor, mas o vencimento não tem lugar fixo: quando os números trazem uma
  data plausível, ela vem marcada como "confira".

Nada aqui acessa a internet: tudo sai dos próprios números (e do texto do PDF, para o beneficiário).
"""
from __future__ import annotations

import re
from datetime import date, timedelta

from .erros import ArquivoInvalido
from .validation import cnpj_valido

BANCOS = {
    "001": "Banco do Brasil", "004": "Banco do Nordeste", "021": "Banestes", "033": "Santander", "037": "Banpará",
    "041": "Banrisul", "047": "Banese", "070": "BRB", "077": "Banco Inter", "085": "Ailos", "104": "Caixa",
    "136": "Unicred", "197": "Stone", "208": "BTG Pactual", "212": "Banco Original", "237": "Bradesco",
    "260": "Nubank", "290": "PagBank", "323": "Mercado Pago", "336": "C6 Bank", "341": "Itaú", "380": "PicPay",
    "389": "Banco Mercantil", "399": "HSBC", "403": "Cora", "422": "Safra", "637": "Sofisa", "655": "Banco BV",
    "707": "Daycoval", "745": "Citibank", "748": "Sicredi", "756": "Sicoob",
}
SEGMENTOS = {"1": "Prefeitura", "2": "Saneamento (água e esgoto)", "3": "Energia elétrica e gás", "4": "Telecomunicações",
             "5": "Órgão governamental", "6": "Carnê ou cobrança de empresa", "7": "Multa de trânsito",
             "9": "Uso exclusivo do banco"}
BASE_FATOR = date(1997, 10, 7)
BASE_FATOR_NOVA = date(2025, 2, 22)    # fator 1000 do segundo ciclo


# ============================================================================ dígitos verificadores
def modulo10(numeros: str) -> int:
    soma, peso = 0, 2
    for d in reversed(numeros):
        p = int(d) * peso
        soma += p // 10 + p % 10
        peso = 1 if peso == 2 else 2
    return (10 - soma % 10) % 10


def _soma11(numeros: str) -> int:
    soma, peso = 0, 2
    for d in reversed(numeros):
        soma += int(d) * peso
        peso = 2 if peso == 9 else peso + 1
    return soma % 11


def modulo11_banco(numeros: str) -> int:
    dv = 11 - _soma11(numeros)
    return 1 if dv in (0, 10, 11) else dv


def modulo11_arrecadacao(numeros: str) -> int:
    resto = _soma11(numeros)
    return 0 if resto in (0, 1) else 11 - resto


# ============================================================================ datas e formatos
def vencimento_do_fator(fator: int, hoje: date | None = None) -> date | None:
    if fator == 0:
        return None
    hoje = hoje or date.today()
    candidatos = [BASE_FATOR + timedelta(days=fator)]
    if fator >= 1000:
        candidatos.append(BASE_FATOR_NOVA + timedelta(days=fator - 1000))
    return min(candidatos, key=lambda d: abs((d - hoje).days))


def fator_da_data(d: date) -> int:
    """O inverso (usado nos testes e para conferir): a data no ciclo atual."""
    if d >= BASE_FATOR_NOVA:
        return 1000 + (d - BASE_FATOR_NOVA).days
    return (d - BASE_FATOR).days


def formatar(digitos: str) -> str:
    if len(digitos) == 47:
        d = digitos
        return f"{d[0:5]}.{d[5:10]} {d[10:15]}.{d[15:21]} {d[21:26]}.{d[26:32]} {d[32]} {d[33:47]}"
    if len(digitos) == 48:
        return " ".join(f"{digitos[i:i + 11]}-{digitos[i + 11]}" for i in range(0, 48, 12))
    return digitos


def so_digitos(texto: str | None) -> str:
    return re.sub(r"\D", "", texto or "")


# ============================================================================ leitura
def _ler_bancario(d: str, hoje: date) -> dict:
    campos = ((d[0:9], d[9], 1), (d[10:20], d[20], 2), (d[21:31], d[31], 3))
    for numeros, dv, n in campos:
        if modulo10(numeros) != int(dv):
            raise ArquivoInvalido(f"O {n}º bloco da linha digitável não confere (dígito verificador). "
                                  "Confira se foi copiada inteira e sem troca de números.")
    barras = d[0:4] + d[32] + d[33:47] + d[4:9] + d[10:20] + d[21:31]
    if modulo11_banco(barras[:4] + barras[5:]) != int(barras[4]):
        raise ArquivoInvalido("O dígito geral da linha digitável não confere. Confira se foi copiada inteira.")
    fator, valor = int(d[33:37]), int(d[37:47])
    venc = vencimento_do_fator(fator, hoje)
    return {"tipo": "bancario", "banco_codigo": d[0:3], "banco": BANCOS.get(d[0:3], f"Banco {d[0:3]}"),
            "codigo_barras": barras, "valor_centavos": valor or None,
            "vencimento": venc.isoformat() if venc else None, "vencimento_incerto": False, "segmento": None}


def _ler_arrecadacao(barras: str, hoje: date, blocos: str | None = None) -> dict:
    if barras[0] != "8":
        raise ArquivoInvalido("Código de arrecadação deve começar com 8.")
    ident = barras[2]
    if ident not in "6789":
        raise ArquivoInvalido("Código de arrecadação com identificador de valor desconhecido.")
    modulo = modulo10 if ident in "67" else modulo11_arrecadacao
    if blocos:
        for i in range(4):
            bloco = blocos[i * 12:(i + 1) * 12]
            if modulo(bloco[:11]) != int(bloco[11]):
                raise ArquivoInvalido(f"O {i + 1}º bloco da linha digitável não confere (dígito verificador). "
                                      "Confira se foi copiada inteira e sem troca de números.")
    if modulo(barras[:3] + barras[4:]) != int(barras[3]):
        raise ArquivoInvalido("O dígito geral do código não confere. Confira se foi copiado inteiro.")
    valor = int(barras[4:15]) if ident in "68" else 0
    # vencimento: sem posição fixa. Muitas concessionárias põem AAAAMMDD logo depois da identificação da empresa.
    venc = None
    for ini in (19, 23, 20, 27):
        trecho = barras[ini:ini + 8]
        try:
            d = date(int(trecho[:4]), int(trecho[4:6]), int(trecho[6:8]))
        except ValueError:
            continue
        if abs((d - hoje).days) <= 400:
            venc = d
            break
    return {"tipo": "arrecadacao", "banco_codigo": None, "banco": None, "codigo_barras": barras,
            "valor_centavos": valor or None, "vencimento": venc.isoformat() if venc else None,
            "vencimento_incerto": venc is not None, "segmento": SEGMENTOS.get(barras[1])}


def ler_linha(texto: str, hoje: date | None = None) -> dict:
    """Linha digitável (47 ou 48 números) ou os 44 números do código de barras, com ou sem pontos e espaços."""
    hoje = hoje or date.today()
    d = so_digitos(texto)
    if len(d) == 47:
        r = _ler_bancario(d, hoje)
        linha = d
    elif len(d) == 48:
        barras = "".join(d[i:i + 11] for i in range(0, 48, 12))
        r = _ler_arrecadacao(barras, hoje, blocos=d)
        linha = d
    elif len(d) == 44:      # código de barras (lido por leitor): vira linha digitável
        if d[0] == "8":
            r = _ler_arrecadacao(d, hoje)
            modulo = modulo10 if d[2] in "67" else modulo11_arrecadacao
            linha = "".join(d[i:i + 11] + str(modulo(d[i:i + 11])) for i in range(0, 44, 11))
        else:
            if modulo11_banco(d[:4] + d[5:]) != int(d[4]):
                raise ArquivoInvalido("O dígito do código de barras não confere.")
            livre = d[19:44]
            c1, c2, c3 = d[0:4] + livre[0:5], livre[5:15], livre[15:25]
            linha = (c1 + str(modulo10(c1)) + c2 + str(modulo10(c2)) + c3 + str(modulo10(c3)) + d[4] + d[5:19])
            r = _ler_bancario(linha, hoje)
    else:
        raise ArquivoInvalido(
            f"A linha digitável tem 47 números (boleto de banco) ou 48 (conta de luz, água, telefone, tributo); "
            f"esta tem {len(d)}." if d else "Cole a linha digitável do boleto (os números embaixo do nome do banco).")
    r["linha_digitavel"] = linha
    r["linha_formatada"] = formatar(linha)
    return r


# ============================================================================ PDF
_RE_BANCARIO = re.compile(r"\d{5}[.\s]?\d{5}\s*\d{5}[.\s]?\d{6}\s*\d{5}[.\s]?\d{6}\s*\d\s*\d{14}")
_RE_ARRECADACAO = re.compile(r"8\d{10}[-\s]?\d\s*\d{11}[-\s]?\d\s*\d{11}[-\s]?\d\s*\d{11}[-\s]?\d")
_RE_CNPJ = re.compile(r"\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}")
_RE_ROTULO_BENEF = re.compile(r"\b(benefici[aá]rio|cedente)\b\s*(final)?\s*[:\-]?\s*", re.I)


def achar_linha_no_texto(texto: str, hoje: date | None = None) -> dict | None:
    candidatos = [m.group(0) for m in _RE_BANCARIO.finditer(texto)] + [m.group(0) for m in _RE_ARRECADACAO.finditer(texto)]
    for linha in texto.splitlines():    # números quebrados de outro jeito numa linha só
        d = so_digitos(linha)
        if len(d) in (47, 48) and d not in map(so_digitos, candidatos):
            candidatos.append(d)
    for c in candidatos:
        try:
            return ler_linha(c, hoje)
        except ArquivoInvalido:
            continue
    return None


def _limpar_nome(texto: str) -> str:
    texto = _RE_CNPJ.sub("", texto)
    texto = re.sub(r"\b(CNPJ|CPF|CPF/CNPJ|CNPJ/CPF)\b\s*[:.]?", "", texto, flags=re.I)
    texto = re.sub(r"\s*[-–|]\s*$", "", texto.strip())
    return " ".join(texto.split()).strip(" -–:|")


def beneficiario_no_texto(texto: str) -> tuple[str | None, str | None]:
    """Nome e CNPJ de quem recebe, pelo rótulo 'Beneficiário' (ou 'Cedente') do boleto."""
    linhas = [l.strip() for l in texto.splitlines()]
    for i, l in enumerate(linhas):
        m = _RE_ROTULO_BENEF.search(l)
        if not m or m.group(2):          # "Beneficiário final" é outra pessoa
            continue
        perto = linhas[i:i + 3]
        cnpj = next((c for c in (so_digitos(x) for t in perto for x in _RE_CNPJ.findall(t)) if cnpj_valido(c)), None)
        nome = _limpar_nome(l[m.end():])
        if len(nome) < 3 or re.fullmatch(r"(ag[eê]ncia|c[oó]digo|endere[cç]o).*", nome, re.I):
            nome = next((_limpar_nome(x) for x in linhas[i + 1:i + 3]
                         if len(_limpar_nome(x)) >= 3 and not re.search(r"\d{4,}", _limpar_nome(x))), "")
        nome = re.split(r"\s{2,}|\b(ag[eê]ncia|nosso n[uú]mero|vencimento)\b", nome, flags=re.I)[0].strip(" -–:|")
        if nome or cnpj:
            return (nome or None), cnpj
    return None, None


def ler_pdf(conteudo: bytes, hoje: date | None = None) -> dict:
    from .extractors.danfe import texto_do_pdf
    texto = texto_do_pdf(conteudo)
    if not texto.strip():
        raise ArquivoInvalido("Este PDF não tem texto (é uma imagem). Cole a linha digitável do boleto.")
    r = achar_linha_no_texto(texto, hoje)
    if r is None:
        raise ArquivoInvalido("Não achei a linha digitável neste PDF. Cole os números do boleto.")
    r["beneficiario"], r["cnpj"] = beneficiario_no_texto(texto)
    return r
