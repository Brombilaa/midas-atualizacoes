"""Contas fixas: o que se repete todo mês (aluguel, internet, contador, mensalidades a receber).

Cada conta fixa é um modelo: valor (fixo, ou estimado quando muda todo mês, como luz e água), dia do vencimento,
primeiro mês e, se houver, o último. O Midas gera o lançamento dos próximos meses (o corrente e os dois seguintes)
como "previsto", e eles aparecem na Agenda. Quando a conta chega (o boleto, a fatura), o previsto vira "a pagar" ou é
pago direto. Gerar de novo nunca duplica: é um lançamento por conta fixa e por mês (índice único no banco), e o mês
cujo lançamento foi cancelado não volta.

Mudar o modelo (valor, dia, categoria...) acompanha os previstos ainda não mexidos a partir do mês corrente; o que já
foi pago ou passou para "a pagar" fica como está. Encerrar mantém o mês corrente e tira os previstos seguintes.
"""
from __future__ import annotations

import calendar
from datetime import date

from . import lancamentos
from .erros import ArquivoInvalido, Conflito, NaoEncontrado
from .extractors.base import FORMAS_PAGAMENTO
from .lancamentos import RE_COMPETENCIA, _agora, contato_para

HORIZONTE_MESES = 3    # o mês corrente e os dois seguintes

CAMPOS = ("tipo", "descricao", "valor_centavos", "valor_estimado", "dia", "inicio", "fim", "categoria_id", "grupo_id",
          "conta_id", "forma_pagamento", "observacoes")
# o que passa do modelo para os previstos ainda não mexidos
CAMPOS_DO_PREVISTO = ("descricao", "valor_centavos", "categoria_id", "grupo_id", "conta_id", "contato_id",
                      "forma_pagamento")


def mes_de(d: date) -> str:
    return d.strftime("%Y-%m")


def somar_meses(mes: str, n: int) -> str:
    ano, m = map(int, mes.split("-"))
    total = ano * 12 + (m - 1) + n
    return f"{total // 12:04d}-{total % 12 + 1:02d}"


def dia_no_mes(mes: str, dia: int) -> str:
    """Dia 31 em fevereiro vira o último dia de fevereiro."""
    ano, m = map(int, mes.split("-"))
    return date(ano, m, min(dia, calendar.monthrange(ano, m)[1])).isoformat()


# ============================================================================ consulta
_SQL = f"""SELECT r.*, ct.nome AS contato, k.nome AS conta, g.nome AS grupo,
                  {lancamentos.NOME_CATEGORIA} AS categoria,
                  (SELECT MIN(COALESCE(l.vencimento, l.data)) FROM lancamentos l
                    WHERE l.recorrencia_id = r.id AND l.situacao IN ('previsto', 'a_pagar', 'a_receber')) AS proximo,
                  (SELECT COUNT(*) FROM lancamentos l WHERE l.recorrencia_id = r.id AND l.situacao <> 'cancelado')
                      AS qtd_lancamentos
           FROM recorrencias r
           LEFT JOIN contatos ct   ON ct.id = r.contato_id
           LEFT JOIN contas k      ON k.id = r.conta_id
           LEFT JOIN grupos g      ON g.id = r.grupo_id
           LEFT JOIN categorias c  ON c.id = r.categoria_id
           LEFT JOIN categorias cp ON cp.id = c.pai_id"""


def _saida(r) -> dict:
    d = dict(r)
    d["valor_estimado"] = bool(d["valor_estimado"])
    d["ativa"] = bool(d["ativa"])
    return d


def listar(conn) -> list[dict]:
    """Ativas primeiro (pelo dia do vencimento), depois as encerradas."""
    return [_saida(r) for r in conn.execute(f"{_SQL} ORDER BY r.ativa DESC, r.dia, r.descricao COLLATE NOCASE")]


def obter(conn, recorrencia_id: int) -> dict:
    r = conn.execute(f"{_SQL} WHERE r.id = ?", (recorrencia_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Conta fixa #{recorrencia_id} não encontrada.")
    return _saida(r)


# ============================================================================ criar e editar
def _conferir(conn, campos: dict) -> None:
    if "tipo" in campos and campos["tipo"] not in lancamentos.TIPOS:
        raise ArquivoInvalido("Tipo deve ser despesa ou receita.")
    if "descricao" in campos:
        campos["descricao"] = " ".join((campos["descricao"] or "").split())
        if not campos["descricao"]:
            raise ArquivoInvalido("Informe uma descrição (ex.: Aluguel da sede).")
    if "valor_centavos" in campos and (campos["valor_centavos"] is None or campos["valor_centavos"] <= 0):
        raise ArquivoInvalido("Informe um valor maior que zero (se ele muda todo mês, use uma estimativa).")
    if "dia" in campos and not (isinstance(campos["dia"], int) and 1 <= campos["dia"] <= 31):
        raise ArquivoInvalido("O dia do vencimento vai de 1 a 31.")
    for chave in ("inicio", "fim"):
        if campos.get(chave) is not None and not RE_COMPETENCIA.fullmatch(campos[chave]):
            raise ArquivoInvalido("Mês deve estar no formato AAAA-MM.")
    if campos.get("forma_pagamento") is not None and campos["forma_pagamento"] not in FORMAS_PAGAMENTO:
        raise ArquivoInvalido("Forma de pagamento desconhecida.")
    if "valor_estimado" in campos:
        campos["valor_estimado"] = 1 if campos["valor_estimado"] else 0
    if "observacoes" in campos:
        campos["observacoes"] = (campos["observacoes"] or "").strip() or None
    for chave, tabela, nome in (("categoria_id", "categorias", "Categoria"), ("grupo_id", "grupos", "Grupo"),
                                ("conta_id", "contas", "Conta")):
        if campos.get(chave) is not None and not conn.execute(
                f"SELECT 1 FROM {tabela} WHERE id = ?", (campos[chave],)).fetchone():
            raise NaoEncontrado(f"{nome} #{campos[chave]} não encontrado(a).")


def _conferir_final(conn, final: dict) -> None:
    if final.get("fim") and final["fim"] < final["inicio"]:
        raise ArquivoInvalido("O último mês não pode ser antes do primeiro.")
    lancamentos._categoria_do_tipo(conn, final.get("categoria_id"), final["tipo"])


def criar(conn, campos: dict, hoje: date | None = None) -> dict:
    hoje = hoje or date.today()
    contato_nome = campos.pop("contato_nome", None)
    campos = {k: v for k, v in campos.items() if k in CAMPOS}
    campos.setdefault("tipo", "despesa")
    for obrigatorio in ("descricao", "valor_centavos", "dia"):
        campos.setdefault(obrigatorio, None)
    campos["inicio"] = campos.get("inicio") or mes_de(hoje)
    _conferir(conn, campos)
    if campos["inicio"] == mes_de(hoje) and campos["dia"] and dia_no_mes(campos["inicio"], campos["dia"]) < hoje.isoformat():
        campos["inicio"] = somar_meses(campos["inicio"], 1)   # o vencimento deste mês já passou: começa no próximo
    _conferir_final(conn, campos)
    agora = _agora()
    with conn:
        campos["contato_id"] = contato_para(conn, contato_nome, campos["tipo"])
        campos |= {"ativa": 1, "criado_em": agora, "atualizado_em": agora}
        cur = conn.execute(f"INSERT INTO recorrencias ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                           tuple(campos.values()))
        gerar_previstos(conn, hoje, apenas=cur.lastrowid)
    return obter(conn, cur.lastrowid)


def _previstos_seguintes(conn, recorrencia_id: int, a_partir: str) -> list:
    """Lançamentos da conta fixa ainda como 'previsto' (ninguém mexeu) a partir de um mês."""
    return conn.execute("""SELECT * FROM lancamentos WHERE recorrencia_id = ? AND situacao = 'previsto'
                           AND competencia >= ?""", (recorrencia_id, a_partir)).fetchall()


def atualizar(conn, recorrencia_id: int, campos: dict, hoje: date | None = None) -> dict:
    hoje = hoje or date.today()
    atual = dict(conn.execute("SELECT * FROM recorrencias WHERE id = ?", (recorrencia_id,)).fetchone() or {})
    if not atual:
        raise NaoEncontrado(f"Conta fixa #{recorrencia_id} não encontrada.")
    tem_contato = "contato_nome" in campos
    contato_nome = campos.pop("contato_nome", None)
    campos = {k: v for k, v in campos.items() if k in CAMPOS + ("ativa",)}
    if "tipo" in campos and campos["tipo"] != atual["tipo"] and conn.execute(
            "SELECT 1 FROM lancamentos WHERE recorrencia_id = ? AND situacao <> 'previsto'", (recorrencia_id,)).fetchone():
        raise Conflito("Esta conta fixa já tem lançamentos pagos: para trocar entre despesa e receita, encerre-a e "
                       "cadastre outra.")
    if "inicio" in campos and not campos["inicio"]:
        campos.pop("inicio")
    _conferir(conn, campos)
    final = atual | campos
    _conferir_final(conn, final)
    mes_atual = mes_de(hoje)
    with conn:
        if tem_contato:
            final["contato_id"] = contato_para(conn, contato_nome, final["tipo"])
        if "ativa" in campos:
            final["ativa"] = 1 if campos["ativa"] else 0
            if not final["ativa"] and (not final.get("fim") or final["fim"] > mes_atual):
                final["fim"] = max(mes_atual, final["inicio"])     # encerrar: fica o mês corrente
            if final["ativa"] and atual["fim"] and "fim" not in campos and atual["fim"] <= mes_atual:
                final["fim"] = None                                # reativar sem fim escolhido: volta sem fim
        mudancas = {k: final[k] for k in CAMPOS + ("ativa", "contato_id") if final.get(k) != atual.get(k)}
        if mudancas:
            sets = ", ".join(f"{k} = ?" for k in mudancas)
            conn.execute(f"UPDATE recorrencias SET {sets}, atualizado_em = ? WHERE id = ?",
                         (*mudancas.values(), _agora(), recorrencia_id))
        # os previstos ainda não mexidos acompanham o modelo; os que passaram do fim (ou de antes do início) saem
        for l in _previstos_seguintes(conn, recorrencia_id, mes_atual):
            fora = l["competencia"] < final["inicio"] or (final.get("fim") and l["competencia"] > final["fim"])
            if fora:
                conn.execute("DELETE FROM lancamentos WHERE id = ?", (l["id"],))
                continue
            novo = {k: final[k] for k in CAMPOS_DO_PREVISTO} | {"tipo": final["tipo"]}
            novo["data"] = novo["vencimento"] = dia_no_mes(l["competencia"], final["dia"])
            diferente = {k: v for k, v in novo.items() if l[k] != v}
            if diferente:
                sets = ", ".join(f"{k} = ?" for k in diferente)
                conn.execute(f"UPDATE lancamentos SET {sets}, atualizado_em = ? WHERE id = ?",
                             (*diferente.values(), _agora(), l["id"]))
        gerar_previstos(conn, hoje, apenas=recorrencia_id)
    return obter(conn, recorrencia_id)


def excluir(conn, recorrencia_id: int, hoje: date | None = None) -> None:
    """Apaga o modelo e os previstos ainda não mexidos; o que já foi pago ou está a pagar continua (sem o vínculo)."""
    obter(conn, recorrencia_id)
    with conn:
        conn.execute("DELETE FROM lancamentos WHERE recorrencia_id = ? AND situacao = 'previsto'", (recorrencia_id,))
        conn.execute("UPDATE lancamentos SET recorrencia_id = NULL WHERE recorrencia_id = ?", (recorrencia_id,))
        conn.execute("DELETE FROM recorrencias WHERE id = ?", (recorrencia_id,))


def de_um_lancamento(conn, lancamento_id: int, dia: int | None = None, hoje: date | None = None) -> dict:
    """'Repetir todo mês' a partir de um lançamento: o modelo copia o lançamento e começa no mês seguinte ao dele
    (o próprio lançamento passa a ser o primeiro da série)."""
    hoje = hoje or date.today()
    l = lancamentos.obter(conn, lancamento_id)
    if l["recorrencia_id"]:
        raise Conflito("Este lançamento já faz parte de uma conta fixa.")
    referencia = l["vencimento"] or l["data"]
    campos = {"tipo": l["tipo"], "descricao": l["descricao"], "valor_centavos": l["valor_centavos"],
              "dia": dia or int(referencia[8:10]), "inicio": l["competencia"], "categoria_id": l["categoria_id"],
              "grupo_id": l["grupo_id"], "conta_id": l["conta_id"], "forma_pagamento": l["forma_pagamento"],
              "contato_nome": l["contato"]}
    with conn:
        # o lançamento de origem ocupa o mês dele na série (por isso não passa por criar())
        contato_nome = campos.pop("contato_nome")
        _conferir(conn, campos)
        agora = _agora()
        campos["contato_id"] = contato_para(conn, contato_nome, campos["tipo"]) if contato_nome else l["contato_id"]
        campos |= {"ativa": 1, "criado_em": agora, "atualizado_em": agora}
        cur = conn.execute(f"INSERT INTO recorrencias ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                           tuple(campos.values()))
        rec = cur.lastrowid
        conn.execute("UPDATE lancamentos SET recorrencia_id = ? WHERE id = ?", (rec, lancamento_id))
        gerar_previstos(conn, hoje, apenas=rec)
    return obter(conn, rec)


# ============================================================================ gerar os previstos
def gerar_previstos(conn, hoje: date | None = None, apenas: int | None = None) -> int:
    """Cria o lançamento 'previsto' de cada conta fixa ativa no mês corrente e nos dois seguintes, onde ainda não
    houver. Devolve quantos criou. Chamado ao abrir a Agenda e os Lançamentos, e ao salvar uma conta fixa."""
    hoje = hoje or date.today()
    mes_atual = mes_de(hoje)
    ultimo = somar_meses(mes_atual, HORIZONTE_MESES - 1)
    sql = "SELECT * FROM recorrencias WHERE ativa = 1" + (" AND id = ?" if apenas else "")
    criados = 0
    for r in conn.execute(sql, (apenas,) if apenas else ()).fetchall():
        mes = max(mes_atual, r["inicio"])
        fim = min(ultimo, r["fim"]) if r["fim"] else ultimo
        while mes <= fim:
            if not conn.execute("SELECT 1 FROM lancamentos WHERE recorrencia_id = ? AND competencia = ?",
                                (r["id"], mes)).fetchone():
                vence = dia_no_mes(mes, r["dia"])
                agora = _agora()
                conn.execute(
                    """INSERT INTO lancamentos (tipo, descricao, valor_centavos, data, competencia, categoria_id,
                       grupo_id, conta_id, contato_id, forma_pagamento, situacao, vencimento, recorrencia_id,
                       criado_em, atualizado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'previsto', ?, ?, ?, ?)""",
                    (r["tipo"], r["descricao"], r["valor_centavos"], vence, mes, r["categoria_id"], r["grupo_id"],
                     r["conta_id"], r["contato_id"], r["forma_pagamento"], vence, r["id"], agora, agora))
                criados += 1
            mes = somar_meses(mes, 1)
    return criados
