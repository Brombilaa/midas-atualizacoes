"""Lançamentos e contas: todo dinheiro que entra ou sai. É daqui que saem a aba Lançamentos, o painel do mês, o gasto
dos grupos, o saldo das contas e a planilha, para que os números nunca discordem.

Uma nota fiscal arquivada é o documento de um lançamento de despesa: ao arquivar, o lançamento é criado (ou
atualizado, se a nota foi reaberta e arquivada de novo). Enquanto uma nota está reaberta para correção, o lançamento
dela fica fora das contas, e volta quando ela é arquivada de novo, sem perder o que foi preenchido nele.

Os dados do DOCUMENTO (descrição, valor, data, mês, categoria, grupo, forma de pagamento) de um lançamento com nota
vêm da nota e só mudam por ela. Os dados do LANÇAMENTO (conta, situação, vencimento, data do pagamento, observações)
são editados no próprio lançamento. Lançamento sem nota (receita, despesa sem documento) tem tudo editável.
Nada é apagado: cancelar é uma situação, e o lançamento cancelado sai das contas mas continua listável.
"""
from __future__ import annotations

import re
import sqlite3
import unicodedata
from datetime import date, datetime, timezone

from .erros import ArquivoInvalido, Conflito, NaoEncontrado
from .extractors.base import FORMAS_PAGAMENTO

TIPOS = ("despesa", "receita")
SITUACOES = ("previsto", "a_pagar", "pago", "a_receber", "recebido", "cancelado")
SITUACOES_DO_TIPO = {"despesa": ("previsto", "a_pagar", "pago", "cancelado"),
                     "receita": ("previsto", "a_receber", "recebido", "cancelado")}
QUITADO = {"despesa": "pago", "receita": "recebido"}
TIPOS_CONTA = ("caixa", "banco", "cartao")
RE_COMPETENCIA = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
MANTER = object()   # "não mexer neste campo" (diferente de None, que limpa)

DE_ONDE = """FROM lancamentos l
             LEFT JOIN notas n      ON n.id = l.nota_id
             LEFT JOIN categorias c ON c.id = l.categoria_id
             LEFT JOIN grupos g     ON g.id = l.grupo_id
             LEFT JOIN contas k     ON k.id = l.conta_id"""
# o que conta nos números: não cancelado, e se veio de uma nota, a nota está arquivada (não em correção)
VALE = "l.situacao <> 'cancelado' AND (l.nota_id IS NULL OR n.status IN ('validado', 'lancado'))"

CAMPOS_DO_DOCUMENTO = ("tipo", "descricao", "valor_centavos", "data", "competencia", "categoria_id", "grupo_id",
                       "forma_pagamento")
CAMPOS_DO_LANCAMENTO = ("conta_id", "situacao", "vencimento", "pago_em", "observacoes")


def _agora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def chave_busca(texto: str | None) -> str:
    """'Alimentação' e 'alimentacao' casam: sem acento, sem maiúsculas, espaços simples."""
    sem_acento = "".join(ch for ch in unicodedata.normalize("NFKD", texto or "") if not unicodedata.combining(ch))
    return " ".join(sem_acento.casefold().split())


def _iso(valor) -> str | None:
    if valor is None or valor == "":
        return None
    if isinstance(valor, date):
        return valor.isoformat()
    try:
        return date.fromisoformat(str(valor)[:10]).isoformat()
    except ValueError as e:
        raise ArquivoInvalido("Data inválida (use AAAA-MM-DD).") from e


# ============================================================================ notas -> lançamentos
def sincronizar_nota(conn, nota_id: int, criar: bool = True, conta_id=MANTER) -> int | None:
    """Cria ou atualiza o lançamento de uma nota arquivada. Roda dentro da mesma transação do arquivamento.

    Com `criar=False` só acompanha uma nota reaberta que já tem lançamento (a correção não deixa o lançamento com
    dado antigo). `conta_id` vem da ficha ao arquivar; MANTER deixa a conta como está.
    """
    n = conn.execute("SELECT * FROM notas WHERE id = ?", (nota_id,)).fetchone()
    descricao = (n["fornecedor"] or "").strip() or f"Nota #{nota_id}"
    data = n["data_emissao"] or n["criado_em"][:10]
    dados = {"descricao": descricao, "valor_centavos": n["valor_total_centavos"] or 0, "data": data,
             "competencia": n["competencia"] or data[:7], "categoria_id": n["categoria_id"],
             "grupo_id": n["grupo_id"], "forma_pagamento": n["forma_pagamento"]}
    if conta_id is not MANTER:
        dados["conta_id"] = conta_id
    existente = conn.execute("SELECT id FROM lancamentos WHERE nota_id = ?", (nota_id,)).fetchone()
    if existente:
        sets = ", ".join(f"{k} = ?" for k in dados)
        conn.execute(f"UPDATE lancamentos SET {sets}, atualizado_em = ? WHERE id = ?",
                     (*dados.values(), _agora(), existente["id"]))
        return existente["id"]
    if not criar:
        return None
    agora = _agora()
    dados |= {"tipo": "despesa", "situacao": "pago", "pago_em": data, "nota_id": nota_id,
              "criado_em": agora, "atualizado_em": agora}
    cur = conn.execute(f"INSERT INTO lancamentos ({', '.join(dados)}) VALUES ({', '.join('?' * len(dados))})",
                       tuple(dados.values()))
    return cur.lastrowid


# ============================================================================ consultas
def _filtros(de: str | None = None, ate: str | None = None, tipo: str | None = None,
             categoria_id: int | None = None, grupo_id: int | None = None, conta_id: int | None = None,
             situacao: str | None = None, busca: str | None = None) -> tuple[str, list]:
    condicoes, params = [VALE] if situacao != "cancelado" else ["l.situacao = 'cancelado'"], []
    for valor, sql in ((de, "l.competencia >= ?"), (ate, "l.competencia <= ?"), (tipo, "l.tipo = ?"),
                       (categoria_id, "l.categoria_id = ?"), (grupo_id, "l.grupo_id = ?"),
                       (conta_id, "l.conta_id = ?")):
        if valor is not None:
            condicoes.append(sql)
            params.append(valor)
    if situacao and situacao != "cancelado":
        condicoes.append("l.situacao = ?")
        params.append(situacao)
    if busca and chave_busca(busca):
        termo = f"%{chave_busca(busca)}%"
        digitos = re.sub(r"\D", "", busca)
        condicoes.append("(chave_busca(l.descricao) LIKE ? OR chave_busca(l.observacoes) LIKE ? "
                         "OR chave_busca(c.nome) LIKE ? OR chave_busca(g.nome) LIKE ? OR chave_busca(k.nome) LIKE ? "
                         "OR n.numero = ?" + (" OR n.cnpj LIKE ?" if len(digitos) >= 4 else "") + ")")
        params += [termo] * 5 + [busca.strip()] + ([f"%{digitos}%"] if len(digitos) >= 4 else [])
    return " AND ".join(condicoes), params


_COLUNAS = """l.*, c.nome AS categoria, g.nome AS grupo, k.nome AS conta, n.status AS nota_status,
              n.numero AS nota_numero, n.cnpj AS nota_cnpj, n.origem AS nota_origem,
              (n.arquivo_ref IS NOT NULL OR l.arquivo_ref IS NOT NULL) AS tem_arquivo"""


def _saida(r) -> dict:
    d = dict(r)
    d["tem_arquivo"] = bool(d["tem_arquivo"])
    d.pop("arquivo_ref", None)
    d.pop("arquivo_sha256", None)
    return d


def listar(conn, limite: int = 500, offset: int = 0, **filtros) -> dict:
    """Lançamentos filtrados (mais recentes primeiro) e os totais de TODOS os filtrados, não só da página."""
    where, params = _filtros(**filtros)
    linhas = conn.execute(f"SELECT {_COLUNAS} {DE_ONDE} WHERE {where} ORDER BY l.data DESC, l.id DESC LIMIT ? OFFSET ?",
                          (*params, limite, offset)).fetchall()
    tot = conn.execute(
        f"""SELECT COUNT(*) AS qtd,
                   COALESCE(SUM(CASE WHEN l.tipo = 'despesa' THEN l.valor_centavos END), 0) AS despesas,
                   COALESCE(SUM(CASE WHEN l.tipo = 'receita' THEN l.valor_centavos END), 0) AS receitas
            {DE_ONDE} WHERE {where}""", params).fetchone()
    return {
        "itens": [_saida(r) for r in linhas],
        "totais": {"qtd": tot["qtd"], "despesas_centavos": tot["despesas"], "receitas_centavos": tot["receitas"],
                   "saldo_centavos": tot["receitas"] - tot["despesas"]},
    }


def obter(conn, lancamento_id: int) -> dict:
    r = conn.execute(f"SELECT {_COLUNAS} {DE_ONDE} WHERE l.id = ?", (lancamento_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Lançamento #{lancamento_id} não encontrado.")
    return _saida(r)


def linha(conn, lancamento_id: int):
    r = conn.execute("SELECT * FROM lancamentos WHERE id = ?", (lancamento_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Lançamento #{lancamento_id} não encontrado.")
    return r


# ============================================================================ criar e editar
def _conferir(conn, campos: dict) -> None:
    """Confere os valores informados (só os presentes em `campos`)."""
    if "tipo" in campos and campos["tipo"] not in TIPOS:
        raise ArquivoInvalido("Tipo deve ser despesa ou receita.")
    if "descricao" in campos:
        campos["descricao"] = " ".join((campos["descricao"] or "").split())
        if not campos["descricao"]:
            raise ArquivoInvalido("Informe uma descrição.")
    if "valor_centavos" in campos:
        if campos["valor_centavos"] is None or campos["valor_centavos"] <= 0:
            raise ArquivoInvalido("Informe um valor maior que zero.")
    for chave in ("data", "vencimento", "pago_em"):
        if chave in campos:
            campos[chave] = _iso(campos[chave])
    if "data" in campos and not campos["data"]:
        raise ArquivoInvalido("Informe a data.")
    if campos.get("competencia") is not None and not RE_COMPETENCIA.fullmatch(campos["competencia"]):
        raise ArquivoInvalido("Mês deve estar no formato AAAA-MM.")
    if campos.get("forma_pagamento") is not None and campos["forma_pagamento"] not in FORMAS_PAGAMENTO:
        raise ArquivoInvalido("Forma de pagamento desconhecida.")
    if "observacoes" in campos:
        campos["observacoes"] = (campos["observacoes"] or "").strip() or None
    for chave, tabela, nome in (("categoria_id", "categorias", "Categoria"), ("grupo_id", "grupos", "Grupo"),
                                ("conta_id", "contas", "Conta")):
        if campos.get(chave) is not None and not conn.execute(
                f"SELECT 1 FROM {tabela} WHERE id = ?", (campos[chave],)).fetchone():
            raise NaoEncontrado(f"{nome} #{campos[chave]} não encontrada." if nome != "Grupo"
                                else f"Grupo #{campos[chave]} não encontrado.")


def _ajustar_situacao(final: dict, mudou: set) -> None:
    """Situação coerente com o tipo; quitado ganha data de pagamento; em aberto perde."""
    tipo = final["tipo"]
    if final["situacao"] not in SITUACOES_DO_TIPO[tipo]:
        if "situacao" in mudou:
            raise ArquivoInvalido(f"Situação '{final['situacao']}' não vale para {tipo}.")
        final["situacao"] = {"pago": "recebido", "recebido": "pago", "a_pagar": "a_receber",
                             "a_receber": "a_pagar"}.get(final["situacao"], final["situacao"])
    if final["situacao"] == QUITADO[tipo]:
        final["pago_em"] = final.get("pago_em") or final["data"]
    elif final["situacao"] != "cancelado":
        final["pago_em"] = None


def criar(conn, campos: dict) -> dict:
    """Lançamento sem nota: receita, ou despesa sem documento fiscal."""
    campos = {k: v for k, v in campos.items() if k in CAMPOS_DO_DOCUMENTO + CAMPOS_DO_LANCAMENTO}
    campos.setdefault("tipo", "despesa")
    for obrigatorio in ("descricao", "valor_centavos", "data"):
        campos.setdefault(obrigatorio, None)
    _conferir(conn, campos)
    campos["competencia"] = campos.get("competencia") or campos["data"][:7]
    campos.setdefault("situacao", QUITADO[campos["tipo"]])
    if campos["situacao"] not in SITUACOES:
        raise ArquivoInvalido("Situação desconhecida.")
    _ajustar_situacao(campos, {"situacao"} if "situacao" in campos else set())
    agora = _agora()
    campos |= {"criado_em": agora, "atualizado_em": agora}
    with conn:
        cur = conn.execute(f"INSERT INTO lancamentos ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                           tuple(campos.values()))
    return obter(conn, cur.lastrowid)


def atualizar(conn, lancamento_id: int, campos: dict) -> dict:
    atual = dict(linha(conn, lancamento_id))
    permitidos = CAMPOS_DO_LANCAMENTO if atual["nota_id"] else CAMPOS_DO_DOCUMENTO + CAMPOS_DO_LANCAMENTO
    proibidos = [k for k in campos if k in CAMPOS_DO_DOCUMENTO and k not in permitidos]
    if proibidos:
        raise Conflito("Este lançamento vem de uma nota fiscal: descrição, valor, data, mês, categoria, grupo e forma "
                       "de pagamento se corrigem na nota (reabra a nota para editar).")
    campos = {k: v for k, v in campos.items() if k in permitidos}
    if "situacao" in campos and campos["situacao"] not in SITUACOES:
        raise ArquivoInvalido("Situação desconhecida.")
    _conferir(conn, campos)
    final = atual | campos
    if "data" in campos and "competencia" not in campos and atual["competencia"] == (atual["data"] or "")[:7]:
        final["competencia"] = final["data"][:7]       # o mês acompanha a data, se ninguém o escolheu à parte
    _ajustar_situacao(final, set(campos))
    mudancas = {k: final[k] for k in permitidos + ("competencia",) if final.get(k) != atual.get(k)}
    if not atual["nota_id"]:
        mudancas = {k: v for k, v in mudancas.items() if k in permitidos or k == "competencia"}
    else:
        mudancas.pop("competencia", None)
    if mudancas:
        with conn:
            sets = ", ".join(f"{k} = ?" for k in mudancas)
            conn.execute(f"UPDATE lancamentos SET {sets}, atualizado_em = ? WHERE id = ?",
                         (*mudancas.values(), _agora(), lancamento_id))
    return obter(conn, lancamento_id)


def marcar_exportados(conn, competencia: str) -> None:
    """A planilha do mês foi 'lançada': registra quando, nos lançamentos que entraram nela."""
    conn.execute(f"""UPDATE lancamentos SET exportado_em = ?
                     WHERE exportado_em IS NULL AND competencia = ? AND tipo = 'despesa' AND id IN (
                         SELECT l.id {DE_ONDE} WHERE {VALE})""", (_agora(), competencia))


# ============================================================================ contas
_SQL_CONTAS = f"""
    SELECT k.*,
           k.saldo_inicial_centavos + COALESCE((
               SELECT SUM(CASE WHEN l.tipo = 'receita' THEN l.valor_centavos ELSE -l.valor_centavos END)
               FROM lancamentos l LEFT JOIN notas n ON n.id = l.nota_id
               WHERE l.conta_id = k.id AND {VALE} AND l.situacao IN ('pago', 'recebido')
                 AND (k.saldo_inicial_em IS NULL OR COALESCE(l.pago_em, l.data) >= k.saldo_inicial_em)), 0)
               AS saldo_centavos,
           (SELECT COUNT(*) FROM lancamentos l WHERE l.conta_id = k.id) AS qtd_lancamentos
    FROM contas k"""


def listar_contas(conn) -> list[dict]:
    """Saldo = saldo inicial + o que entrou (recebido) - o que saiu (pago) desde a data do saldo inicial."""
    return [dict(r) for r in conn.execute(_SQL_CONTAS + " ORDER BY k.ativa DESC, k.nome COLLATE NOCASE")]


def obter_conta(conn, conta_id: int) -> dict:
    r = conn.execute(_SQL_CONTAS + " WHERE k.id = ?", (conta_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Conta #{conta_id} não encontrada.")
    return dict(r)


def _conferir_conta(conn, campos: dict, ignorar_id: int | None = None) -> None:
    if "nome" in campos:
        campos["nome"] = " ".join((campos["nome"] or "").split())
        if not campos["nome"]:
            raise ArquivoInvalido("Informe o nome da conta.")
        for r in conn.execute("SELECT id, nome FROM contas"):
            if r["id"] != ignorar_id and chave_busca(r["nome"]) == chave_busca(campos["nome"]):
                raise Conflito(f"Já existe a conta '{r['nome']}'.")
    if "tipo" in campos and campos["tipo"] not in TIPOS_CONTA:
        raise ArquivoInvalido("Tipo de conta deve ser caixa, banco ou cartão.")
    if "saldo_inicial_em" in campos:
        campos["saldo_inicial_em"] = _iso(campos["saldo_inicial_em"])
    if "saldo_inicial_centavos" in campos and campos["saldo_inicial_centavos"] is None:
        campos["saldo_inicial_centavos"] = 0
    if "ativa" in campos:
        campos["ativa"] = 1 if campos["ativa"] else 0


def criar_conta(conn, campos: dict) -> dict:
    campos = {k: v for k, v in campos.items()
              if k in ("nome", "tipo", "saldo_inicial_centavos", "saldo_inicial_em")}
    campos.setdefault("nome", None)
    _conferir_conta(conn, campos)
    campos["criado_em"] = _agora()
    try:
        with conn:
            cur = conn.execute(f"INSERT INTO contas ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                               tuple(campos.values()))
    except sqlite3.IntegrityError as e:
        raise Conflito("Já existe uma conta com esse nome.") from e
    return obter_conta(conn, cur.lastrowid)


def atualizar_conta(conn, conta_id: int, campos: dict) -> dict:
    obter_conta(conn, conta_id)
    campos = {k: v for k, v in campos.items()
              if k in ("nome", "tipo", "saldo_inicial_centavos", "saldo_inicial_em", "ativa")}
    _conferir_conta(conn, campos, ignorar_id=conta_id)
    if campos:
        with conn:
            conn.execute(f"UPDATE contas SET {', '.join(f'{k} = ?' for k in campos)} WHERE id = ?",
                         (*campos.values(), conta_id))
    return obter_conta(conn, conta_id)


def excluir_conta(conn, conta_id: int) -> None:
    conta = obter_conta(conn, conta_id)
    if conta["qtd_lancamentos"]:
        raise Conflito(f"A conta '{conta['nome']}' tem {conta['qtd_lancamentos']} lançamento(s) e não pode ser "
                       "excluída. Desative a conta para ela sair das escolhas, sem perder o histórico.",
                       qtd_lancamentos=conta["qtd_lancamentos"])
    with conn:
        conn.execute("DELETE FROM contas WHERE id = ?", (conta_id,))
