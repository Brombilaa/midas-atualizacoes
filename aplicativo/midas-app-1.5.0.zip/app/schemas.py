"""Formato de entrada/saída da API. Na API o dinheiro é em reais (Decimal); internamente é em centavos."""
from __future__ import annotations

import json
from datetime import date
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from .dinheiro import centavos_para_decimal, para_centavos

Reais = Annotated[Decimal, Field(max_digits=12, decimal_places=2, ge=0)]
Competencia = Annotated[str, Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$", examples=["2026-10"])]


# ---------------------------------------------------------------- grupos / categorias
class GrupoIn(BaseModel):
    nome: str = Field(min_length=1, max_length=120)
    data_grupo: date | None = None
    orcamento: Reais | None = None


class GrupoPatch(BaseModel):
    nome: str | None = Field(default=None, min_length=1, max_length=120)
    data_grupo: date | None = None
    orcamento: Reais | None = None


class GrupoOut(BaseModel):
    id: int
    nome: str
    data_grupo: date | None
    orcamento: Decimal | None
    gasto: Decimal           # só notas validadas/lançadas
    qtd_notas: int


class CategoriaIn(BaseModel):
    nome: str = Field(min_length=1, max_length=80)


class CategoriaOut(BaseModel):
    id: int
    nome: str
    qtd_notas: int = 0


def grupo_out(d: dict) -> GrupoOut:
    return GrupoOut(id=d["id"], nome=d["nome"],
                     data_grupo=date.fromisoformat(d["data_grupo"]) if d["data_grupo"] else None,
                     orcamento=centavos_para_decimal(d["orcamento_centavos"]),
                     gasto=centavos_para_decimal(d["gasto_centavos"]), qtd_notas=d["qtd_notas"])


# ---------------------------------------------------------------- notas
class ItemIn(BaseModel):
    descricao: str = Field(min_length=1)
    quantidade: float | None = None
    valor_unitario: Reais | None = None
    valor_total: Reais | None = None


class ItemOut(BaseModel):
    descricao: str
    quantidade: float | None
    valor_unitario: Decimal | None
    valor_total: Decimal | None


class AvisoOut(BaseModel):
    campo: str
    nivel: str      # "erro" bloqueia a validação; "aviso" só pede atenção
    mensagem: str


class NotaPatch(BaseModel):
    """Só os campos enviados são alterados (enviar null limpa o campo)."""
    fornecedor: str | None = None
    cnpj: str | None = None
    numero: str | None = None
    serie: str | None = None
    data_emissao: date | None = None
    valor_total: Reais | None = None
    chave_acesso: str | None = None
    observacoes: str | None = None
    grupo_id: int | None = None
    categoria_id: int | None = None
    competencia: Competencia | None = None
    forma_pagamento: str | None = None
    itens: list[ItemIn] | None = None


class ValidarIn(BaseModel):
    grupo_id: int | None = None   # opcional: nota sem grupo
    categoria_id: int
    conta_id: int | None = Field(default=None, description="Conta de onde saiu o dinheiro; omitido = não mexe.")
    competencia: Competencia | None = Field(
        default=None, description="Mês de competência; se omitido, usa o mês da data de emissão.")


class NotaOut(BaseModel):
    id: int
    status: str
    origem: str
    fornecedor: str | None
    cnpj: str | None
    numero: str | None
    serie: str | None
    data_emissao: date | None
    valor_total: Decimal | None
    chave_acesso: str | None
    grupo_id: int | None
    categoria_id: int | None
    competencia: str | None
    confianca: dict[str, str]
    observacoes: str | None
    tipo_documento: str | None = None
    regioes: dict[str, list[float]] = {}
    forma_pagamento: str | None = None
    conta_id: int | None = None      # do lançamento da nota, quando já arquivada
    tem_arquivo: bool
    arquivo_nome: str | None
    arquivo_mime: str | None
    criado_em: str
    validado_em: str | None
    itens: list[ItemOut]
    avisos: list[AvisoOut]


def nota_out(d: dict) -> NotaOut:
    return NotaOut(
        id=d["id"], status=d["status"], origem=d["origem"], fornecedor=d["fornecedor"], cnpj=d["cnpj"],
        numero=d["numero"], serie=d["serie"],
        data_emissao=date.fromisoformat(d["data_emissao"]) if d["data_emissao"] else None,
        valor_total=centavos_para_decimal(d["valor_total_centavos"]), chave_acesso=d["chave_acesso"],
        grupo_id=d["grupo_id"], categoria_id=d["categoria_id"], competencia=d["competencia"],
        confianca=d["confianca"], observacoes=d["observacoes"], tipo_documento=d.get("tipo_documento"),
        regioes=json.loads(d["regioes"]) if d.get("regioes") else {}, tem_arquivo=d["arquivo_ref"] is not None,
        forma_pagamento=d.get("forma_pagamento"), conta_id=d.get("conta_id"),
        arquivo_nome=d["arquivo_nome"], arquivo_mime=d["arquivo_mime"], criado_em=d["criado_em"], validado_em=d["validado_em"],
        itens=[ItemOut(descricao=i["descricao"], quantidade=i["quantidade"],
                       valor_unitario=centavos_para_decimal(i["valor_unitario_centavos"]),
                       valor_total=centavos_para_decimal(i["valor_total_centavos"])) for i in d["itens"]],
        avisos=[AvisoOut(**a) for a in d["avisos"]],
    )


def itens_para_centavos(itens: list[ItemIn]) -> list[dict]:
    return [{"descricao": i.descricao, "quantidade": i.quantidade,
             "valor_unitario_centavos": para_centavos(i.valor_unitario),
             "valor_total_centavos": para_centavos(i.valor_total)} for i in itens]


# ---------------------------------------------------------------- lançamentos e contas
# Entrada em reais (como nas notas); a saída de lançamentos e contas vem em centavos, como na listagem.
SaldoReais = Annotated[Decimal, Field(max_digits=12, decimal_places=2)]   # pode ser negativo (cartão, cheque especial)


class LancamentoIn(BaseModel):
    tipo: Literal["despesa", "receita"] = "despesa"
    descricao: str = Field(min_length=1, max_length=200)
    valor: Reais
    data: date
    competencia: Competencia | None = None
    categoria_id: int | None = None
    grupo_id: int | None = None
    conta_id: int | None = None
    forma_pagamento: str | None = None
    situacao: str | None = None
    vencimento: date | None = None
    pago_em: date | None = None
    observacoes: str | None = Field(default=None, max_length=500)


class LancamentoPatch(BaseModel):
    """Só os campos enviados mudam. Em lançamento de nota, só conta, situação, datas e observações."""
    tipo: Literal["despesa", "receita"] | None = None
    descricao: str | None = Field(default=None, max_length=200)
    valor: Reais | None = None
    data: date | None = None
    competencia: Competencia | None = None
    categoria_id: int | None = None
    grupo_id: int | None = None
    conta_id: int | None = None
    forma_pagamento: str | None = None
    situacao: str | None = None
    vencimento: date | None = None
    pago_em: date | None = None
    observacoes: str | None = Field(default=None, max_length=500)


class ContaIn(BaseModel):
    nome: str = Field(min_length=1, max_length=80)
    tipo: Literal["caixa", "banco", "cartao"] = "banco"
    saldo_inicial: SaldoReais | None = None
    saldo_inicial_em: date | None = None


class ContaPatch(BaseModel):
    nome: str | None = Field(default=None, max_length=80)
    tipo: Literal["caixa", "banco", "cartao"] | None = None
    saldo_inicial: SaldoReais | None = None
    saldo_inicial_em: date | None = None
    ativa: bool | None = None


def para_banco(modelo: BaseModel) -> dict:
    """Só os campos enviados, com reais convertidos para centavos."""
    d = modelo.model_dump(exclude_unset=True)
    if "valor" in d:
        d["valor_centavos"] = para_centavos(d.pop("valor"))
    if "saldo_inicial" in d:
        d["saldo_inicial_centavos"] = para_centavos(d.pop("saldo_inicial")) if d["saldo_inicial"] is not None else 0
        d.pop("saldo_inicial", None)
    return d
