"""Regras de negócio. Nada aqui conhece HTTP: a API (main.py) só traduz entrada/saída."""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import time
import unicodedata
from datetime import date, datetime, timezone
from pathlib import Path

from . import lancamentos, validation
from .erros import ArquivoInvalido, Conflito, ErroNegocio, NaoEncontrado, ServicoIndisponivel  # noqa: F401
from .config import Config
from .excel_export import gerar_planilha_mensal
from .extractors.danfe import ler_danfe_digital, texto_do_pdf
from .extractors import ErroExtracao, Extracao, LeitorClaude, extrair_xml, normalizar_documento, ocr_local
from .extractors.base import FORMAS_PAGAMENTO
from .storage import Armazenamento, ArmazenamentoLocal, criar_armazenamento, slug

RE_COMPETENCIA = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
RE_CHAVE = re.compile(r"[0-9A-Z]{44}")
CAMPOS_EDITAVEIS = {"fornecedor", "cnpj", "numero", "serie", "data_emissao", "valor_total_centavos",
                    "chave_acesso", "observacoes", "grupo_id", "categoria_id", "competencia", "forma_pagamento"}
CAMPO_CONFIANCA = {"valor_total_centavos": "valor_total"}  # nome da coluna -> nome na tabela de confiança
CAMPOS_COM_CONFIANCA = {"fornecedor", "cnpj", "data_emissao", "valor_total", "itens", "chave_acesso"}


def agora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def detectar_tipo(conteudo: bytes) -> tuple[str, str, str]:
    """Devolve (tipo, mime, extensão) pelo conteúdo, não pelo nome (o nome vem do celular/usuário)."""
    if conteudo.startswith(b"%PDF"):
        return "pdf", "application/pdf", ".pdf"
    if conteudo.startswith(b"\xff\xd8\xff"):
        return "imagem", "image/jpeg", ".jpg"
    if conteudo.startswith(b"\x89PNG\r\n\x1a\n"):
        return "imagem", "image/png", ".png"
    if conteudo[:4] == b"RIFF" and conteudo[8:12] == b"WEBP":
        return "imagem", "image/webp", ".webp"
    if conteudo[4:8] == b"ftyp" and conteudo[8:12] in (b"heic", b"heix", b"mif1", b"hevc", b"msf1"):
        return "imagem", "image/heic", ".heic"
    inicio = conteudo.lstrip(b"\xef\xbb\xbf \t\r\n")[:64]
    if inicio.startswith((b"<?xml", b"<nfeProc", b"<NFe")):
        return "xml", "application/xml", ".xml"
    raise ArquivoInvalido("Formato não suportado. Envie XML da nota, PDF ou foto (JPG/PNG).")


def classificar_anexo(nome: str, conteudo: bytes) -> tuple[str, str, str]:
    """Para anexar SEM ler: formatos conhecidos são identificados pelo conteúdo; o resto vira anexo genérico.

    Um anexo genérico nunca herda o tipo do nome (um 'comprovante.html' não pode ser servido como página).
    """
    try:
        return detectar_tipo(conteudo)
    except ArquivoInvalido:
        extensao = Path(nome or "").suffix.lower()
        if not re.fullmatch(r"\.[a-z0-9]{1,8}", extensao):
            extensao = ".bin"
        return "outro", "application/octet-stream", extensao


def _registrar_leitura(tipo: str, conteudo: bytes, leitor: str, inicio: float, resultado: str) -> None:
    """Uma linha por leitura em dados/log.txt: é o que mostra onde está a demora num computador específico."""
    print(f"[leitura] {tipo} {len(conteudo) // 1024} KB · leitor {leitor} · {time.perf_counter() - inicio:.1f} s · "
          f"{resultado}", flush=True)


class Servico:
    def __init__(self, cfg: Config, leitor: LeitorClaude | None = None, leitor_local=None):
        self.cfg = cfg
        # Leitores de foto/PDF escaneado: Claude (com chave) e/ou OCR local (sem internet nem chave).
        self.leitor = None if cfg.leitor_foto == "local" else leitor
        if self.leitor is None and cfg.anthropic_api_key and cfg.leitor_foto != "local":
            self.leitor = LeitorClaude(api_key=cfg.anthropic_api_key, modelo=cfg.modelo_claude)
        self.leitor_local = None
        if cfg.leitor_foto != "claude":
            self.leitor_local = leitor_local or (ocr_local.LeitorLocal() if ocr_local.disponivel() else None)
        # Entrada (área de espera, sempre local) e destino final (configurável: local hoje, Drive depois).
        self.entrada = ArmazenamentoLocal(cfg.dados_dir / "entrada")
        antiga, nova = cfg.dados_dir / "eventos", cfg.dados_dir / "grupos"
        if antiga.is_dir() and not nova.exists():   # versão anterior guardava em dados/eventos; os caminhos gravados são relativos
            antiga.rename(nova)
        self.destino: Armazenamento = criar_armazenamento(cfg.armazenamento, nova)

    # ------------------------------------------------------------------ grupos e categorias
    def criar_grupo(self, conn, nome: str, data_grupo: date | None = None,
                     orcamento_centavos: int | None = None) -> dict:
        nome = (nome or "").strip()
        if not nome:
            raise ArquivoInvalido("Informe o nome do grupo.")
        self._conferir_nome_unico(conn, "grupos", nome)
        try:
            with conn:
                cur = conn.execute(
                    "INSERT INTO grupos (nome, data_grupo, orcamento_centavos, criado_em) VALUES (?,?,?,?)",
                    (nome, data_grupo.isoformat() if data_grupo else None, orcamento_centavos, agora()))
        except sqlite3.IntegrityError as e:
            raise Conflito(f"Já existe um grupo chamado '{nome}'.") from e
        return self.obter_grupo(conn, cur.lastrowid)

    def obter_grupo(self, conn, grupo_id: int) -> dict:
        linha = conn.execute(self._SQL_GRUPO + " WHERE e.id = ? GROUP BY e.id", (grupo_id,)).fetchone()
        if linha is None:
            raise NaoEncontrado(f"Grupo #{grupo_id} não encontrado.")
        return dict(linha)

    # gasto do grupo = despesas que contam (mesma regra da aba Lançamentos, do painel e da planilha)
    _SQL_GRUPO = f"""
        SELECT e.*, COALESCE(SUM(CASE WHEN l.tipo = 'despesa' THEN l.valor_centavos END), 0) AS gasto_centavos,
               COUNT(CASE WHEN l.tipo = 'despesa' THEN 1 END) AS qtd_notas
        FROM grupos e LEFT JOIN (SELECT l.* {lancamentos.DE_ONDE} WHERE {lancamentos.VALE}) l ON l.grupo_id = e.id"""

    def listar_grupos(self, conn) -> list[dict]:
        return [dict(r) for r in conn.execute(self._SQL_GRUPO + " GROUP BY e.id ORDER BY e.nome")]

    def atualizar_grupo(self, conn, grupo_id: int, campos: dict) -> dict:
        self.obter_grupo(conn, grupo_id)
        mapa = {"nome": "nome", "data_grupo": "data_grupo", "orcamento_centavos": "orcamento_centavos"}
        sets, params = [], []
        for chave, valor in campos.items():
            if chave not in mapa:
                continue
            if chave == "nome":
                valor = (valor or "").strip()
                if not valor:
                    raise ArquivoInvalido("O nome do grupo não pode ficar vazio.")
                self._conferir_nome_unico(conn, "grupos", valor, ignorar_id=grupo_id)
            if isinstance(valor, date):
                valor = valor.isoformat()
            sets.append(f"{mapa[chave]} = ?")
            params.append(valor)
        if sets:
            try:
                with conn:
                    conn.execute(f"UPDATE grupos SET {', '.join(sets)} WHERE id = ?", (*params, grupo_id))
            except sqlite3.IntegrityError as e:
                raise Conflito("Já existe um grupo com esse nome.") from e
        return self.obter_grupo(conn, grupo_id)

    @staticmethod
    def _chave_nome(nome: str) -> str:
        """Para detectar duplicatas: ignora maiúsculas, acentos e espaços repetidos ('Alimentação' = 'alimentacao')."""
        sem_acento = "".join(c for c in unicodedata.normalize("NFKD", nome) if not unicodedata.combining(c))
        return " ".join(sem_acento.casefold().split())

    def _conferir_nome_unico(self, conn, tabela: str, nome: str, ignorar_id: int | None = None) -> None:
        rotulo = "categoria" if tabela == "categorias" else "grupo"
        for r in conn.execute(f"SELECT id, nome FROM {tabela}"):
            if r["id"] != ignorar_id and self._chave_nome(r["nome"]) == self._chave_nome(nome):
                raise Conflito(f"Já existe {'uma' if rotulo == 'categoria' else 'um'} {rotulo} chamad{'a' if rotulo == 'categoria' else 'o'} '{r['nome']}'.")

    def criar_categoria(self, conn, nome: str) -> dict:
        nome = " ".join((nome or "").split())
        if not nome:
            raise ArquivoInvalido("Informe o nome da categoria.")
        self._conferir_nome_unico(conn, "categorias", nome)
        try:
            with conn:
                cur = conn.execute("INSERT INTO categorias (nome) VALUES (?)", (nome,))
        except sqlite3.IntegrityError as e:
            raise Conflito(f"Já existe a categoria '{nome}'.") from e
        return {"id": cur.lastrowid, "nome": nome, "qtd_notas": 0}

    def listar_categorias(self, conn) -> list[dict]:
        return [dict(r) for r in conn.execute(
            "SELECT c.id, c.nome, COUNT(n.id) AS qtd_notas FROM categorias c "
            "LEFT JOIN notas n ON n.categoria_id = c.id GROUP BY c.id ORDER BY c.nome COLLATE NOCASE")]

    def atualizar_categoria(self, conn, categoria_id: int, nome: str) -> dict:
        atual = conn.execute("SELECT id FROM categorias WHERE id = ?", (categoria_id,)).fetchone()
        if atual is None:
            raise NaoEncontrado(f"Categoria #{categoria_id} não encontrada.")
        nome = " ".join((nome or "").split())
        if not nome:
            raise ArquivoInvalido("O nome da categoria não pode ficar vazio.")
        self._conferir_nome_unico(conn, "categorias", nome, ignorar_id=categoria_id)
        with conn:
            conn.execute("UPDATE categorias SET nome = ? WHERE id = ?", (nome, categoria_id))
        return next(c for c in self.listar_categorias(conn) if c["id"] == categoria_id)

    def excluir_categoria(self, conn, categoria_id: int) -> None:
        cat = conn.execute("SELECT id, nome FROM categorias WHERE id = ?", (categoria_id,)).fetchone()
        if cat is None:
            raise NaoEncontrado(f"Categoria #{categoria_id} não encontrada.")
        usos = conn.execute("SELECT COUNT(*) FROM notas WHERE categoria_id = ?", (categoria_id,)).fetchone()[0]
        usos += conn.execute(  # lançamento sem nota (o de uma nota sempre acompanha a nota)
            "SELECT COUNT(*) FROM lancamentos WHERE categoria_id = ? AND nota_id IS NULL", (categoria_id,)).fetchone()[0]
        if usos:
            raise Conflito(f"A categoria '{cat['nome']}' está em uso por {usos} {'nota' if usos == 1 else 'notas'} e não pode ser excluída. "
                           "Troque a categoria dessas notas antes, ou renomeie esta categoria.", qtd_notas=usos)
        with conn:
            conn.execute("DELETE FROM categorias WHERE id = ?", (categoria_id,))

    # ------------------------------------------------------------------ upload e leitura
    def receber_upload(self, conn, nome_arquivo: str, conteudo: bytes, ler: bool = True) -> dict:
        """Com ler=True lê XML/PDF/foto; com ler=False só anexa (qualquer documento) e a pessoa preenche."""
        if not conteudo:
            raise ArquivoInvalido("Arquivo vazio.")
        tipo, mime, ext = detectar_tipo(conteudo) if ler else classificar_anexo(nome_arquivo, conteudo)
        sha = hashlib.sha256(conteudo).hexdigest()

        existente = conn.execute("SELECT id FROM notas WHERE arquivo_sha256 = ?", (sha,)).fetchone()
        if existente:
            raise Conflito(f"Este arquivo já foi enviado (nota #{existente['id']}).", nota_id=existente["id"])

        extracao = self._extrair(conteudo, tipo) if ler else Extracao(origem="manual")

        chave, obs = extracao.chave_acesso, extracao.observacoes
        if chave and not RE_CHAVE.fullmatch(chave):
            obs = " | ".join(filter(None, [obs, f"Chave lida fora do padrão e descartada: {chave}"]))
            chave = None
        if chave:
            existente = conn.execute("SELECT id FROM notas WHERE chave_acesso = ?", (chave,)).fetchone()
            if existente:
                raise Conflito(f"Esta nota já foi lançada (chave de acesso igual à nota #{existente['id']}).",
                               nota_id=existente["id"])

        ref = self.entrada.salvar(f"{sha[:16]}{ext}", conteudo)
        try:
            with conn:
                cur = conn.execute(
                    """INSERT INTO notas (origem, fornecedor, cnpj, numero, serie, data_emissao,
                           valor_total_centavos, chave_acesso, confianca, observacoes, arquivo_nome,
                           arquivo_mime, arquivo_sha256, arquivo_ref, arquivo_local, criado_em, tipo_documento, regioes,
                           forma_pagamento)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'entrada', ?, ?, ?, ?)""",
                    (extracao.origem, extracao.fornecedor, extracao.cnpj, extracao.numero, extracao.serie,
                     extracao.data_emissao.isoformat() if extracao.data_emissao else None,
                     extracao.valor_total_centavos, chave, json.dumps(extracao.confianca), obs,
                     Path(nome_arquivo or f"nota{ext}").name, mime, sha, ref, agora(), extracao.tipo_documento,
                     json.dumps(extracao.regioes) if extracao.regioes else None, extracao.forma_pagamento))
                self._gravar_itens(conn, cur.lastrowid, [i.model_dump() for i in extracao.itens])
        except Exception:
            self.entrada.remover(ref)
            raise
        return self.detalhar_nota(conn, cur.lastrowid)

    def criar_nota_manual(self, conn, campos: dict, itens: list[dict] | None = None) -> dict:
        """Lançamento sem arquivo: a pessoa informa os dados (e pode anexar um comprovante depois)."""
        with conn:
            cur = conn.execute("INSERT INTO notas (origem, criado_em) VALUES ('manual', ?)", (agora(),))
        nota_id = cur.lastrowid
        if campos or itens:
            try:
                return self.atualizar_nota(conn, nota_id, campos, itens)
            except ErroNegocio:
                with conn:
                    conn.execute("DELETE FROM notas WHERE id = ?", (nota_id,))
                raise
        return self.detalhar_nota(conn, nota_id)

    def anexar_arquivo(self, conn, nota_id: int, nome_arquivo: str, conteudo: bytes) -> dict:
        """Anexa um comprovante a uma nota ainda aberta e sem arquivo (não lê o conteúdo)."""
        nota = self._linha(conn, nota_id)
        if nota["status"] != "lido":
            raise Conflito("Reabra a nota para anexar um arquivo.")
        if nota["arquivo_ref"]:
            raise Conflito("Esta nota já tem um arquivo anexado.")
        if not conteudo:
            raise ArquivoInvalido("Arquivo vazio.")
        _, mime, ext = classificar_anexo(nome_arquivo, conteudo)
        sha = hashlib.sha256(conteudo).hexdigest()
        existente = conn.execute("SELECT id FROM notas WHERE arquivo_sha256 = ?", (sha,)).fetchone()
        if existente:
            raise Conflito(f"Este arquivo já está anexado à nota #{existente['id']}.", nota_id=existente["id"])

        ref = self.entrada.salvar(f"{sha[:16]}{ext}", conteudo)
        try:
            with conn:
                conn.execute(
                    """UPDATE notas SET arquivo_nome = ?, arquivo_mime = ?, arquivo_sha256 = ?, arquivo_ref = ?,
                           arquivo_local = 'entrada' WHERE id = ?""",
                    (Path(nome_arquivo or f"anexo{ext}").name, mime, sha, ref, nota_id))
        except Exception:
            self.entrada.remover(ref)
            raise
        return self.detalhar_nota(conn, nota_id)

    def leitores_de_foto(self) -> list:
        """Em ordem de preferência: Claude (mais preciso) e, se faltar ou falhar, o OCR local."""
        return [l for l in (self.leitor, self.leitor_local) if l is not None]

    def nome_do_leitor(self) -> str | None:
        return "claude" if self.leitor is not None else "local" if self.leitor_local is not None else None

    def _extrair(self, conteudo: bytes, tipo: str) -> Extracao:
        try:
            if tipo == "xml":
                return extrair_xml(conteudo)
            digital = ler_danfe_digital(texto_do_pdf(conteudo)) if tipo == "pdf" else None
            leitores = self.leitores_de_foto()
            if digital is not None and self.leitor is None:  # texto do PDF é exato: vale mais que OCR
                return digital
            if not leitores:
                raise ServicoIndisponivel(
                    "Este computador está sem o leitor de fotos (OCR) e sem a chave da API do Claude. "
                    "Envie o XML da nota ou preencha os dados à mão.")
            falha: Exception | None = None
            for leitor in leitores:
                nome = "claude" if leitor is self.leitor else "local"
                inicio = time.perf_counter()
                try:
                    ext = leitor.extrair(conteudo, tipo)
                    _registrar_leitura(tipo, conteudo, nome, inicio, "ok")
                    return ext
                except ErroExtracao as e:
                    _registrar_leitura(tipo, conteudo, nome, inicio, "não entendeu")
                    falha = falha or e
                except Exception as e:  # Claude fora do ar, sem internet etc.: tenta o próximo leitor
                    _registrar_leitura(tipo, conteudo, nome, inicio, f"falhou ({type(e).__name__})")
                    falha = falha or e
            if digital is not None:
                return digital
            raise falha
        except ErroExtracao as e:
            raise ArquivoInvalido(str(e)) from e

    @staticmethod
    def _gravar_itens(conn, nota_id: int, itens: list[dict]) -> None:
        conn.execute("DELETE FROM itens WHERE nota_id = ?", (nota_id,))
        conn.executemany(
            "INSERT INTO itens (nota_id, descricao, quantidade, valor_unitario_centavos, valor_total_centavos)"
            " VALUES (?,?,?,?,?)",
            [(nota_id, i["descricao"], i.get("quantidade"), i.get("valor_unitario_centavos"),
              i.get("valor_total_centavos")) for i in itens])

    # ------------------------------------------------------------------ consulta
    def _linha(self, conn, nota_id: int) -> dict:
        linha = conn.execute("SELECT * FROM notas WHERE id = ?", (nota_id,)).fetchone()
        if linha is None:
            raise NaoEncontrado(f"Nota #{nota_id} não encontrada.")
        return dict(linha)

    def _itens(self, conn, nota_id: int) -> list[dict]:
        return [dict(r) for r in conn.execute("SELECT * FROM itens WHERE nota_id = ? ORDER BY id", (nota_id,))]

    @classmethod
    def _nome_forn(cls, nome: str) -> str:
        return " ".join(re.sub(r"[^\w\s]", " ", cls._chave_nome(nome)).split())

    def _duplicatas(self, conn, nota: dict) -> list[int]:
        """Heurística para quando falta a chave: mesmo fornecedor (CNPJ ou nome), data e valor.

        Se as duas notas têm chave de acesso (e a chave é única no banco), são documentos distintos
        e não há o que suspeitar.
        """
        if not (nota["data_emissao"] and nota["valor_total_centavos"]):
            return []
        if not (nota["cnpj"] or nota["fornecedor"]):
            return []
        # CNPJ igual OU nome igual (sem acento/pontuação): foto de um pedido x DANFE da mesma compra
        # podem trazer o nome um pouco diferente, mas o CNPJ costuma coincidir.
        nome = self._nome_forn(nota["fornecedor"]) if nota["fornecedor"] else None
        candidatas = conn.execute(
            """SELECT id, cnpj, fornecedor FROM notas WHERE id != ? AND data_emissao = ?
               AND valor_total_centavos = ? AND (chave_acesso IS NULL OR ? IS NULL)""",
            (nota["id"], nota["data_emissao"], nota["valor_total_centavos"], nota["chave_acesso"])).fetchall()
        linhas = [r for r in candidatas
                  if (nota["cnpj"] and r["cnpj"] == nota["cnpj"])
                  or (nome and r["fornecedor"] and self._nome_forn(r["fornecedor"]) == nome)]
        return [r["id"] for r in linhas]

    def _avisos(self, conn, nota: dict, itens: list[dict]) -> list[validation.Aviso]:
        return validation.validar(nota, itens, json.loads(nota["confianca"] or "{}"), self._duplicatas(conn, nota))

    def detalhar_nota(self, conn, nota_id: int) -> dict:
        nota = self._linha(conn, nota_id)
        itens = self._itens(conn, nota_id)
        nota["confianca"] = json.loads(nota["confianca"] or "{}")
        nota["itens"] = itens
        nota["avisos"] = [a.__dict__ for a in self._avisos(conn, {**nota, "confianca": json.dumps(nota["confianca"])},
                                                           itens)]
        lanc = conn.execute("SELECT conta_id FROM lancamentos WHERE nota_id = ?", (nota_id,)).fetchone()
        nota["conta_id"] = lanc["conta_id"] if lanc else None
        return nota

    def listar_notas(self, conn, status: str | None = None, grupo_id: int | None = None,
                     competencia: str | None = None, limite: int = 200, offset: int = 0) -> list[dict]:
        """`status` aceita lido, validado, lancado ou 'concluidas' (validado + lancado).

        Notas ainda 'lido' (a fila de conferência) já vêm com itens e avisos; as demais vêm sem.
        """
        filtros, params = [], []
        if status == "concluidas":
            filtros.append("status IN ('validado', 'lancado')")
        elif status is not None:
            filtros.append("status = ?")
            params.append(status)
        for coluna, valor in (("grupo_id", grupo_id), ("competencia", competencia)):
            if valor is not None:
                filtros.append(f"{coluna} = ?")
                params.append(valor)
        where = f"WHERE {' AND '.join(filtros)}" if filtros else ""
        linhas = conn.execute(f"SELECT * FROM notas {where} ORDER BY data_emissao DESC, id DESC LIMIT ? OFFSET ?",
                              (*params, limite, offset)).fetchall()
        resultado = []
        for r in linhas:
            if r["status"] == "lido":
                resultado.append(self.detalhar_nota(conn, r["id"]))
                continue
            n = dict(r)
            n["confianca"] = json.loads(n["confianca"] or "{}")
            n["itens"], n["avisos"] = [], []
            resultado.append(n)
        return resultado

    def arquivo_da_nota(self, conn, nota_id: int) -> tuple[bytes, str, str]:
        nota = self._linha(conn, nota_id)
        return self._ler_arquivo(nota), nota["arquivo_nome"], nota["arquivo_mime"]

    def _loja(self, nota: dict) -> Armazenamento:
        return self.entrada if nota["arquivo_local"] == "entrada" else self.destino

    def _ler_arquivo(self, nota: dict) -> bytes:
        if not nota["arquivo_ref"]:
            raise NaoEncontrado("Esta nota não tem arquivo anexado.")
        try:
            return self._loja(nota).ler(nota["arquivo_ref"])
        except FileNotFoundError as e:
            raise NaoEncontrado("O arquivo original desta nota não foi encontrado no armazenamento.") from e

    # ------------------------------------------------------------------ anexo de lançamento sem nota
    def anexar_ao_lancamento(self, conn, lancamento_id: int, nome_arquivo: str, conteudo: bytes) -> dict:
        """Comprovante de um lançamento sem nota (recibo, extrato, contrato...). Substitui o anterior, se houver."""
        lanc = lancamentos.linha(conn, lancamento_id)
        if lanc["nota_id"]:
            raise Conflito("Este lançamento vem de uma nota: o arquivo é o da nota.")
        if not conteudo:
            raise ArquivoInvalido("Arquivo vazio.")
        _, mime, ext = classificar_anexo(nome_arquivo, conteudo)
        valor = f"{lanc['valor_centavos'] / 100:.2f}".replace(".", "-")
        caminho = (f"lancamentos/{lanc['competencia']}/"
                   f"{lanc['data']}_{slug(lanc['descricao'])}_{valor}_l{lancamento_id}{ext}")
        ref = self.destino.salvar(caminho, conteudo)
        try:
            with conn:
                conn.execute("""UPDATE lancamentos SET arquivo_nome = ?, arquivo_mime = ?, arquivo_sha256 = ?,
                                arquivo_ref = ? WHERE id = ?""",
                             (Path(nome_arquivo or f"anexo{ext}").name, mime, hashlib.sha256(conteudo).hexdigest(),
                              ref, lancamento_id))
        except Exception:
            self.destino.remover(ref)
            raise
        if lanc["arquivo_ref"] and lanc["arquivo_ref"] != ref:
            try:
                self.destino.remover(lanc["arquivo_ref"])
            except OSError:
                pass
        return lancamentos.obter(conn, lancamento_id)

    def arquivo_do_lancamento(self, conn, lancamento_id: int) -> tuple[bytes, str, str]:
        lanc = lancamentos.linha(conn, lancamento_id)
        if lanc["nota_id"]:
            return self.arquivo_da_nota(conn, lanc["nota_id"])
        if not lanc["arquivo_ref"]:
            raise NaoEncontrado("Este lançamento não tem arquivo anexado.")
        try:
            return self.destino.ler(lanc["arquivo_ref"]), lanc["arquivo_nome"], lanc["arquivo_mime"]
        except FileNotFoundError as e:
            raise NaoEncontrado("O arquivo deste lançamento não foi encontrado no armazenamento.") from e

    # ------------------------------------------------------------------ conferência (edição)
    def atualizar_nota(self, conn, nota_id: int, campos: dict, itens: list[dict] | None = None) -> dict:
        nota = self._linha(conn, nota_id)
        if nota["status"] != "lido":
            raise Conflito("Só é possível editar notas ainda não validadas. Reabra a nota primeiro.")

        sets, params, editados = [], [], []
        for coluna, valor in campos.items():
            if coluna not in CAMPOS_EDITAVEIS:
                continue
            if coluna in ("cnpj", "chave_acesso"):
                valor = normalizar_documento(valor)
            elif coluna in ("fornecedor", "numero", "serie", "observacoes"):
                valor = (valor or "").strip() or None
            elif coluna == "data_emissao" and isinstance(valor, date):
                valor = valor.isoformat()
            if coluna == "chave_acesso" and valor and not RE_CHAVE.fullmatch(valor):
                raise ArquivoInvalido("A chave de acesso deve ter 44 caracteres (letras e números).")
            if coluna == "valor_total_centavos" and valor is not None and valor < 0:
                raise ArquivoInvalido("O valor total não pode ser negativo.")
            if coluna == "forma_pagamento" and valor is not None and valor not in FORMAS_PAGAMENTO:
                raise ArquivoInvalido("Forma de pagamento desconhecida.")
            if coluna == "competencia" and valor is not None and not RE_COMPETENCIA.fullmatch(valor):
                raise ArquivoInvalido("Competência deve estar no formato AAAA-MM.")
            if coluna == "grupo_id" and valor is not None:
                self.obter_grupo(conn, valor)
            if coluna == "categoria_id" and valor is not None and not conn.execute(
                    "SELECT 1 FROM categorias WHERE id = ?", (valor,)).fetchone():
                raise NaoEncontrado(f"Categoria #{valor} não encontrada.")
            sets.append(f"{coluna} = ?")
            params.append(valor)
            editados.append(CAMPO_CONFIANCA.get(coluna, coluna))
        if itens is not None:
            editados.append("itens")

        confianca = json.loads(nota["confianca"] or "{}")
        for campo in editados:  # o que uma pessoa digitou/conferiu passa a valer como leitura confiável
            if campo in CAMPOS_COM_CONFIANCA:
                confianca[campo] = "alta"
        sets.append("confianca = ?")
        params.append(json.dumps(confianca))

        try:
            with conn:
                conn.execute(f"UPDATE notas SET {', '.join(sets)} WHERE id = ?", (*params, nota_id))
                if itens is not None:
                    self._gravar_itens(conn, nota_id, itens)
                lancamentos.sincronizar_nota(conn, nota_id, criar=False)
        except sqlite3.IntegrityError as e:
            raise Conflito("Já existe outra nota com essa chave de acesso.") from e
        return self.detalhar_nota(conn, nota_id)

    # ------------------------------------------------------------------ validação final
    def validar_nota(self, conn, nota_id: int, grupo_id: int | None, categoria_id: int,
                     competencia: str | None = None, conta_id: int | None | object = lancamentos.MANTER) -> dict:
        nota = self._linha(conn, nota_id)
        if nota["status"] != "lido":
            raise Conflito(f"A nota #{nota_id} já está {nota['status']}.")
        grupo = self.obter_grupo(conn, grupo_id) if grupo_id else None   # o grupo é opcional
        categoria = conn.execute("SELECT * FROM categorias WHERE id = ?", (categoria_id,)).fetchone()
        if categoria is None:
            raise NaoEncontrado(f"Categoria #{categoria_id} não encontrada.")
        if conta_id not in (None, lancamentos.MANTER):
            lancamentos.obter_conta(conn, conta_id)

        itens = self._itens(conn, nota_id)
        erros = [a for a in self._avisos(conn, nota, itens) if a.nivel == "erro"]
        if erros:
            raise ArquivoInvalido("Corrija os erros antes de validar: " + " ".join(a.mensagem for a in erros),
                                  avisos=[a.__dict__ for a in erros])

        competencia = competencia or nota["competencia"] or nota["data_emissao"][:7]
        if not RE_COMPETENCIA.fullmatch(competencia):
            raise ArquivoInvalido("Competência deve estar no formato AAAA-MM.")

        sets = "status = 'validado', grupo_id = ?, categoria_id = ?, competencia = ?, validado_em = ?"
        params: list = [grupo_id or None, categoria_id, competencia, agora()]
        antigo = novo_ref = None
        if nota["arquivo_ref"]:  # lançamento manual sem arquivo não tem o que mover
            conteudo = self._ler_arquivo(nota)
            pasta = self.cfg.estrutura_pastas.format_map(
                {"grupo": slug(grupo["nome"]) if grupo else "sem-grupo", "competencia": competencia, "categoria": slug(categoria["nome"])})
            valor = f"{nota['valor_total_centavos'] / 100:.2f}".replace(".", "-")
            nome = (f"{nota['data_emissao']}_{slug(nota['fornecedor'])}_{valor}_n{nota_id}"
                    f"{Path(nota['arquivo_ref']).suffix}")
            novo_ref = self.destino.salvar(f"{pasta}/{nome}", conteudo)
            antigo = (nota["arquivo_local"], nota["arquivo_ref"])
            sets += ", arquivo_ref = ?, arquivo_local = 'destino'"
            params.append(novo_ref)
        with conn:
            conn.execute(f"UPDATE notas SET {sets} WHERE id = ?", (*params, nota_id))
            lancamentos.sincronizar_nota(conn, nota_id, conta_id=conta_id)
        if antigo and antigo != ("destino", novo_ref):  # nunca apaga o arquivo que acabou de ser gravado
            try:
                self._loja(nota).remover(antigo[1])
            except OSError:
                pass  # sobra de arquivo na área de espera não afeta o lançamento
        return self.detalhar_nota(conn, nota_id)

    def reabrir_nota(self, conn, nota_id: int) -> dict:
        nota = self._linha(conn, nota_id)
        if nota["status"] == "lido":
            raise Conflito(f"A nota #{nota_id} já está aberta para edição.")
        with conn:
            conn.execute("UPDATE notas SET status = 'lido', validado_em = NULL WHERE id = ?", (nota_id,))
        return self.detalhar_nota(conn, nota_id)

    def excluir_nota(self, conn, nota_id: int) -> None:
        nota = self._linha(conn, nota_id)
        if nota["status"] != "lido":
            raise Conflito("Só notas ainda não validadas podem ser excluídas. Reabra a nota primeiro.")
        with conn:
            conn.execute("DELETE FROM notas WHERE id = ?", (nota_id,))
        if nota["arquivo_ref"]:
            try:
                self._loja(nota).remover(nota["arquivo_ref"])
            except OSError:
                pass

    # ------------------------------------------------------------------ resumo do mês (painel)
    def resumo_mes(self, conn, competencia: str) -> dict:
        """Números do mês para o painel, das despesas que contam (os mesmos da aba Lançamentos). Centavos."""
        if not RE_COMPETENCIA.fullmatch(competencia):
            raise ArquivoInvalido("Competência deve estar no formato AAAA-MM.")
        base = f"{lancamentos.DE_ONDE} WHERE {lancamentos.VALE} AND l.tipo = 'despesa' AND l.competencia = ?"
        tot = conn.execute(
            f"""SELECT COALESCE(SUM(l.valor_centavos), 0) AS total, COUNT(*) AS qtd,
                       COUNT(CASE WHEN n.status = 'lancado' OR l.exportado_em IS NOT NULL THEN 1 END) AS lancadas
                {base}""", (competencia,)).fetchone()
        por_categoria = [dict(r) for r in conn.execute(
            f"""SELECT COALESCE(c.nome, '(sem categoria)') AS nome, SUM(l.valor_centavos) AS total_centavos,
                       COUNT(*) AS qtd {base} GROUP BY l.categoria_id ORDER BY total_centavos DESC, nome""",
            (competencia,))]
        acumulado = {g["id"]: g for g in self.listar_grupos(conn)}
        por_grupo = []
        for r in conn.execute(
                f"""SELECT g.id, g.nome, SUM(l.valor_centavos) AS total_centavos, COUNT(*) AS qtd
                    {base} GROUP BY l.grupo_id ORDER BY g.id IS NULL, total_centavos DESC""", (competencia,)):
            g = acumulado.get(r["id"])
            por_grupo.append({**dict(r), "nome": r["nome"] or "Sem grupo",
                              "orcamento_centavos": g["orcamento_centavos"] if g else None,
                              "acumulado_centavos": g["gasto_centavos"] if g else None})
        ultimas = [dict(r) for r in conn.execute(
            f"""SELECT l.nota_id AS id, l.id AS lancamento_id, l.descricao AS fornecedor, l.data AS data_emissao,
                       l.valor_centavos AS valor_total_centavos, n.tipo_documento, n.status,
                       c.nome AS categoria, g.nome AS grupo {base}
                ORDER BY l.atualizado_em DESC, l.id DESC LIMIT 5""", (competencia,))]
        ano, mes = map(int, competencia.split("-"))
        anterior = f"{ano - (mes == 1):04d}-{12 if mes == 1 else mes - 1:02d}"
        total_anterior = conn.execute(f"SELECT COALESCE(SUM(l.valor_centavos), 0) {base}", (anterior,)).fetchone()[0]
        return {"competencia": competencia, "total_centavos": tot["total"], "qtd": tot["qtd"],
                "qtd_lancadas": tot["lancadas"], "qtd_a_lancar": tot["qtd"] - tot["lancadas"],
                "por_categoria": por_categoria, "por_grupo": por_grupo, "ultimas": ultimas,
                "mes_anterior": anterior, "total_mes_anterior_centavos": total_anterior}

    # ------------------------------------------------------------------ planilha mensal
    def exportar_mes(self, conn, competencia: str, marcar_lancado: bool = True) -> bytes:
        if not RE_COMPETENCIA.fullmatch(competencia):
            raise ArquivoInvalido("Competência deve estar no formato AAAA-MM.")
        linhas = conn.execute(
            f"""SELECT l.*, g.nome AS grupo_nome, c.nome AS categoria_nome, n.cnpj, n.numero, n.chave_acesso,
                       n.arquivo_ref
                {lancamentos.DE_ONDE}
                WHERE {lancamentos.VALE} AND l.tipo = 'despesa' AND l.competencia = ?""", (competencia,)).fetchall()

        do_mes = [{
            "data": date.fromisoformat(l["data"]), "grupo": l["grupo_nome"], "categoria": l["categoria_nome"],
            "fornecedor": l["descricao"], "cnpj": l["cnpj"], "numero": l["numero"],
            "valor_centavos": l["valor_centavos"], "chave": l["chave_acesso"],
            "arquivo": l["arquivo_ref"] or "(sem arquivo)", "nota_id": l["nota_id"],
        } for l in linhas]

        grupos = {}
        for e in self.listar_grupos(conn):
            grupos[e["nome"]] = {"orcamento_centavos": e["orcamento_centavos"], "acumulado_centavos": e["gasto_centavos"]}

        conteudo = gerar_planilha_mensal(competencia, do_mes, grupos)
        if marcar_lancado:
            with conn:
                lancamentos.marcar_exportados(conn, competencia)
                conn.execute("UPDATE notas SET status = 'lancado' WHERE competencia = ? AND status = 'validado'",
                             (competencia,))
        return conteudo
