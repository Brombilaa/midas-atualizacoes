"""Interpreta o texto de uma foto de cupom/pedido/DANFE lido por OCR e devolve uma `Extracao`.

Função pura (sem OCR, sem rede): recebe as linhas de texto com posição e aplica regras. Foi escrita para o que
o OCR erra de verdade: letras no lugar de zeros ('C0O', 'PIP0CA'), valores colados ('24,9974,97'), valores e rótulos
em linhas diferentes por causa do papel torto. O que não dá para confirmar sai com confiança baixa ou fica vazio:
quem decide é a pessoa, olhando o documento ao lado.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, timedelta

from ..dinheiro import para_centavos
from ..validation import TOLERANCIA_SOMA_CENTAVOS, cnpj_valido
from .base import ErroExtracao, Extracao, ItemExtraido
from .danfe import achar_chave_no_texto, reconciliar


@dataclass
class Linha:
    texto: str
    y: float = 0.0
    x: float = 0.0
    score: float = 1.0
    caixa: tuple[float, float, float, float] | None = None  # x0, y0, x1, y1 em fração da imagem (0 a 1)


_DIG = "0-9OIl"  # o OCR troca estes por dígitos com frequência
_RE_CNPJ = re.compile(rf"(?<![0-9A-Za-z])([{_DIG}]{{2}})[.\s]?([{_DIG}]{{3}})[.\s]?([{_DIG}]{{3}})\s?/\s?([{_DIG}]{{4}})\s?[-.]?\s?([{_DIG}]{{2}})(?![0-9])")
_RE_CNPJ_SEM_PONTUACAO = re.compile(r"(?<![0-9])(\d{14})(?![0-9])")
_RE_DATA = re.compile(rf"(?<![0-9])([{_DIG}]{{2}})\s?[/.\-]\s?([{_DIG}]{{2}})\s?[/.\-]\s?(20[{_DIG}]{{2}})")
_RE_DINHEIRO = re.compile(r"\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2}")
_UNIDADES = r"(?:UN|UNID|UND|UNI|PC|PCT|CX|KG|LT|L|MT|M|FD|DZ|PAR|SC|GR|G|ML|BD|FR)"
_RE_LINHA_NUMERICA = re.compile(rf"^\s*([0-9OIl]+(?:[.,][0-9]+)?)\s*(?:X\s*)?({_UNIDADES})(?![A-Za-z])", re.I)
_RE_PONTO_DECIMAL = re.compile(r"(\d)\.(\d{2})(?![\d.,])")
_RE_CODIGO_DESCRICAO = re.compile(r"^\s*(?:\d{1,4}\s+)?(\d{6,14})\s*(.+)$")

_TIPOS = (
    ("pedido_ou_comprovante", re.compile(
        r"PEDIDO\s*DE\s*(NF|NOTA|VENDA|COMPRA)|OR[CÇ]AMENTO|COMPROVANTE|RECIBO|SEM\s*VALOR\s*FISCAL|"
        r"N[AÃ]O\s*[EÉ]\s*DOCUMENTO\s*FISCAL|VIA\s*(DO\s*)?CLIENTE")),
    ("nfce_cupom", re.compile(r"NFC-?E|CUPOM\s*FISCAL|NOTA\s*FISCAL\s*DE\s*CONSUMIDOR")),
    ("nfse_servico", re.compile(r"NFS-?E|NOTA\s*FISCAL\s*DE\s*SERVI[CÇ]OS?")),
    ("nfe_danfe", re.compile(r"DANFE|NOTA\s*FISCAL\s*ELETR[OÔ]NICA|\bNF-?E\b")),
)
_RE_ROTULO_TOTAL = re.compile(
    r"[VU]ALOR\s*TOTAL|TOTAL\s*(A\s*PAGAR|R[$S]|GERAL|DA\s*NOTA|DO\s*PEDIDO|DO\s*CUPOM)|^\s*TOTAL\b|[VU]ALOR\s*A\s*PAGAR|[VU]ALOR\s*PAGO")
_RE_NAO_TOTAL = re.compile(r"QUANT|ITENS|PRODUTOS|DESCONT|TROCO|TRIBUT|ICMS|PIS\b|COFINS|BASE|IMPOSTO|IBPT|APROX|FRETE|SEGURO")
_RE_COMPRADOR = re.compile(r"DESTINAT|CLIENTE|CONSUMIDOR|TOMADOR|COMPRADOR")
_RE_NAO_NOME = re.compile(
    r"CUPOM|NFC|DANFE|DOCUMENTO|CNPJ|CPF|\bIE\b|INSCR|RECEBEMOS|EMISS|DATA|COO\b|N[UÚ]MERO|PEDIDO|S[EÉ]RIE|"
    r"FISCAL|ELETR|CHAVE|PROTOCOLO|VIA\b|RUA|AV\b|AV\.|AVENIDA|ENDERE|PORTO ALEGRE|CEP")
_RE_PAGAMENTO = re.compile(
    r"(TEF\s*(?:CR[EÉ]DITO|D[EÉ]BITO)|CART[AÃ]O\s*(?:DE\s*)?(?:CR[EÉ]DITO|D[EÉ]BITO)|\bPIX\b|DINHEIRO|BOLETO|CHEQUE|TRANSFER[EÊ]NCIA)")

# Confusões típicas de OCR em dígitos, usadas só para tentar consertar um CNPJ com dígito verificador inválido.
_CONFUSOES = {"0": "86", "8": "036", "3": "8", "1": "7", "7": "1", "5": "6", "6": "58", "9": "84", "4": "9", "2": "7"}


def _so_digitos(texto: str) -> str:
    return texto.translate(str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1"}))


def _letras_certas(texto: str) -> str:
    """'PIP0CA D0CE' -> 'PIPOCA DOCE': zero entre letras é a letra O."""
    return re.sub(r"(?<=[A-Za-zÀ-ú])0(?=[A-Za-zÀ-ú])|(?<=[A-Za-zÀ-ú])0\b", "O", texto)


def _dinheiro(texto: str) -> list[int]:
    return [c for c in (para_centavos(m.group()) for m in _RE_DINHEIRO.finditer(texto)) if c is not None]


def _consertar_cnpj(cnpj: str) -> str | None:
    """Troca um dígito por vez pelas confusões do OCR; só vale se exatamente uma troca fecha o dígito verificador."""
    achados = {cnpj[:i] + novo + cnpj[i + 1:] for i, d in enumerate(cnpj) for novo in _CONFUSOES.get(d, "")
               if cnpj_valido(cnpj[:i] + novo + cnpj[i + 1:])}
    return achados.pop() if len(achados) == 1 else None


def _detectar_tipo(plano: str, chave: str | None) -> str | None:
    for nome, rx in _TIPOS:
        if rx.search(plano):
            return nome
    if chave:
        return "nfce_cupom" if chave[20:22] == "65" else "nfe_danfe"
    return None


def interpretar(linhas: list[Linha], hoje: date | None = None) -> Extracao:
    """Devolve a melhor leitura possível; campos que não deu para ler ficam None."""
    hoje = hoje or date.today()
    linhas = sorted((l for l in linhas if l.texto and l.texto.strip()), key=lambda l: (l.y, l.x))
    textos = [l.texto.strip() for l in linhas]
    plano = "\n".join(textos)
    maiusculo = [t.upper() for t in textos]
    conf: dict[str, str] = {}
    obs: list[str] = []

    chave = achar_chave_no_texto(plano)
    tipo = _detectar_tipo("\n".join(maiusculo), chave)

    # ---------------- CNPJ do emitente (e do comprador, só para conferência) ----------------
    emitente = (None, -1, False)    # (cnpj, índice da linha, DV válido)
    destinatario = None
    comprador = False
    candidatos_invalidos: list[tuple[str, int]] = []
    for i, (t, up) in enumerate(zip(textos, maiusculo)):
        if _RE_COMPRADOR.search(up):
            comprador = True
        achados = [_so_digitos("".join(m.groups())) for m in _RE_CNPJ.finditer(t)]
        achados += [m.group(1) for m in _RE_CNPJ_SEM_PONTUACAO.finditer(t)]
        for cnpj in achados:
            if len(cnpj) != 14 or not cnpj.isdigit():
                continue
            if comprador:
                destinatario = destinatario or cnpj
            elif cnpj_valido(cnpj):
                if emitente[0] is None or not emitente[2]:
                    emitente = (cnpj, i, True)
            else:
                candidatos_invalidos.append((cnpj, i))
    cnpj, idx_cnpj = emitente[0], emitente[1]
    if cnpj:
        conf["cnpj"] = "alta"
    elif candidatos_invalidos:
        lido, idx_cnpj = candidatos_invalidos[0]
        corrigido = _consertar_cnpj(lido)
        if corrigido:
            cnpj, conf["cnpj"] = corrigido, "media"
            obs.append(f"CNPJ lido como {lido} não fechava o dígito verificador; ajustado para {corrigido}. Confira.")
        else:
            cnpj, conf["cnpj"] = lido, "baixa"

    # ---------------- fornecedor: a linha de nome logo acima do CNPJ ----------------
    fornecedor, idx_forn = None, -1
    limite = idx_cnpj if idx_cnpj >= 0 else min(len(textos), 6)
    for i in range(limite - 1, max(limite - 6, -1), -1):
        t, up = textos[i], maiusculo[i]
        letras = sum(c.isalpha() for c in t)
        if letras >= 4 and letras / max(len(t), 1) >= 0.6 and not _RE_NAO_NOME.search(up) and not _RE_COMPRADOR.search(up):
            fornecedor, idx_forn = _letras_certas(re.sub(r"\s+", " ", t)).strip(" -:.,"), i
            break
    if fornecedor is None:  # sem CNPJ à vista: procura o primeiro nome com cara de empresa
        for i, (t, up) in enumerate(zip(textos[:12], maiusculo[:12])):
            if re.search(r"\b(LTDA|EIRELI|EPP|S/?A|ME|MEI|COM[EÉ]RCIO|SUPERMERCADO|MERCADO|ATACADO|DISTRIBUIDORA)\b", up) \
                    and not _RE_NAO_NOME.search(up):
                fornecedor, idx_forn = _letras_certas(re.sub(r"\s+", " ", t)).strip(" -:.,"), i
                break
    if fornecedor:
        conf["fornecedor"] = "media"

    # ---------------- data de emissão ----------------
    data_emissao, melhor, idx_data = None, 9, -1
    for i, (t, up) in enumerate(zip(textos, maiusculo)):
        for m in _RE_DATA.finditer(t):
            dia, mes, ano = (int(_so_digitos(g)) for g in m.groups())
            try:
                d = date(ano, mes, dia)
            except ValueError:
                continue
            if d > hoje + timedelta(days=1) or d.year < 2000:
                continue
            prioridade = 0 if re.search(r"EMISS|DATA", up) and not re.search(r"VALIDADE|VENC|SA[IÍ]DA|PROTOCOLO|AUTORIZ", up) else 1
            if prioridade < melhor:
                data_emissao, melhor, idx_data = d, prioridade, i
    if data_emissao:
        conf["data_emissao"] = "alta" if melhor == 0 else "media"

    # ---------------- itens ----------------
    linhas_num: list[tuple[float, str]] = []
    linhas_desc: list[tuple[float, str]] = []
    idx_item: set[int] = set()  # linhas que são itens (não entram na busca do total)
    for i, (l, t) in enumerate(zip(linhas, textos)):
        if _RE_LINHA_NUMERICA.match(t):  # numa linha de item, '74.97' é o OCR trocando a vírgula por ponto
            t = _RE_PONTO_DECIMAL.sub(r"\1,\2", t)
        dinheiros = _dinheiro(t)
        if len(dinheiros) >= 2 and _RE_LINHA_NUMERICA.match(t):
            linhas_num.append((l.y, t))
            idx_item.add(i)
        else:
            m = _RE_CODIGO_DESCRICAO.match(t)
            if m and not dinheiros and sum(c.isalpha() for c in m.group(2)) >= 3 and not _RE_NAO_NOME.search(t.upper()):
                linhas_desc.append((l.y, _letras_certas(re.sub(r"\s+", " ", m.group(2))).strip()))
    itens: list[ItemExtraido] = []
    if linhas_num and len(linhas_num) == len(linhas_desc):
        for (_, num), (_, desc) in zip(linhas_num, linhas_desc):
            m = _RE_LINHA_NUMERICA.match(num)
            quantidade = para_centavos(_so_digitos(m.group(1)).replace(",", "."))  # centavos de 'x.xx' = quantidade*100
            quantidade = None if quantidade is None else quantidade / 100
            valores = _dinheiro(num[m.end():])
            unit, total = (valores[-2], valores[-1]) if len(valores) >= 2 else (None, valores[-1])
            itens.append(ItemExtraido(descricao=desc, quantidade=quantidade, valor_unitario_centavos=unit,
                                      valor_total_centavos=total))
        conf["itens"] = "media"
    soma_itens = sum(i.valor_total_centavos or 0 for i in itens) if itens else None

    # ---------------- valor total ----------------
    pontos: dict[int, float] = {}
    ocorrencias: dict[int, int] = {}
    indices_rotulo = [i for i, up in enumerate(maiusculo) if _RE_ROTULO_TOTAL.search(up) and not _RE_NAO_TOTAL.search(up)]
    for i, (t, up) in enumerate(zip(textos, maiusculo)):
        if _RE_NAO_TOTAL.search(up) and not _RE_ROTULO_TOTAL.search(up):
            continue
        if i in idx_item:
            continue
        for v in _dinheiro(t):
            ocorrencias[v] = ocorrencias.get(v, 0) + 1
            pontos.setdefault(v, 0.0)
    for i in indices_rotulo:
        for v in _dinheiro(textos[i]):
            pontos[v] = pontos.get(v, 0) + 3
        for j, l2 in enumerate(linhas):  # valor em outra caixa, na altura do rótulo (o papel torto desalinha um pouco)
            if j != i and abs(l2.y - linhas[i].y) <= 60:
                so_dinheiro = re.fullmatch(r"(R\$)?\s*(\d{1,3}(?:\.\d{3})*|\d+),\d{2}", textos[j])
                if so_dinheiro:
                    for v in _dinheiro(textos[j]):
                        pontos[v] = pontos.get(v, 0) + 2
    for v, n in ocorrencias.items():
        if n >= 2:
            pontos[v] = pontos.get(v, 0) + 2
        if soma_itens is not None and abs(v - soma_itens) <= TOLERANCIA_SOMA_CENTAVOS:
            pontos[v] = pontos.get(v, 0) + 6
    valor = None
    if pontos:
        valor = max(pontos, key=lambda v: (pontos[v], v))
        pontuacao = pontos[valor]
        bate = soma_itens is not None and abs(valor - soma_itens) <= TOLERANCIA_SOMA_CENTAVOS
        conf["valor_total"] = "alta" if bate and pontuacao >= 8 else "media" if pontuacao >= 3 else "baixa"
        if bate and "itens" in conf:
            conf["itens"] = "alta"
    elif soma_itens:
        valor, conf["valor_total"] = soma_itens, "baixa"

    # linha de onde saiu o total (para destacar na foto): a do rótulo, a do valor perto dele, ou a 1ª que o tem
    idx_valor = -1
    if valor is not None:
        com_valor = [i for i, t in enumerate(textos) if i not in idx_item and valor in _dinheiro(t)]
        fortes = [j for j in indices_rotulo if "PAGO" not in maiusculo[j]]  # "VALOR PAGO" repete o total; o rótulo é o TOTAL
        perto = lambda rotulos: [i for i in com_valor if i in rotulos  # noqa: E731
                                 or any(abs(linhas[i].y - linhas[j].y) <= 60 for j in rotulos)]
        idx_valor = (perto(fortes) or perto(indices_rotulo) or com_valor or [-1])[0]

    # ---------------- número e série ----------------
    numero = serie = None
    if tipo != "pedido_ou_comprovante":
        m = re.search(r"(?:NFC-?E|NF-?E|CUPOM|NOTA)\D{0,12}?N[º°O0.]*\s*([0-9OIl.]{1,12})", "\n".join(maiusculo))
        if m:
            numero = _so_digitos(m.group(1)).replace(".", "").lstrip("0") or None
        m = re.search(r"S[EÉ]RIE\s*[:.]?\s*([0-9OIl]{1,3})", "\n".join(maiusculo))
        if m:
            serie = _so_digitos(m.group(1)).lstrip("0") or "0"

    # ---------------- pedido/comprovante: dados úteis vão para as observações ----------------
    if tipo == "pedido_ou_comprovante":
        m = re.search(r"\bN[UÚ][MN][EF]R[O0]\s*[:.]?\s*([0-9OIl]+)", "\n".join(maiusculo))
        if m:
            obs.append(f"Pedido {_so_digitos(m.group(1))}.")
        m = re.search(r"\bC[O0]{2}\s*[:.]?\s*([0-9OIl]+)", "\n".join(maiusculo))
        if m:
            obs.append(f"COO {_so_digitos(m.group(1))}.")
    pagamento = _RE_PAGAMENTO.search("\n".join(maiusculo))
    if pagamento:
        obs.append(f"Pagamento: {pagamento.group(1).title()}.")

    if not (cnpj or data_emissao or valor):
        raise ErroExtracao("Não consegui ler CNPJ, data nem valor nesta imagem. Tente uma foto mais próxima e reta, "
                           "ou preencha os campos à mão.")

    regioes = {campo: list(linhas[i].caixa) for campo, i in (
        ("fornecedor", idx_forn), ("cnpj", idx_cnpj), ("data_emissao", idx_data), ("valor_total", idx_valor))
        if 0 <= i < len(linhas) and linhas[i].caixa}

    ext = Extracao(
        origem="ocr", tipo_documento=tipo, fornecedor=fornecedor, cnpj=cnpj, numero=numero, serie=serie,
        data_emissao=data_emissao, valor_total_centavos=valor, chave_acesso=chave, itens=itens, confianca=conf,
        observacoes=" ".join(obs) or None, destinatario_cnpj=destinatario, regioes=regioes)
    return reconciliar(ext, plano)
