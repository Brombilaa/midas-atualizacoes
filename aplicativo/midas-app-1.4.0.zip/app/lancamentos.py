"""Lançamentos: todo dinheiro que entra ou sai. É daqui que saem a aba Lançamentos, o painel do mês, o gasto dos
grupos e a planilha, para que os números nunca discordem.

Uma nota fiscal arquivada é o documento de um lançamento de despesa: ao arquivar, o lançamento é criado (ou
atualizado, se a nota foi reaberta e arquivada de novo). Enquanto uma nota está reaberta para correção, o lançamento
dela fica fora das contas, e volta quando ela é arquivada de novo, sem perder o que foi preenchido nele.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime, timezone

TIPOS = ("despesa", "receita")
SITUACOES = ("previsto", "a_pagar", "pago", "a_receber", "recebido", "cancelado")
RE_COMPETENCIA = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")

DE_ONDE = """FROM lancamentos l
             LEFT JOIN notas n      ON n.id = l.nota_id
             LEFT JOIN categorias c ON c.id = l.categoria_id
             LEFT JOIN grupos g     ON g.id = l.grupo_id"""
# o que conta nos números: não cancelado, e se veio de uma nota, a nota está arquivada (não em correção)
VALE = "l.situacao <> 'cancelado' AND (l.nota_id IS NULL OR n.status IN ('validado', 'lancado'))"


def _agora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def chave_busca(texto: str | None) -> str:
    """'Alimentação' e 'alimentacao' casam: sem acento, sem maiúsculas, espaços simples."""
    sem_acento = "".join(ch for ch in unicodedata.normalize("NFKD", texto or "") if not unicodedata.combining(ch))
    return " ".join(sem_acento.casefold().split())


def sincronizar_nota(conn, nota_id: int, criar: bool = True) -> int | None:
    """Cria ou atualiza o lançamento de uma nota arquivada. Roda dentro da mesma transação do arquivamento.

    Os dados do documento (descrição, valor, data, mês, categoria, grupo) vêm da nota; o que é só do lançamento
    (situação, conta, forma de pagamento, observações) é preservado ao arquivar de novo. Com `criar=False` só
    acompanha uma nota reaberta que já tem lançamento (a correção não deixa o lançamento com dado antigo).
    """
    n = conn.execute("SELECT * FROM notas WHERE id = ?", (nota_id,)).fetchone()
    descricao = (n["fornecedor"] or "").strip() or f"Nota #{nota_id}"
    data = n["data_emissao"] or n["criado_em"][:10]
    dados = (descricao, n["valor_total_centavos"] or 0, data, n["competencia"] or data[:7], n["categoria_id"],
             n["grupo_id"])
    existente = conn.execute("SELECT id FROM lancamentos WHERE nota_id = ?", (nota_id,)).fetchone()
    if existente:
        conn.execute("""UPDATE lancamentos SET descricao = ?, valor_centavos = ?, data = ?, competencia = ?,
                        categoria_id = ?, grupo_id = ?, atualizado_em = ? WHERE id = ?""",
                     (*dados, _agora(), existente["id"]))
        return existente["id"]
    if not criar:
        return None
    agora = _agora()
    cur = conn.execute("""INSERT INTO lancamentos (descricao, valor_centavos, data, competencia, categoria_id, grupo_id,
                                                  tipo, situacao, pago_em, nota_id, criado_em, atualizado_em)
                          VALUES (?, ?, ?, ?, ?, ?, 'despesa', 'pago', ?, ?, ?, ?)""",
                       (*dados, data, nota_id, agora, agora))
    return cur.lastrowid


def _filtros(de: str | None = None, ate: str | None = None, tipo: str | None = None,
             categoria_id: int | None = None, grupo_id: int | None = None, situacao: str | None = None,
             busca: str | None = None) -> tuple[str, list]:
    condicoes, params = [VALE] if situacao != "cancelado" else ["l.situacao = 'cancelado'"], []
    for valor, sql in ((de, "l.competencia >= ?"), (ate, "l.competencia <= ?"), (tipo, "l.tipo = ?"),
                       (categoria_id, "l.categoria_id = ?"), (grupo_id, "l.grupo_id = ?")):
        if valor is not None:
            condicoes.append(sql)
            params.append(valor)
    if situacao and situacao != "cancelado":
        condicoes.append("l.situacao = ?")
        params.append(situacao)
    if busca and chave_busca(busca):
        termo = f"%{chave_busca(busca)}%"
        digitos = re.sub(r"\D", "", busca)
        condicoes.append("(chave_busca(l.descricao) LIKE ? OR chave_busca(l.observacoes) LIKE ? "
                         "OR chave_busca(c.nome) LIKE ? OR chave_busca(g.nome) LIKE ? OR n.numero = ?"
                         + (" OR n.cnpj LIKE ?" if len(digitos) >= 4 else "") + ")")
        params += [termo, termo, termo, termo, busca.strip()] + ([f"%{digitos}%"] if len(digitos) >= 4 else [])
    return " AND ".join(condicoes), params


def listar(conn, limite: int = 500, offset: int = 0, **filtros) -> dict:
    """Lançamentos filtrados (mais recentes primeiro) e os totais de TODOS os filtrados, não só da página."""
    where, params = _filtros(**filtros)
    linhas = conn.execute(
        f"""SELECT l.*, c.nome AS categoria, g.nome AS grupo, n.status AS nota_status, n.numero AS nota_numero,
                   n.cnpj AS nota_cnpj, n.origem AS nota_origem, n.arquivo_ref IS NOT NULL AS tem_arquivo
            {DE_ONDE} WHERE {where}
            ORDER BY l.data DESC, l.id DESC LIMIT ? OFFSET ?""", (*params, limite, offset)).fetchall()
    tot = conn.execute(
        f"""SELECT COUNT(*) AS qtd,
                   COALESCE(SUM(CASE WHEN l.tipo = 'despesa' THEN l.valor_centavos END), 0) AS despesas,
                   COALESCE(SUM(CASE WHEN l.tipo = 'receita' THEN l.valor_centavos END), 0) AS receitas
            {DE_ONDE} WHERE {where}""", params).fetchone()
    return {
        "itens": [dict(r) | {"tem_arquivo": bool(r["tem_arquivo"])} for r in linhas],
        "totais": {"qtd": tot["qtd"], "despesas_centavos": tot["despesas"], "receitas_centavos": tot["receitas"],
                   "saldo_centavos": tot["receitas"] - tot["despesas"]},
    }


def marcar_exportados(conn, competencia: str) -> None:
    """A planilha do mês foi 'lançada': registra quando, nos lançamentos que entraram nela."""
    conn.execute(f"""UPDATE lancamentos SET exportado_em = ?
                     WHERE exportado_em IS NULL AND competencia = ? AND tipo = 'despesa' AND id IN (
                         SELECT l.id {DE_ONDE} WHERE {VALE})""", (_agora(), competencia))
