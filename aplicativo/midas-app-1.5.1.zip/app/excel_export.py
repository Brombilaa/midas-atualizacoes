"""Gera a planilha mensal (xlsx): aba 'Lançamentos' com as notas e aba 'Resumo' com fórmulas vivas."""
from __future__ import annotations

import io
import re
from datetime import date
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.properties import PageSetupProperties

MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]

FONTE = "Arial"
SEM_GRUPO = "(sem grupo)"
BRL = '"R$" #,##0.00'
CABECALHO_FILL = PatternFill("solid", fgColor="1F3864")
TOTAL_FILL = PatternFill("solid", fgColor="D9E1F2")
BORDA = Border(bottom=Side(style="thin", color="BFBFBF"))

COLUNAS = [  # título, largura
    ("Data", 12), ("Grupo", 28), ("Categoria", 22), ("Fornecedor", 34), ("CNPJ", 20),
    ("Nº da nota", 12), ("Valor (R$)", 16), ("Chave de acesso", 48), ("Arquivo", 66), ("ID no sistema", 14),
]
ABA = "Lançamentos"
REF = f"'{ABA}'"  # nome com acento: sempre entre aspas nas fórmulas


def nome_competencia(competencia: str) -> str:
    ano, mes = competencia.split("-")
    return f"{MESES[int(mes) - 1]}/{ano}"


def formatar_cnpj(cnpj: str | None) -> str:
    if cnpj and re.fullmatch(r"[0-9A-Z]{12}[0-9]{2}", cnpj):
        return f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
    return cnpj or ""


def _reais(centavos: int | None) -> float | None:
    return None if centavos is None else float(Decimal(centavos) / 100)


def _texto(celula, valor: str | None) -> None:
    """Grava texto sempre como texto: um fornecedor '=1+1' não pode virar fórmula no Excel."""
    celula.value = valor or None
    if isinstance(valor, str) and valor.startswith("="):
        celula.data_type = "s"


def _estilo(celula, *, negrito=False, cor=None, formato=None, fill=None, alinhamento=None) -> None:
    celula.font = Font(name=FONTE, size=10, bold=negrito, color=cor)
    if formato:
        celula.number_format = formato
    if fill:
        celula.fill = fill
    if alinhamento:
        celula.alignment = alinhamento


def gerar_planilha_mensal(competencia: str, lancamentos: list[dict],
                          grupos: dict[str, dict] | None = None) -> bytes:
    """
    lancamentos: dicts com data (date), grupo, categoria, fornecedor, cnpj, numero, valor_centavos,
                 chave, arquivo, nota_id.
    grupos: nome -> {"orcamento_centavos": int|None, "acumulado_centavos": int} (acumulado = todos os meses).
    """
    grupos = grupos or {}
    # lançamento sem nota (nota_id None) vem depois das notas do mesmo dia
    lancamentos = sorted(lancamentos, key=lambda x: (x["data"], x["nota_id"] is None, x["nota_id"] or 0, x.get("fornecedor") or ""))

    wb = Workbook()
    ws = wb.active
    ws.title = ABA

    # ---------------- aba Lançamentos ----------------
    for col, (titulo, largura) in enumerate(COLUNAS, start=1):
        c = ws.cell(row=1, column=col, value=titulo)
        _estilo(c, negrito=True, cor="FFFFFF", fill=CABECALHO_FILL,
                alinhamento=Alignment(horizontal="center", vertical="center", wrap_text=True))
        ws.column_dimensions[get_column_letter(col)].width = largura
    ws.row_dimensions[1].height = 22

    for linha, n in enumerate(lancamentos, start=2):
        valores = [n["data"], n.get("grupo") or SEM_GRUPO, n.get("categoria"), n.get("fornecedor"),
                   formatar_cnpj(n.get("cnpj")), n.get("numero"), _reais(n["valor_centavos"]),
                   n.get("chave"), n.get("arquivo"), n["nota_id"]]
        for col, v in enumerate(valores, start=1):
            c = ws.cell(row=linha, column=col)
            if isinstance(v, str) or v is None:
                _texto(c, v)
            else:
                c.value = v
            _estilo(c, formato={1: "dd/mm/yyyy", 7: BRL}.get(col))
            c.border = BORDA
            if col == 1:
                c.alignment = Alignment(horizontal="center")
            elif col in (8, 9):
                c.alignment = Alignment(horizontal="left", indent=1)
            if col in (5, 6, 8):
                c.number_format = "@"  # chave (44 dígitos) e CNPJ são texto: Excel só guarda 15 dígitos de precisão
    ultima = max(len(lancamentos) + 1, 2)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLUNAS))}{ultima}"

    faixa = lambda col: f"{REF}!${col}$2:${col}${ultima}"  # noqa: E731

    # ---------------- aba Resumo ----------------
    rs = wb.create_sheet("Resumo")
    rs.sheet_view.showGridLines = False
    for col, largura in zip("ABCDEF", (34, 10, 18, 20, 20, 16)):
        rs.column_dimensions[col].width = largura

    rs["A1"] = f"Resumo de {nome_competencia(competencia)}"
    _estilo(rs["A1"], negrito=True)
    rs["A1"].font = Font(name=FONTE, size=14, bold=True)

    def cabecalho(linha: int, titulos: list[str]) -> None:
        for col, t in enumerate(titulos, start=1):
            c = rs.cell(row=linha, column=col, value=t)
            _estilo(c, negrito=True, cor="FFFFFF", fill=CABECALHO_FILL,
                    alinhamento=Alignment(horizontal="center", vertical="center", wrap_text=True))
        rs.row_dimensions[linha].height = 30

    def total(linha: int, primeira: int, ultima_linha: int, colunas: str) -> None:
        for col in range(1, 7):
            _estilo(rs.cell(row=linha, column=col), negrito=True, fill=TOTAL_FILL)
        rs.cell(row=linha, column=1, value="Total")
        for letra in colunas:
            c = rs[f"{letra}{linha}"]
            c.value = f"=SUM({letra}{primeira}:{letra}{ultima_linha})"
            _estilo(c, negrito=True, fill=TOTAL_FILL, formato=BRL if letra == "C" else "0")

    # --- por grupo
    rs["A3"] = "Por grupo"
    _estilo(rs["A3"], negrito=True)
    cabecalho(4, ["Grupo", "Notas", "Gasto no mês", "Orçamento do grupo", "Acumulado do grupo", "% do orçamento"])
    nomes_grupos = sorted({n.get("grupo") or SEM_GRUPO for n in lancamentos}, key=str.lower)
    linha = 5
    for nome in nomes_grupos:
        _texto(rs.cell(row=linha, column=1), nome)
        rs[f"B{linha}"] = f"=SUMPRODUCT(--({faixa('B')}=A{linha}))"
        rs[f"C{linha}"] = f"=SUMPRODUCT(({faixa('B')}=A{linha})*{faixa('G')})"
        info = grupos.get(nome, {})
        rs[f"D{linha}"] = _reais(info.get("orcamento_centavos"))
        rs[f"E{linha}"] = _reais(info.get("acumulado_centavos"))
        rs[f"F{linha}"] = f'=IF(AND(ISNUMBER(D{linha}),D{linha}>0,ISNUMBER(E{linha})),E{linha}/D{linha},"")'
        _estilo(rs[f"A{linha}"])
        _estilo(rs[f"B{linha}"], formato="0")
        _estilo(rs[f"C{linha}"], formato=BRL)
        _estilo(rs[f"D{linha}"], cor="0000FF", formato=BRL)   # azul = valor vindo do cadastro do grupo
        _estilo(rs[f"E{linha}"], cor="0000FF", formato=BRL)   # azul = valor vindo do banco (todos os meses)
        _estilo(rs[f"F{linha}"], formato="0.0%")
        linha += 1
    ev_ini, ev_fim = 5, max(linha - 1, 5)
    total(linha, ev_ini, ev_fim, "BC")
    linha_total_grupos = linha

    # --- por categoria
    linha += 2
    rs[f"A{linha}"] = "Por categoria"
    _estilo(rs[f"A{linha}"], negrito=True)
    linha += 1
    cabecalho(linha, ["Categoria", "Notas", "Gasto no mês"])
    linha += 1
    cat_ini = linha
    for nome in sorted({n.get("categoria") or "(sem categoria)" for n in lancamentos}, key=str.lower):
        _texto(rs.cell(row=linha, column=1), nome)
        rs[f"B{linha}"] = f"=SUMPRODUCT(--({faixa('C')}=A{linha}))"
        rs[f"C{linha}"] = f"=SUMPRODUCT(({faixa('C')}=A{linha})*{faixa('G')})"
        _estilo(rs[f"A{linha}"])
        _estilo(rs[f"B{linha}"], formato="0")
        _estilo(rs[f"C{linha}"], formato=BRL)
        linha += 1
    cat_fim = max(linha - 1, cat_ini)
    total(linha, cat_ini, cat_fim, "BC")
    linha_total_cat = linha

    # --- conferência e notas
    linha += 2
    rs[f"A{linha}"] = "Conferência (grupos = categorias = lançamentos)"
    rs[f"C{linha}"] = (f'=IF(AND(ROUND(C{linha_total_grupos}-C{linha_total_cat},2)=0,'
                       f'ROUND(C{linha_total_grupos}-SUM({faixa("G")}),2)=0),"OK","DIVERGENTE")')
    _estilo(rs[f"A{linha}"], negrito=True)
    _estilo(rs[f"C{linha}"], negrito=True, alinhamento=Alignment(horizontal="center"))
    linha += 2
    notas = [
        "Valores em azul não são fórmulas: Orçamento vem do cadastro do grupo; Acumulado soma todos os meses",
        "lançados no sistema para o grupo. Notas ainda não validadas não entram nesta planilha.",
    ]
    for texto in notas:
        rs[f"A{linha}"] = texto
        _estilo(rs[f"A{linha}"], cor="595959")
        linha += 1

    for planilha in (ws, rs):  # impressão: paisagem, uma página de largura
        planilha.page_setup.orientation = "landscape"
        planilha.page_setup.fitToWidth = 1
        planilha.page_setup.fitToHeight = 0
        planilha.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)

    wb.calculation.fullCalcOnLoad = True  # o Excel recalcula as fórmulas ao abrir
    saida = io.BytesIO()
    wb.save(saida)
    return saida.getvalue()
