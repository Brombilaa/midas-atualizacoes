"""Lançamentos e contas: todo dinheiro que entra ou sai. É daqui que saem a aba Lançamentos, o painel do mês, o gasto
dos grupos, o saldo das contas e a planilha, para que os números nunca discordem.

Uma nota fiscal arquivada é o documento de um lançamento de despesa: ao arquivar, o lançamento é criado (ou
atualizado, se a nota foi reaberta e arquivada de novo). Enquanto uma nota está reaberta para correção, o lançamento
dela fica fora das contas, e volta quando ela é arquivada de novo, sem perder o que foi preenchido nele.

Os dados do DOCUMENTO (descrição, valor, data, mês, categoria, grupo, forma de pagamento) de um lançamento com nota
vêm da nota e só mudam por ela. Os dados do LANÇAMENTO (conta, situação, vencimento, data do pagamento, observações)
são editados no próprio lançamento. Lançamento sem nota (receita, despesa sem documento) tem tudo editável.
Nada é apagado: cancelar é uma situação, e o lançamento cancelado sai das contas mas continua listável.
"""
from __future__ import annotations

import re
import sqlite3
import unicodedata
from datetime import date, datetime, timedelta, timezone

from .erros import ArquivoInvalido, Conflito, NaoEncontrado
from .extractors.base import FORMAS_PAGAMENTO

TIPOS = ("despesa", "receita")
SITUACOES = ("previsto", "a_pagar", "pago", "a_receber", "recebido", "cancelado")
SITUACOES_DO_TIPO = {"despesa": ("previsto", "a_pagar", "pago", "cancelado"),
                     "receita": ("previsto", "a_receber", "recebido", "cancelado")}
QUITADO = {"despesa": "pago", "receita": "recebido"}
TIPOS_CONTA = ("caixa", "banco", "cartao")
RE_COMPETENCIA = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
MANTER = object()   # "não mexer neste campo" (diferente de None, que limpa)

DE_ONDE = """FROM lancamentos l
             LEFT JOIN notas n       ON n.id = l.nota_id
             LEFT JOIN categorias c  ON c.id = l.categoria_id
             LEFT JOIN categorias cp ON cp.id = c.pai_id
             LEFT JOIN grupos g      ON g.id = l.grupo_id
             LEFT JOIN contas k      ON k.id = l.conta_id
             LEFT JOIN contatos ct   ON ct.id = l.contato_id"""
# subcategoria aparece como "Alimentação › Coffee break"
NOME_CATEGORIA = "CASE WHEN cp.nome IS NOT NULL THEN cp.nome || ' › ' || c.nome ELSE c.nome END"
# o que conta nos números: não cancelado, e se veio de uma nota, a nota está arquivada (não em correção)
VALE = "l.situacao <> 'cancelado' AND (l.nota_id IS NULL OR n.status IN ('validado', 'lancado'))"

CAMPOS_DO_DOCUMENTO = ("tipo", "descricao", "valor_centavos", "data", "competencia", "categoria_id", "grupo_id",
                       "forma_pagamento")
CAMPOS_DO_LANCAMENTO = ("conta_id", "situacao", "vencimento", "pago_em", "observacoes")
TIPO_DO_CONTATO = {"despesa": "fornecedor", "receita": "cliente"}


def _agora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def chave_busca(texto: str | None) -> str:
    """'Alimentação' e 'alimentacao' casam: sem acento, sem maiúsculas, espaços simples."""
    sem_acento = "".join(ch for ch in unicodedata.normalize("NFKD", texto or "") if not unicodedata.combining(ch))
    return " ".join(sem_acento.casefold().split())


def _iso(valor) -> str | None:
    if valor is None or valor == "":
        return None
    if isinstance(valor, date):
        return valor.isoformat()
    try:
        return date.fromisoformat(str(valor)[:10]).isoformat()
    except ValueError as e:
        raise ArquivoInvalido("Data inválida (use AAAA-MM-DD).") from e


# ============================================================================ notas -> lançamentos
def sincronizar_nota(conn, nota_id: int, criar: bool = True, conta_id=MANTER, situacao: str | None = None,
                     vencimento: str | None = None) -> int | None:
    """Cria ou atualiza o lançamento de uma nota arquivada. Roda dentro da mesma transação do arquivamento.

    Com `criar=False` só acompanha uma nota reaberta que já tem lançamento (a correção não deixa o lançamento com
    dado antigo). `conta_id` vem da ficha ao arquivar; MANTER deixa a conta como está. `situacao` ('pago' ou
    'a_pagar', com `vencimento`) vem da ficha ao arquivar; sem ela, um lançamento novo nasce pago (o padrão).
    """
    n = conn.execute("SELECT * FROM notas WHERE id = ?", (nota_id,)).fetchone()
    descricao = (n["fornecedor"] or "").strip() or f"Nota #{nota_id}"
    data = n["data_emissao"] or n["criado_em"][:10]
    dados = {"descricao": descricao, "valor_centavos": n["valor_total_centavos"] or 0, "data": data,
             "competencia": n["competencia"] or data[:7], "categoria_id": n["categoria_id"],
             "grupo_id": n["grupo_id"], "forma_pagamento": n["forma_pagamento"]}
    if conta_id is not MANTER:
        dados["conta_id"] = conta_id
    existente = conn.execute("SELECT id FROM lancamentos WHERE nota_id = ?", (nota_id,)).fetchone()
    if not existente and not criar:
        return None     # nota em conferência sem lançamento: nada a acompanhar (nem fornecedor a cadastrar)
    dados["contato_id"] = contato_para(conn, n["fornecedor"], "despesa", cnpj=n["cnpj"])
    if situacao in ("pago", "a_pagar"):
        dados["situacao"] = situacao
        dados["pago_em"] = data if situacao == "pago" else None
        dados["vencimento"] = (vencimento or data) if situacao == "a_pagar" else None
    if existente:
        sets = ", ".join(f"{k} = ?" for k in dados)
        conn.execute(f"UPDATE lancamentos SET {sets}, atualizado_em = ? WHERE id = ?",
                     (*dados.values(), _agora(), existente["id"]))
        return existente["id"]
    agora = _agora()
    dados.setdefault("situacao", "pago")
    dados.setdefault("pago_em", data)
    dados |= {"tipo": "despesa", "nota_id": nota_id, "criado_em": agora, "atualizado_em": agora}
    cur = conn.execute(f"INSERT INTO lancamentos ({', '.join(dados)}) VALUES ({', '.join('?' * len(dados))})",
                       tuple(dados.values()))
    return cur.lastrowid


# ============================================================================ consultas
def _filtros(de: str | None = None, ate: str | None = None, tipo: str | None = None,
             categoria_id: int | None = None, grupo_id: int | None = None, conta_id: int | None = None,
             contato_id: int | None = None, situacao: str | None = None, busca: str | None = None) -> tuple[str, list]:
    condicoes, params = [VALE] if situacao != "cancelado" else ["l.situacao = 'cancelado'"], []
    for valor, sql in ((de, "l.competencia >= ?"), (ate, "l.competencia <= ?"), (tipo, "l.tipo = ?"),
                       (grupo_id, "l.grupo_id = ?"), (conta_id, "l.conta_id = ?"), (contato_id, "l.contato_id = ?")):
        if valor is not None:
            condicoes.append(sql)
            params.append(valor)
    if categoria_id is not None:   # a categoria e as subcategorias dela
        condicoes.append("(l.categoria_id = ? OR c.pai_id = ?)")
        params += [categoria_id, categoria_id]
    if situacao and situacao != "cancelado":
        condicoes.append("l.situacao = ?")
        params.append(situacao)
    if busca and chave_busca(busca):
        termo = f"%{chave_busca(busca)}%"
        digitos = re.sub(r"\D", "", busca)
        condicoes.append("(chave_busca(l.descricao) LIKE ? OR chave_busca(l.observacoes) LIKE ? "
                         "OR chave_busca(c.nome) LIKE ? OR chave_busca(cp.nome) LIKE ? OR chave_busca(g.nome) LIKE ? "
                         "OR chave_busca(k.nome) LIKE ? OR chave_busca(ct.nome) LIKE ? OR n.numero = ?"
                         + (" OR n.cnpj LIKE ? OR ct.cnpj LIKE ?" if len(digitos) >= 4 else "") + ")")
        params += [termo] * 7 + [busca.strip()] + ([f"%{digitos}%"] * 2 if len(digitos) >= 4 else [])
    return " AND ".join(condicoes), params


_COLUNAS = f"""l.*, {NOME_CATEGORIA} AS categoria, c.tipo AS categoria_tipo, g.nome AS grupo, k.nome AS conta,
              ct.nome AS contato, ct.cnpj AS contato_cnpj, n.status AS nota_status,
              n.numero AS nota_numero, n.cnpj AS nota_cnpj, n.origem AS nota_origem,
              (SELECT COUNT(*) FROM documentos d WHERE d.lancamento_id = l.id) AS qtd_documentos,
              (n.arquivo_ref IS NOT NULL OR EXISTS (SELECT 1 FROM documentos d WHERE d.lancamento_id = l.id))
                  AS tem_arquivo"""


def _saida(r) -> dict:
    d = dict(r)
    d["tem_arquivo"] = bool(d["tem_arquivo"])
    for legado in ("arquivo_ref", "arquivo_sha256", "arquivo_nome", "arquivo_mime"):   # antes da 1.7 (hoje: documentos)
        d.pop(legado, None)
    return d


def listar(conn, limite: int = 500, offset: int = 0, **filtros) -> dict:
    """Lançamentos filtrados (mais recentes primeiro) e os totais de TODOS os filtrados, não só da página."""
    where, params = _filtros(**filtros)
    linhas = conn.execute(f"SELECT {_COLUNAS} {DE_ONDE} WHERE {where} ORDER BY l.data DESC, l.id DESC LIMIT ? OFFSET ?",
                          (*params, limite, offset)).fetchall()
    tot = conn.execute(
        f"""SELECT COUNT(*) AS qtd,
                   COALESCE(SUM(CASE WHEN l.tipo = 'despesa' THEN l.valor_centavos END), 0) AS despesas,
                   COALESCE(SUM(CASE WHEN l.tipo = 'receita' THEN l.valor_centavos END), 0) AS receitas
            {DE_ONDE} WHERE {where}""", params).fetchone()
    return {
        "itens": [_saida(r) for r in linhas],
        "totais": {"qtd": tot["qtd"], "despesas_centavos": tot["despesas"], "receitas_centavos": tot["receitas"],
                   "saldo_centavos": tot["receitas"] - tot["despesas"]},
    }


def obter(conn, lancamento_id: int) -> dict:
    r = conn.execute(f"SELECT {_COLUNAS} {DE_ONDE} WHERE l.id = ?", (lancamento_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Lançamento #{lancamento_id} não encontrado.")
    return _saida(r)


def linha(conn, lancamento_id: int):
    r = conn.execute("SELECT * FROM lancamentos WHERE id = ?", (lancamento_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Lançamento #{lancamento_id} não encontrado.")
    return r


# ============================================================================ criar e editar
def _conferir(conn, campos: dict) -> None:
    """Confere os valores informados (só os presentes em `campos`)."""
    if "tipo" in campos and campos["tipo"] not in TIPOS:
        raise ArquivoInvalido("Tipo deve ser despesa ou receita.")
    if "descricao" in campos:
        campos["descricao"] = " ".join((campos["descricao"] or "").split())
        if not campos["descricao"]:
            raise ArquivoInvalido("Informe uma descrição.")
    if "valor_centavos" in campos:
        if campos["valor_centavos"] is None or campos["valor_centavos"] <= 0:
            raise ArquivoInvalido("Informe um valor maior que zero.")
    for chave in ("data", "vencimento", "pago_em"):
        if chave in campos:
            campos[chave] = _iso(campos[chave])
    if "data" in campos and not campos["data"]:
        raise ArquivoInvalido("Informe a data.")
    if campos.get("competencia") is not None and not RE_COMPETENCIA.fullmatch(campos["competencia"]):
        raise ArquivoInvalido("Mês deve estar no formato AAAA-MM.")
    if campos.get("forma_pagamento") is not None and campos["forma_pagamento"] not in FORMAS_PAGAMENTO:
        raise ArquivoInvalido("Forma de pagamento desconhecida.")
    if "observacoes" in campos:
        campos["observacoes"] = (campos["observacoes"] or "").strip() or None
    for chave, tabela, nome in (("categoria_id", "categorias", "Categoria"), ("grupo_id", "grupos", "Grupo"),
                                ("conta_id", "contas", "Conta")):
        if campos.get(chave) is not None and not conn.execute(
                f"SELECT 1 FROM {tabela} WHERE id = ?", (campos[chave],)).fetchone():
            raise NaoEncontrado(f"{nome} #{campos[chave]} não encontrada." if nome != "Grupo"
                                else f"Grupo #{campos[chave]} não encontrado.")


def _ajustar_situacao(final: dict, mudou: set) -> None:
    """Situação coerente com o tipo; quitado ganha data de pagamento; em aberto perde."""
    tipo = final["tipo"]
    if final["situacao"] not in SITUACOES_DO_TIPO[tipo]:
        if "situacao" in mudou:
            raise ArquivoInvalido(f"Situação '{final['situacao']}' não vale para {tipo}.")
        final["situacao"] = {"pago": "recebido", "recebido": "pago", "a_pagar": "a_receber",
                             "a_receber": "a_pagar"}.get(final["situacao"], final["situacao"])
    if final["situacao"] == QUITADO[tipo]:
        final["pago_em"] = final.get("pago_em") or final["data"]
    elif final["situacao"] != "cancelado":
        final["pago_em"] = None


def _categoria_do_tipo(conn, categoria_id: int | None, tipo: str) -> None:
    if categoria_id is None:
        return
    cat = conn.execute("SELECT nome, tipo FROM categorias WHERE id = ?", (categoria_id,)).fetchone()
    if cat and cat["tipo"] != tipo:
        raise ArquivoInvalido(f"A categoria '{cat['nome']}' é de {cat['tipo']}; escolha uma categoria de {tipo}.")


def criar(conn, campos: dict) -> dict:
    """Lançamento sem nota: receita, ou despesa sem documento fiscal."""
    contato_nome = campos.pop("contato_nome", None)
    campos = {k: v for k, v in campos.items() if k in CAMPOS_DO_DOCUMENTO + CAMPOS_DO_LANCAMENTO}
    campos.setdefault("tipo", "despesa")
    for obrigatorio in ("descricao", "valor_centavos", "data"):
        campos.setdefault(obrigatorio, None)
    _conferir(conn, campos)
    campos["competencia"] = campos.get("competencia") or campos["data"][:7]
    campos.setdefault("situacao", QUITADO[campos["tipo"]])
    if campos["situacao"] not in SITUACOES:
        raise ArquivoInvalido("Situação desconhecida.")
    _ajustar_situacao(campos, {"situacao"} if "situacao" in campos else set())
    _categoria_do_tipo(conn, campos.get("categoria_id"), campos["tipo"])
    campos["contato_id"] = contato_para(conn, contato_nome, campos["tipo"])
    agora = _agora()
    campos |= {"criado_em": agora, "atualizado_em": agora}
    with conn:
        cur = conn.execute(f"INSERT INTO lancamentos ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                           tuple(campos.values()))
    return obter(conn, cur.lastrowid)


def atualizar(conn, lancamento_id: int, campos: dict) -> dict:
    atual = dict(linha(conn, lancamento_id))
    tem_contato = "contato_nome" in campos
    contato_nome = campos.pop("contato_nome", None)
    if tem_contato and atual["nota_id"]:
        raise Conflito("O fornecedor de um lançamento de nota é o da nota.")
    permitidos = CAMPOS_DO_LANCAMENTO if atual["nota_id"] else CAMPOS_DO_DOCUMENTO + CAMPOS_DO_LANCAMENTO
    proibidos = [k for k in campos if k in CAMPOS_DO_DOCUMENTO and k not in permitidos]
    if proibidos:
        raise Conflito("Este lançamento vem de uma nota fiscal: descrição, valor, data, mês, categoria, grupo e forma "
                       "de pagamento se corrigem na nota (reabra a nota para editar).")
    campos = {k: v for k, v in campos.items() if k in permitidos}
    if "situacao" in campos and campos["situacao"] not in SITUACOES:
        raise ArquivoInvalido("Situação desconhecida.")
    _conferir(conn, campos)
    final = atual | campos
    if "data" in campos and "competencia" not in campos and atual["competencia"] == (atual["data"] or "")[:7]:
        final["competencia"] = final["data"][:7]       # o mês acompanha a data, se ninguém o escolheu à parte
    _ajustar_situacao(final, set(campos))
    _categoria_do_tipo(conn, final.get("categoria_id"), final["tipo"])
    if tem_contato or ("tipo" in campos and final["contato_id"]):
        final["contato_id"] = (contato_para(conn, contato_nome, final["tipo"]) if tem_contato
                               else _ajustar_tipo_contato(conn, final["contato_id"], final["tipo"]))
    mudancas = {k: final[k] for k in permitidos + ("competencia", "contato_id") if final.get(k) != atual.get(k)}
    if atual["nota_id"]:
        mudancas.pop("competencia", None)
        mudancas.pop("contato_id", None)
    if mudancas:
        with conn:
            sets = ", ".join(f"{k} = ?" for k in mudancas)
            conn.execute(f"UPDATE lancamentos SET {sets}, atualizado_em = ? WHERE id = ?",
                         (*mudancas.values(), _agora(), lancamento_id))
    return obter(conn, lancamento_id)


def marcar_exportados(conn, competencia: str) -> None:
    """A planilha do mês foi 'lançada': registra quando, nos lançamentos que entraram nela."""
    conn.execute(f"""UPDATE lancamentos SET exportado_em = ?
                     WHERE exportado_em IS NULL AND competencia = ? AND tipo = 'despesa' AND id IN (
                         SELECT l.id {DE_ONDE} WHERE {VALE})""", (_agora(), competencia))


# ============================================================================ contas
_SQL_CONTAS = f"""
    SELECT k.*,
           k.saldo_inicial_centavos + COALESCE((
               SELECT SUM(CASE WHEN l.tipo = 'receita' THEN l.valor_centavos ELSE -l.valor_centavos END)
               FROM lancamentos l LEFT JOIN notas n ON n.id = l.nota_id
               WHERE l.conta_id = k.id AND {VALE} AND l.situacao IN ('pago', 'recebido')
                 AND (k.saldo_inicial_em IS NULL OR COALESCE(l.pago_em, l.data) >= k.saldo_inicial_em)), 0)
               AS saldo_centavos,
           (SELECT COUNT(*) FROM lancamentos l WHERE l.conta_id = k.id) AS qtd_lancamentos
    FROM contas k"""


def listar_contas(conn) -> list[dict]:
    """Saldo = saldo inicial + o que entrou (recebido) - o que saiu (pago) desde a data do saldo inicial."""
    return [dict(r) for r in conn.execute(_SQL_CONTAS + " ORDER BY k.ativa DESC, k.nome COLLATE NOCASE")]


def obter_conta(conn, conta_id: int) -> dict:
    r = conn.execute(_SQL_CONTAS + " WHERE k.id = ?", (conta_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Conta #{conta_id} não encontrada.")
    return dict(r)


def _conferir_conta(conn, campos: dict, ignorar_id: int | None = None) -> None:
    if "nome" in campos:
        campos["nome"] = " ".join((campos["nome"] or "").split())
        if not campos["nome"]:
            raise ArquivoInvalido("Informe o nome da conta.")
        for r in conn.execute("SELECT id, nome FROM contas"):
            if r["id"] != ignorar_id and chave_busca(r["nome"]) == chave_busca(campos["nome"]):
                raise Conflito(f"Já existe a conta '{r['nome']}'.")
    if "tipo" in campos and campos["tipo"] not in TIPOS_CONTA:
        raise ArquivoInvalido("Tipo de conta deve ser caixa, banco ou cartão.")
    if "saldo_inicial_em" in campos:
        campos["saldo_inicial_em"] = _iso(campos["saldo_inicial_em"])
    if "saldo_inicial_centavos" in campos and campos["saldo_inicial_centavos"] is None:
        campos["saldo_inicial_centavos"] = 0
    if "ativa" in campos:
        campos["ativa"] = 1 if campos["ativa"] else 0


def criar_conta(conn, campos: dict) -> dict:
    campos = {k: v for k, v in campos.items()
              if k in ("nome", "tipo", "saldo_inicial_centavos", "saldo_inicial_em")}
    campos.setdefault("nome", None)
    _conferir_conta(conn, campos)
    campos["criado_em"] = _agora()
    try:
        with conn:
            cur = conn.execute(f"INSERT INTO contas ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                               tuple(campos.values()))
    except sqlite3.IntegrityError as e:
        raise Conflito("Já existe uma conta com esse nome.") from e
    return obter_conta(conn, cur.lastrowid)


def atualizar_conta(conn, conta_id: int, campos: dict) -> dict:
    obter_conta(conn, conta_id)
    campos = {k: v for k, v in campos.items()
              if k in ("nome", "tipo", "saldo_inicial_centavos", "saldo_inicial_em", "ativa")}
    _conferir_conta(conn, campos, ignorar_id=conta_id)
    if campos:
        with conn:
            conn.execute(f"UPDATE contas SET {', '.join(f'{k} = ?' for k in campos)} WHERE id = ?",
                         (*campos.values(), conta_id))
    return obter_conta(conn, conta_id)


def excluir_conta(conn, conta_id: int) -> None:
    conta = obter_conta(conn, conta_id)
    if conta["qtd_lancamentos"]:
        raise Conflito(f"A conta '{conta['nome']}' tem {conta['qtd_lancamentos']} lançamento(s) e não pode ser "
                       "excluída. Desative a conta para ela sair das escolhas, sem perder o histórico.",
                       qtd_lancamentos=conta["qtd_lancamentos"])
    with conn:
        conn.execute("DELETE FROM contas WHERE id = ?", (conta_id,))


# ============================================================================ fornecedores e clientes (contatos)
def _ajustar_tipo_contato(conn, contato_id: int | None, tipo_lancamento: str) -> int | None:
    """Quem vende para a associação é fornecedor, quem paga é cliente; quem faz os dois vira 'ambos'."""
    if contato_id is None:
        return None
    papel = TIPO_DO_CONTATO[tipo_lancamento]
    atual = conn.execute("SELECT tipo FROM contatos WHERE id = ?", (contato_id,)).fetchone()
    if atual and atual["tipo"] not in (papel, "ambos"):
        conn.execute("UPDATE contatos SET tipo = 'ambos' WHERE id = ?", (contato_id,))
    return contato_id


def contato_para(conn, nome: str | None, tipo_lancamento: str, cnpj: str | None = None) -> int | None:
    """Acha (pelo CNPJ, ou pelo nome sem acento nem maiúsculas) ou cadastra o fornecedor/cliente."""
    nome = " ".join((nome or "").split())
    if not nome and not cnpj:
        return None
    achado = None
    if cnpj:
        achado = conn.execute("SELECT id FROM contatos WHERE cnpj = ?", (cnpj,)).fetchone()
    if achado is None and nome:
        chave = chave_busca(nome)
        achado = next((r for r in conn.execute("SELECT id, nome, cnpj FROM contatos")
                       if chave_busca(r["nome"]) == chave and (not cnpj or not r["cnpj"])), None)
        if achado is not None and cnpj:     # o mesmo nome agora com CNPJ: completa o cadastro
            conn.execute("UPDATE contatos SET cnpj = ? WHERE id = ?", (cnpj, achado["id"]))
    if achado is not None:
        return _ajustar_tipo_contato(conn, achado["id"], tipo_lancamento)
    cur = conn.execute("INSERT INTO contatos (nome, cnpj, tipo, criado_em) VALUES (?, ?, ?, ?)",
                       (nome or cnpj, cnpj, TIPO_DO_CONTATO[tipo_lancamento], _agora()))
    return cur.lastrowid


_SQL_CONTATOS = f"""
    SELECT ct.*,
           COUNT(v.id) AS qtd_lancamentos,
           COALESCE(SUM(CASE WHEN v.tipo = 'despesa' THEN v.valor_centavos END), 0) AS despesas_centavos,
           COALESCE(SUM(CASE WHEN v.tipo = 'receita' THEN v.valor_centavos END), 0) AS receitas_centavos,
           MAX(v.data) AS ultimo_em
    FROM contatos ct
    LEFT JOIN (SELECT l.* FROM lancamentos l LEFT JOIN notas n ON n.id = l.nota_id WHERE {VALE}) v
           ON v.contato_id = ct.id"""


def listar_contatos(conn, busca: str | None = None, tipo: str | None = None) -> list[dict]:
    """Fornecedores e clientes com o histórico resumido: quanto se pagou, quanto se recebeu, quantas vezes e quando."""
    linhas = [dict(r) for r in conn.execute(_SQL_CONTATOS + " GROUP BY ct.id ORDER BY MAX(v.data) IS NULL, "
                                                            "MAX(v.data) DESC, ct.nome COLLATE NOCASE")]
    if tipo:
        linhas = [r for r in linhas if r["tipo"] in (tipo, "ambos")]
    if busca and chave_busca(busca):
        termo, digitos = chave_busca(busca), re.sub(r"\D", "", busca)
        linhas = [r for r in linhas if termo in chave_busca(r["nome"])
                  or (len(digitos) >= 4 and digitos in (r["cnpj"] or ""))]
    return linhas


def obter_contato(conn, contato_id: int) -> dict:
    r = conn.execute(_SQL_CONTATOS + " WHERE ct.id = ? GROUP BY ct.id", (contato_id,)).fetchone()
    if r is None:
        raise NaoEncontrado(f"Fornecedor/cliente #{contato_id} não encontrado.")
    return dict(r)


def atualizar_contato(conn, contato_id: int, campos: dict) -> dict:
    obter_contato(conn, contato_id)
    campos = {k: v for k, v in campos.items() if k in ("nome", "observacoes")}
    if "nome" in campos:
        campos["nome"] = " ".join((campos["nome"] or "").split())
        if not campos["nome"]:
            raise ArquivoInvalido("Informe o nome.")
    if "observacoes" in campos:
        campos["observacoes"] = (campos["observacoes"] or "").strip() or None
    if campos:
        with conn:
            conn.execute(f"UPDATE contatos SET {', '.join(f'{k} = ?' for k in campos)} WHERE id = ?",
                         (*campos.values(), contato_id))
    return obter_contato(conn, contato_id)


# ============================================================================ agenda (contas a pagar e a receber)
EM_ABERTO = ("a_pagar", "a_receber", "previsto")
FAIXAS = (("atrasadas", "Atrasadas"), ("hoje", "Hoje"), ("semana", "Próximos 7 dias"),
          ("mes", "Resto do mês"), ("depois", "Mais adiante"))


def agenda(conn, hoje: date | None = None, dias_adiante: int = 60) -> dict:
    """O que está em aberto (a pagar, a receber, previsto), separado por quando vence. O vencimento que falta é a
    data do lançamento. 'Mais adiante' vai até `dias_adiante` dias depois do fim do mês."""
    hoje = hoje or date.today()
    fim_semana = hoje + timedelta(days=7)
    proximo_mes = (hoje.replace(day=28) + timedelta(days=4)).replace(day=1)
    fim_mes = proximo_mes - timedelta(days=1)
    limite = fim_mes + timedelta(days=dias_adiante)
    linhas = conn.execute(
        f"""SELECT {_COLUNAS}, COALESCE(l.vencimento, l.data) AS vence_em {DE_ONDE}
            WHERE {VALE} AND l.situacao IN ('a_pagar', 'a_receber', 'previsto')
              AND COALESCE(l.vencimento, l.data) <= ?
            ORDER BY vence_em, l.tipo = 'receita', l.id""", (limite.isoformat(),)).fetchall()
    faixas = {chave: {"chave": chave, "rotulo": rotulo, "itens": [], "a_pagar_centavos": 0, "a_receber_centavos": 0}
              for chave, rotulo in FAIXAS}
    for r in linhas:
        item = _saida(r)
        vence = date.fromisoformat(item["vence_em"])
        chave = ("atrasadas" if vence < hoje else "hoje" if vence == hoje else "semana" if vence <= fim_semana
                 else "mes" if vence <= fim_mes else "depois")
        faixa = faixas[chave]
        faixa["itens"].append(item)
        faixa["a_pagar_centavos" if item["tipo"] == "despesa" else "a_receber_centavos"] += item["valor_centavos"]
    return {"hoje": hoje.isoformat(), "faixas": list(faixas.values()),
            "atrasadas": len(faixas["atrasadas"]["itens"]),
            "vencem_hoje": len(faixas["hoje"]["itens"]),
            "vencem_semana": len(faixas["semana"]["itens"])}


def quitar(conn, lancamento_id: int, pago_em=None, conta_id=MANTER) -> dict:
    """Marca como pago (despesa) ou recebido (receita), com a data e, se informada, a conta."""
    atual = linha(conn, lancamento_id)
    if atual["situacao"] not in EM_ABERTO:
        raise Conflito("Este lançamento não está em aberto." if atual["situacao"] != "cancelado"
                       else "Lançamento cancelado: reative antes de marcar como pago.")
    campos = {"situacao": QUITADO[atual["tipo"]], "pago_em": _iso(pago_em) or date.today().isoformat()}
    if conta_id is not MANTER:
        campos["conta_id"] = conta_id
    return atualizar(conn, lancamento_id, campos)
